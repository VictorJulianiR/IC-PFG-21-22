/**
 * OrdSet
 * 
 * This class implements an ordered set of integers; it supports 
 * the basic sets operation: union as well as search, removal and 
 * insertion.
 */
import java.util.HashMap;
import java.util.Vector;

public class OrdSet {
	
	// ---------
	// Constants
	// ---------
	public static final int min_set_size = 4;
	public static final int max_set_size = 16;
	public static final int max_accepted_resizes = 2;
	
	private static Observer obs;
	
	//The maximum current set size; in other words, the maximum allowed number 
	// of elements before a resize
	private int _set_size;
	
	//The number of resizes made on the set
	private int _resized_times;
	
	//The index of the last element
	private int _last;
	
	//representation of the OrdSet as an array; note that _last + 1 = 
	// _set.length
	private int[] _set;
	
	//Flag that becomes true when trying to add new elements to the Ordered set 
	//after reaching the maximum set size and the maximum accepted resizes
	private boolean _overflow;
	
	// ---------
	// Private methods
	// ---------
	/**
	 * Determines the size to set the array to from any given size. This
	 * method ensures that the size of the array is at least equal to and
	 * always the closest multiple of min_set_size to the proposed size n.
	 * If the proposed size is greater than the max_set_size, the returned
	 * size is max_set_size. 
	 * Note that no changes are made to the instance of OrdSet.
	 * 
	 * @param n - The proposed size to set the array to, n is expected to be >=0
	 * @return The new size for the array, as a multiple of min_set_size.
	 */
	private int defSetSize(int n) {
		int mod;
		this.addVisitedNode("def1");
		if (n <= min_set_size) {this.addVisitedNode("def2");return min_set_size;}
		this.addVisitedNode("def3");
		if (n >= max_set_size) {this.addVisitedNode("def4");return max_set_size;}
		this.addVisitedNode("def5");
		mod = n / min_set_size;
		if (mod * min_set_size == n) {this.addVisitedNode("def7"); return n;}
		else {this.addVisitedNode("def8"); return (mod+1)*min_set_size;} 
	}
	
	/**
	 * Initializes the array. Sets all of the variables to their default.
	 * It also copies the provided values into the ordered set up to the
	 * set size. 
	 * 
	 * @param v - The array of values to copy from into the ordered set.
	 * @param n - The size proposed for the ordered set.
	 */
	private void initSetArray (int[] v) {
		int k;
		this.addVisitedNode("init1");		
		for (k = 0; k < v.length; k++) {
			try {
				this.addVisitedNode("init2");
				if (! _overflow) {
					this.addVisitedNode("init3"); this.add(v[k]);
				}
			} catch (OverflowException e) {
				this.addVisitedNode("init4"); 
				System.out.println("Array is too big.");
			}
			this.addVisitedNode("init6");
		}
		this.addVisitedNode("init5");
	}
	
	/**
	 * Increments the size of the array, if possible, by min_set_size.
	 * If the maximum size or the maximum resizes is reached, _overflow
	 * is set to true.
	 */
	private void resizeArray() {
		this.addVisitedNode("resz1");
		int new_size = _set_size + min_set_size;
		
		if (new_size <= max_set_size && _resized_times < max_accepted_resizes) {
			this.addVisitedNode("resz3");
			int[] _new_set = new int[new_size];
			for (int k = 0; k < _last+1; k++) {
				this.addVisitedNode("resz5");
				_new_set[k] = _set[k];
			}
			this.addVisitedNode("resz6");
			_set_size = new_size;
			_set = _new_set;
			_resized_times++;
		} else {
			this.addVisitedNode("resz7");
			_overflow = true;
		}
	}
	
	/**
	 * Performs a binary search on the provided array for the element x.
	 * A binary search is a search algorithm for finding a particular value 
	 * in a list of data. Binary search assumes the data is sorted. The 
	 * search begins by examining the value in the center of the list; 
	 * because the values are sorted, it then knows whether the value occurs 
	 * before or after the center value, and searches through the correct 
	 * half in the same way.
	 * 
	 * @param a - The array to search.
	 * @param nElts - The number of elements to search in array (first nElts).
	 * @param x - The value to search the array for.
	 * @return The index of the value if it is found, and -1 otherwise.
	 */
	private int binSearch(int[] a, int nElts, int x) {
		this.addVisitedNode("bsch1");
		int i=0;
		int j=nElts-1;
		int m=0;
		
//		The array is of size 0
		if (j<0) {this.addVisitedNode("bsch3"); return -1;} 
		
//		All elements in the array are of smaller value than the searched value x
		this.addVisitedNode("bsch4");
		if (a[j] < x)  {this.addVisitedNode("bsch5"); return -1;} 

// 		Applying the search algorithm by first examining the value of the center
		this.addVisitedNode("bsch6");
		while(i<j){
			this.addVisitedNode("bsch7");
			m= (i+j)/2;
			
//		Changing the indexes of search to choose the appropriate half of the 
//		array to search in
			if (x>a[m]) {
				this.addVisitedNode("bsch9");
				i=m+1;
			} else { 
				this.addVisitedNode("bsch10");
				j=m;
			}
		}

// 		if the value is found, return its index
		this.addVisitedNode("bsch12");
		if (x == a[i]) {this.addVisitedNode("bsch13"); return i;}
		
//		if the value is not found, return -1
		this.addVisitedNode("bsch14");
		return -1;
	}
	
	// ---------
	// Constructors
	// ---------
	/**
	 * Create an empty instance of OrdSet with default values and
	 * a size based on the proposed size.
	 *  
	 * @param size - The proposed size
	 */
	public OrdSet (int size) {
		if (obs == null) obs = new Observer();
		this.addVisitedNode("oss1");
		_set_size = defSetSize(size);
		_set = new int[_set_size];
		_last = -1;
		_resized_times = 0;
		_overflow = false;
	}
	
	/**
	 * Create by copy from an array of values. The ordered set size
	 * will be defined based on the length of the parameter array v; 
	 * if the length of v exceeds max_set_size, only the first values in
	 * the array up to max_set_size will be considered and the set  
	 * would have a size of max_set_size 
	 * 
	 * @param v - The array of values to copy from into the ordered set.
	 */
	public OrdSet(int[] v) {
		this(v.length);
		this.addVisitedNode("osv1");
		initSetArray(v);
	}
	
	// ----------
	// Get methods
	// ----------
	/**
	 * @return The times the array has been resized
	 */
	public int getResizedTimes() {
		this.addVisitedNode("grt1");
		return _resized_times;
	}
	/**
	 * @return The actual size of the ordered set (the actual number of elements
	 * in the ordered set)
	 */
	public int getActualSize() {
		this.addVisitedNode("gas1");
		return _last +1;
	}
	
	/**
	 * @return The current maximum size of the ordered set (the current allowed 
	 * number of elements before resizing).
	 */
	public int getSetSize() {
		this.addVisitedNode("gss1");
		return _set_size;
	}
	
	/**
	 * @return The index of the last element in the ordered set.
	 */
	public int getSetLast() {
		this.addVisitedNode("gsl1");
		return _last;
	}
	
	/**
	 * @return True if the ordered set is empty and false otherwise.
	 */
	public boolean isEmpty() {
		this.addVisitedNode("empt1");
		if (_last < 0) {this.addVisitedNode("empt2"); return true;}
		this.addVisitedNode("empt3");
		return false;
	}
	
	/**
	 * @return The ordered set as an array (note that it may include zeros for the empty slots)
	 */
	private int[] getSetArray() {
		this.addVisitedNode("gsa1");
		return _set;
	}
	
	/**
	 * @return The elements of the ordered set as an array
	 */
	public int[] getSetElements() {
		this.addVisitedNode("gse1");
		int[] elts = new int[_last+1];
		for (int i =0; i<=_last; i++) {
			this.addVisitedNode("gse3");
			elts[i] = _set[i];
		}
		this.addVisitedNode("gse4");
		return elts;
	}	
	
	/**
	 * @return The overflow flag
	 */
	public boolean isOverflow() {
		this.addVisitedNode("ovr1");
		return _overflow;
	}
	
	// ---------
	// Operators.
	// ---------
	
	/**
	 * Compares two ordered sets for equality.
	 * @param x - The ordered set to check for equality.
	 * @return 0 if the sets are equal (have the same elements, 
	 * 		   1 if they are the same size, but not equal,
	 * 		   and the difference in size otherwise.
	 */
	public int equals(OrdSet x) {
		int k,n;
		this.addVisitedNode("eq1");
		if (x.getSetLast() != _last) {
			this.addVisitedNode("eq2");
			return (_last - x.getSetLast());
		}
		this.addVisitedNode("eq3");
		if (isEmpty()) {
			this.addVisitedNode("eq3");
			if (x.isEmpty()) {this.addVisitedNode("eq4");return 0;}
		}
		this.addVisitedNode("eq5");
		for(k = 0, n = 0; n < (x.getSetLast() + 1); n++) {
			this.addVisitedNode("eq6");
			k = x.elementAt(n);
			if (k != _set[n]) {
				this.addVisitedNode("eq8");
				return 1;
			}
			this.addVisitedNode("eq11");
		}
		this.addVisitedNode("eq9");
		return 0;
	}

	/**
	 * Checks if the ordered set contains the indicated value.
	 * @param n - The value to check for in the ordered set.
	 * @return True if a match is found and false otherwise.
	 */
	public boolean contains(int n) {
		this.addVisitedNode("ctnn1");
		return binSearch(_set, _last+1, n) >= 0;
	}
	
	/**
	 * Checks if this ordered set contains the ordered set given by x,
	 * all elements in x are elements in this.
	 * @param x - The ordered set to check for.
	 * @return true if x is a subset of this ordered set, and false otherwise.
	 */
	public boolean contains (OrdSet x) {
		int k, n;
		this.addVisitedNode("ctno1");
		for(n = 0, k = 0; n < (x.getSetLast() + 1); n++) {
			this.addVisitedNode("ctno2");
			k = x.elementAt(n);
			if (binSearch(_set, _last+1, k) < 0) {
				this.addVisitedNode("ctno4");
				return false;
			}
			this.addVisitedNode("ctno7");
		}
		this.addVisitedNode("ctno5");
		return true;
	}
	
	/**
	 * Removes an element from the set. The element to remove is given 
	 * by the val parameter.
	 * 
	 * @param val - The value of the element to remove from the set.
	 * @return true if the value was found and removed, and false otherwise.
	 */
	public boolean remove (int val) throws OverflowException{
		this.addVisitedNode("rmv1");
		if (_overflow) {this.addVisitedNode("rmv2"); throw new OverflowException();}
		this.addVisitedNode("rmv3");
		int where = binSearch(_set, _last + 1, val);
		if (where >= 0) {
			int k;
			this.addVisitedNode("rmv5");
			for (k = where; k < _last; k++) {
				this.addVisitedNode("rmv6");
				_set[k] = _set[k+1];
			}
			this.addVisitedNode("rmv7");
			_last --;
			return true;
		} else {
			this.addVisitedNode("rmv9");
			return false;
		}
	}
	
	/**
	 * Adds an item to the set. Since this is a set, the element is only 
	 * added if it is unique. An attempt to add a new element while the set
	 * is full causes a set resize. When no resizes are allowed, an 
	 * overflow exception is raised.
	 * 
	 * @param n - The element to add to the ordered set. 
	 */
	public void add(int n) throws OverflowException{
		this.addVisitedNode("add1");
		if (_overflow) {this.addVisitedNode("add2"); throw new OverflowException();}
		// if it is already in the set we return.
		this.addVisitedNode("add3");
		if (this.contains(n)) {this.addVisitedNode("add4"); return;}
		this.addVisitedNode("add5");
		if (_last+1 >= _set_size) {
			this.addVisitedNode("add6");
			this.resizeArray();
			if (_overflow) {
				this.addVisitedNode("add8");
				throw new OverflowException();
			}
		}
		this.addVisitedNode("add9");
		int i = make_a_free_slot(n);
		_set[i] = n;
		_last++;
	}
	 
	/**
	 * Returns the element at the provided index.
	 * 
	 * @param where - The position of the element to return or -1 if the item is
	 * out of bound.
	 * @return The ordered set element at the given position.
	 */
	public int elementAt(int where) {
		this.addVisitedNode("elt1");
		if ((where < 0) || (where > _last)) {
			this.addVisitedNode("elt2");
			System.err.println("Out of bound element: " + where);
			return -1;
		}
		this.addVisitedNode("elt3");
		return _set[where];
	}
	
	/**
	 * Makes a free slot in the array, to place the value n into. 
	 * This free slot will be made where it is appropriate to store
	 * the value n and maintain the ordering of the set.
	 * 
	 * @param n - The value to be stored in the array, for which the free slot 
	 * is being made.
	 * @return The index of the new slot in which to place n.
	 */
	private int make_a_free_slot(int n) {
		this.addVisitedNode("mks1");
		int where = _last + 1;
		
		while ((where-1>=0) && (_set[where-1] > n)) {
			this.addVisitedNode("mks3");
			_set[where] = _set[where-1];
			where--;
		}
		this.addVisitedNode("mks4");
		return where;
	}
	 
	/**
	 * Union of two sets. It returns an instance of OrdSet that is the union of 
	 * "this" instance and s2. If the size of the union is greater than 
	 * max_set_size an overflow exception is thrown
	 * 
	 * @param s2 The second set to perform the union on.
	 * @return The union of the two sets, "this" and s2.
	 */
	public OrdSet union(OrdSet s2) {
		this.addVisitedNode("uni1");
		int[] set1 = this.getSetArray();
		int[] set2 = s2.getSetArray();
		
		int size1 = this.getSetLast() + 1;
		int size2 = s2.getSetLast() + 1;
		
		OrdSet set = new OrdSet(size1 + size2);
		
		int lb1 = 0, lb2 = 0, pos = 0;
		try {
			while (lb1 < size1 && lb2 < size2) {
				this.addVisitedNode("uni4");
				if (set1[lb1] < set2[lb2]) {
					this.addVisitedNode("uni5");
					set.add(set1[lb1]);
					pos = pos + 1;
					lb1 = lb1 + 1;
				} else {
					this.addVisitedNode("uni6");
					if (set2[lb2] < set1[lb1]) {
						this.addVisitedNode("uni7");
						set.add(set2[lb2]);
						pos = pos + 1;
						lb2 = lb2 + 1;
					} else {
						this.addVisitedNode("uni8");
						if (set1[lb1] == set2[lb2]) {
							this.addVisitedNode("uni9");
							set.add(set2[lb2]);
							pos = pos + 1;
							lb1 = lb1 + 1;
							lb2 = lb2 + 1;
						} else {
							this.addVisitedNode("uni10");
							System.exit(1);
						}
					}
				}
				this.addVisitedNode("uni11");
			}
			this.addVisitedNode("uni12");
			while (lb1 < size1) {
				this.addVisitedNode("uni13");
				set.add(set1[lb1]);
				pos = pos + 1;
				lb1 = lb1 + 1;
				this.addVisitedNode("uni12");
			}
			this.addVisitedNode("uni14");
			while (lb2 < size2) {
				this.addVisitedNode("uni15");
				set.add(set2[lb2]);
				pos = pos + 1;
				lb2 = lb2 + 1;
				this.addVisitedNode("uni14");
			}
		
			// set the last element index.
			this.addVisitedNode("uni16");
			set._last = pos - 1;
		} catch (OverflowException e) {
			this.addVisitedNode("uni18");
			System.out.println ("The union caused an overflow; the union size exceeds the maximum set size");
		}
		return set;
	}

	/**
	 * 
	 * @return The string representation of this ordered set, where each integer
	 * in the set is separated from the next one by a space character.
	 */
	public String toString() {
		this.addVisitedNode("str1");
		String output = "";
		int k = 0;
		
		for (k = 0; k <= _last; k++)
			{
				this.addVisitedNode("str3");
				output += "" + _set[k] + " ";
			}
		this.addVisitedNode("str4");
		return output;
	}
	
    public static String getReport() {
    	if (!obs.isRecording()) return "";
    	return obs.getReport();
    }
    
	public static void startRecording() {
    	// Setup the node list.
		HashMap nodeList = new HashMap();
		
		//defSetSize
		nodeList.put("def1","Line 52: if (n <= min_set_size)");
		nodeList.put("def2","Line 52: return min_set_size;");
		nodeList.put("def3","Line 53: if (n >= max_set_size)");
		nodeList.put("def4","Line 53: return max_set_size;");
		nodeList.put("def5","Line 54: mod = n / min_set_size;");
		nodeList.put("def6","Line 55: if (mod * min_set_size == n)");
		nodeList.put("def7","Line 55: return n;");
		nodeList.put("def8","Line 56: else return (mod+1)*min_set_size;");
		nodeList.put("def9","Line 57: End method");
		
		//initSetArray
		nodeList.put("init1","Line 70: for (k = 0; k < v.length; k++)");
		nodeList.put("init2","Line 72: if (! _overflow)");
		nodeList.put("init3","Line 72: this.add(v[k]);");
		nodeList.put("init4","Line 74: catch - System.out.println(Array is too big.)");
		nodeList.put("init6","Line 76: for loop end");
		nodeList.put("init5","Line 77: End Method");
		
		//resizeArray
		nodeList.put("resz1","Line 85: int new_size = _set_size + min_set_size;");
		nodeList.put("resz2","Line 87: if (new_size <= max_set_size && _resized_times < max_accepted_resizes) {");
		nodeList.put("resz3","Line 88: int[] _new_set = new int[new_size];");
		nodeList.put("resz4","Line 89: for (int k = 0; k < _last+1; k++)");
		nodeList.put("resz5","Line 90: _new_set[k] = _set[k];");
		nodeList.put("resz6","Line 93: _set_size = new_size;");
		nodeList.put("resz7","Line 97: _overflow = true;");
		nodeList.put("resz8","Line 99: End Method");
		
		//binSearch
		nodeList.put("bsch1","Line 116: int i=0;");
		nodeList.put("bsch2","Line 121: if (j<0)");
		nodeList.put("bsch3","Line 121: return -1");
		nodeList.put("bsch4","Line 124: if (a[j] < x)");
		nodeList.put("bsch5","Line 124: return -1;");
		nodeList.put("bsch6","Line 127: while(i<j){");
		nodeList.put("bsch7","Line 128: m= (i+j)/2;");
		nodeList.put("bsch8","Line 132: if (x>a[m]) {");
		nodeList.put("bsch9","Line 133: i=m+1;");
		nodeList.put("bsch10","Line 135: j=m;");
		nodeList.put("bsch11","Line 136: end if-else");
		nodeList.put("bsch12","Line 140: if (x == a[i])");
		nodeList.put("bsch13","Line 140: return i;");
		nodeList.put("bsch14","Line 143: return -1;");
		nodeList.put("bsch15","Line 144: End Method");
		
		//OrdSet(size)
		nodeList.put("oss1","Line 156: _set_size = defSetSize(size);");
		nodeList.put("oss2","Line 157: _set = new int[_set_size];");
		nodeList.put("oss3","Line 161: End Method");
		
		//OrdSet(array)
		nodeList.put("osv1","Line 174: initSetArray(v);");
		nodeList.put("osv2","Line 175: End Method");
		
		//getResizedTimes
		nodeList.put("grt1","Line 184: return _resized_times;");
		nodeList.put("grt2","Line 185: End Method");	
		
		//getActualSize
		nodeList.put("gas1","Line 191: return _last +1;");
		nodeList.put("gas2","Line 192: End Method");
		
		//getSetSize
		nodeList.put("gss1","Line 199: return _set_size;");
		nodeList.put("gss2","Line 200: End Method");		

		//getSetLast
		nodeList.put("gsl1","Line 206: return _last;");
		nodeList.put("gsl2","Line 207: End Method");
		
		//isEmpty
		nodeList.put("empt1","Line 213: if (_last < 0)");
		nodeList.put("empt2","Line 213: return true;");
		nodeList.put("empt3","Line 214: return false;");
		nodeList.put("empt4","Line 215: End Method");
		
		//getSetArray
		nodeList.put("gsa1","Line 221: return _set;");
		nodeList.put("gsa2","Line 222: End Method");		
		
		//getSetElements
		nodeList.put("gse1","Line 228: int[] elts = new int[_last+1];");
		nodeList.put("gse2","Line 229: for (int i =0; i<=_last; i++) {");	
		nodeList.put("gse3","Line 230: elts[i] = _set[i];");
		nodeList.put("gse4","Line 232: return elts;");
		nodeList.put("gse5","Line 233: End Method");
		
		//isOverflow
		nodeList.put("ovr1","Line 239: return _overflow;");
		nodeList.put("ovr2","Line 240: End Method");		
		
		//equals(OrdSet)
		nodeList.put("eq1","Line 256: if (x.getSetLast() != _last) {");
		nodeList.put("eq2","Line 257: return (_last - x.getSetLast());");	
		nodeList.put("eq3","Line 260: if (isEmpty() && x.isEmpty())");
		nodeList.put("eq4","Line 260: return 0;");
		nodeList.put("eq5","Line 262: for(k = 0, n = 0; n < (x.getSetLast() + 1); n++) {");
		nodeList.put("eq6","Line 263: k = x.elementAt(n);");
		nodeList.put("eq7","Line 264: if (k != _set[n]) {");	
		nodeList.put("eq8","Line 265: return 1;");
		nodeList.put("eq9","Line 269: return 0;");
		nodeList.put("eq11","Line 266: end if");
		nodeList.put("eq10","Line 270: End Method");
		
		//contains(n)
		nodeList.put("ctnn1","Line 278: return binSearch(_set, _last+1, n) >= 0;");
		nodeList.put("ctnn2","Line 279: End Method");
		
		//contains(OrdSet)
		nodeList.put("ctno1","Line 290: for(n = 0, k = 0; n < (x.getSetLast() + 1); n++) {");
		nodeList.put("ctno2","Line 291: k = x.elementAt(n);");	
		nodeList.put("ctno3","Line 292: if (binSearch(_set, _last+1, k) < 0) {");
		nodeList.put("ctno4","Line 293: return false;");
		nodeList.put("ctno5","Line 297: return true;");
		nodeList.put("ctno7","Line 294: end if");
		nodeList.put("ctno6","Line 298: End Method");		
		
		//remove
		nodeList.put("rmv1","Line 308: if (_overflow) ");
		nodeList.put("rmv2","Line 308: throw new OverflowException();");	
		nodeList.put("rmv3","Line 309: int where = binSearch(_set, _last + 1, val);");
		nodeList.put("rmv4","Line 310: if (where >= 0) {");
		nodeList.put("rmv5","Line 312: for (k = where; k < _last; k++) {");
		nodeList.put("rmv6","Line 313: _set[k] = _set[k+1];");
		nodeList.put("rmv7","Line 315: _last --;");	
		nodeList.put("rmv8","Line 316: return true;");
		nodeList.put("rmv9","Line 318: return false;");
		nodeList.put("rmv10","Line 320: End Method");		
		
		//add
		nodeList.put("add1","Line 331: if (_overflow) ");
		nodeList.put("add2","Line 331: throw new OverflowException();");	
		nodeList.put("add3","Line 333: if (this.contains(n))");
		nodeList.put("add4","Line 333: return;");
		nodeList.put("add5","Line 335: if (_last+1 >= _set_size) {");
		nodeList.put("add6","Line 336: this.resizeArray();");
		nodeList.put("add7","Line 337: if (_overflow) {");	
		nodeList.put("add8","Line 338: throw new OverflowException();");
		nodeList.put("add9","Line 342: int i = make_a_free_slot(n);");
		nodeList.put("add10","Line 343: _set[i] = n;");
		nodeList.put("add11","Line 345: End Method");			
		
		//elementAt
		nodeList.put("elt1","Line 355: if ((where < 0) || (where > _last)) {");
		nodeList.put("elt2","Line 356: System.err.println(Out of bound element:  + where);");
		nodeList.put("elt3","Line 360: return _set[where];");
		nodeList.put("elt4","Line 361: End Method");			
		
		//make_a_free_slot
		nodeList.put("mks1","Line 373: int where = _last + 1;");
		nodeList.put("mks2","Line 375: while ((where-1>=0) && (_set[where-1] > n)) {");
		nodeList.put("mks3","Line 376: _set[where] = _set[where-1];");
		nodeList.put("mks4","Line 379: return where;");
		nodeList.put("mks5","Line 380: End Method");		
		
		//union
		nodeList.put("uni1","Line 391: int[] set1 = this.getSetArray();");
		nodeList.put("uni2","Line 400: try {");
		nodeList.put("uni3","Line 401: while (lb1 < size1 && lb2 < size2) {");
		nodeList.put("uni4","Line 402: if (set1[lb1] < set2[lb2]) {");	
		nodeList.put("uni5","Line 403: set.add(set1[lb1]);");
		nodeList.put("uni6","Line 406: } else if (set2[lb2] < set1[lb1]) {");
		nodeList.put("uni7","Line 407: set.add(set2[lb2]);");
		nodeList.put("uni8","Line 410: } else if (set1[lb1] == set2[lb2]) {");
		nodeList.put("uni9","Line 411: set.add(set2[lb2]);");
		nodeList.put("uni10","Line 416: System.exit(1);");	
		nodeList.put("uni11","Line 418: end first while");
		nodeList.put("uni12","Line 420: while (lb1 < size1) {");
		nodeList.put("uni13","Line 421: set.add(set1[lb1]);");
		nodeList.put("uni14","Line 426: while (lb2 < size2) {");
		nodeList.put("uni15","Line 427: set.add(set2[lb2]);");	
		nodeList.put("uni16","Line 433: set._last = pos - 1;");
		nodeList.put("uni17","Line 437: return set;");
		nodeList.put("uni18","Line 435: System.out.println (The union caused an overflow; the union size exceeds the maximum set size);");
		nodeList.put("uni19","Line 438: End Method");		
		
		//toString
		nodeList.put("str1","Line 446: String output = ;");
		nodeList.put("str2","Line 449: for (k = 0; k <= _last; k++)");
		nodeList.put("str3","Line 450: output +=  + _set[k] + ;");
		nodeList.put("str4","Line 452: return output;");
		nodeList.put("str5","Line 453: End Method");		
						
        String startNode = "oss1";
        
        Vector edgeList = new Vector();
        //defSetSize
        edgeList.add("def1");
        edgeList.add("def2");
        
        edgeList.add("def1");
        edgeList.add("def3");
        
        edgeList.add("def2");
        edgeList.add("def9");
        
        edgeList.add("def3");
        edgeList.add("def4");
        
        edgeList.add("def3");
        edgeList.add("def5");
        
        edgeList.add("def4");
        edgeList.add("def9");
        
        edgeList.add("def5");
        edgeList.add("def6");
        
        edgeList.add("def6");
        edgeList.add("def7");
        
        edgeList.add("def6");
        edgeList.add("def8");
        
        edgeList.add("def7");
        edgeList.add("def9");
        
        edgeList.add("def8");
        edgeList.add("def9");
        
        //initSetArray
        edgeList.add("init1");
        edgeList.add("init2");
        
        edgeList.add("init1");
        edgeList.add("init5");

        edgeList.add("init2");
        edgeList.add("init6");
        
        edgeList.add("init2");
        edgeList.add("init3");

        edgeList.add("init3");
        edgeList.add("init6");
    
        edgeList.add("init3");
        edgeList.add("init4");
        
        edgeList.add("init4");
        edgeList.add("init6");
        
        edgeList.add("init6");
        edgeList.add("init1");
        
        //resizeArray
        edgeList.add("resz1");
        edgeList.add("resz2");
        
        edgeList.add("resz2");
        edgeList.add("resz3");
        
        edgeList.add("resz2");
        edgeList.add("resz7");
        
        edgeList.add("resz3");
        edgeList.add("resz4");
        
        edgeList.add("resz4");
        edgeList.add("resz5");
        
        edgeList.add("resz4");
        edgeList.add("resz6");
        
        edgeList.add("resz5");
        edgeList.add("resz4");
        
        edgeList.add("resz6");
        edgeList.add("resz8");
        
        edgeList.add("resz7");
        edgeList.add("resz8");
        
        //binSearch
        edgeList.add("bsch1");
        edgeList.add("bsch2");
        
        edgeList.add("bsch2");
        edgeList.add("bsch3");
        
        edgeList.add("bsch2");
        edgeList.add("bsch4");
        
        edgeList.add("bsch3");
        edgeList.add("bsch15");
        
        edgeList.add("bsch4");
        edgeList.add("bsch5");
        
        edgeList.add("bsch4");
        edgeList.add("bsch6");
        
        edgeList.add("bsch5");
        edgeList.add("bsch15");
        
        edgeList.add("bsch6");
        edgeList.add("bsch7");
        
        edgeList.add("bsch6");
        edgeList.add("bsch12");
        
        edgeList.add("bsch7");
        edgeList.add("bsch8");
        
        edgeList.add("bsch8");
        edgeList.add("bsch9");
        
        edgeList.add("bsch8");
        edgeList.add("bsch10");
        
        edgeList.add("bsch9");
        edgeList.add("bsch11");
        
        edgeList.add("bsch10");
        edgeList.add("bsch11");
        
        edgeList.add("bsch11");
        edgeList.add("bsch6");
        
        edgeList.add("bsch12");
        edgeList.add("bsch13");
        
        edgeList.add("bsch12");
        edgeList.add("bsch14");
        
        edgeList.add("bsch13");
        edgeList.add("bsch15");
        
        edgeList.add("bsch14");
        edgeList.add("bsch15");
        
        //OrdSet(size)
        edgeList.add("oss1");
        edgeList.add("oss2");
        
        edgeList.add("oss2");
        edgeList.add("oss3");    
        
        //OrdSet(array)
        edgeList.add("osv1");
        edgeList.add("osv2");
        
        //getResizeTimes
        edgeList.add("grt1");
        edgeList.add("grt2");
        
        //getActualSize
        edgeList.add("gas1");
        edgeList.add("gas2");
        
        //getSetSize
        edgeList.add("gss1");
        edgeList.add("gss2");
        
        //getSetLast
        edgeList.add("gsl1");
        edgeList.add("gsl2");
        
        //isEmpty
        edgeList.add("empt1");
        edgeList.add("empt2");
        
        edgeList.add("empt1");
        edgeList.add("empt3");
        
        edgeList.add("empt2");
        edgeList.add("empt4");
        
        edgeList.add("empt3");
        edgeList.add("empt4");
        
        //getSetArray
        edgeList.add("gsa1");
        edgeList.add("gsa2");        
        
        //getSetElements
        edgeList.add("gse1");
        edgeList.add("gse2");
        
        edgeList.add("gse2");
        edgeList.add("gse3");
        
        edgeList.add("gse2");
        edgeList.add("gse4");
        
        edgeList.add("gse3");
        edgeList.add("gse2");
        
        edgeList.add("gse4");
        edgeList.add("gse5");
        
        //isOverflow
        edgeList.add("ovr1");
        edgeList.add("ovr2");
        
        //equals
        edgeList.add("eq1");
        edgeList.add("eq2");
        
        edgeList.add("eq1");
        edgeList.add("eq3");
        
        edgeList.add("eq2");
        edgeList.add("eq10");
        
        edgeList.add("eq3");
        edgeList.add("eq4");
        
        edgeList.add("eq3");
        edgeList.add("eq5");
        
        edgeList.add("eq4");
        edgeList.add("eq10");
        
        edgeList.add("eq5");
        edgeList.add("eq6");
        
        edgeList.add("eq5");
        edgeList.add("eq9");
        
        edgeList.add("eq6");
        edgeList.add("eq7");
        
        edgeList.add("eq7");
        edgeList.add("eq8");
        
        edgeList.add("eq7");
        edgeList.add("eq11");
        
        edgeList.add("eq8");
        edgeList.add("eq10");
        
        edgeList.add("eq9");
        edgeList.add("eq10");
        
        edgeList.add("eq11");
        edgeList.add("eq5");
        
        //Contains(n)
        edgeList.add("ctnn1");
        edgeList.add("ctnn2");
        
        //contains(OrdSet)
        edgeList.add("ctno1");
        edgeList.add("ctno2");
        
        edgeList.add("ctno1");
        edgeList.add("ctno5");
        
        edgeList.add("ctno2");
        edgeList.add("ctno3");
        
        edgeList.add("ctno3");
        edgeList.add("ctno7");
        
        edgeList.add("ctno3");
        edgeList.add("ctno4");
        
        edgeList.add("ctno4");
        edgeList.add("ctno6");
        
        edgeList.add("ctno5");
        edgeList.add("ctno6");
        
        edgeList.add("ctno7");
        edgeList.add("ctno1");
        
        //remove
        edgeList.add("rmv1");
        edgeList.add("rmv2");
        
        edgeList.add("rmv1");
        edgeList.add("rmv3");
        
        edgeList.add("rmv2");
        edgeList.add("rmv10");
        
        edgeList.add("rmv3");
        edgeList.add("rmv4");
        
        edgeList.add("rmv4");
        edgeList.add("rmv5");
        
        edgeList.add("rmv4");
        edgeList.add("rmv9");
        
        edgeList.add("rmv5");
        edgeList.add("rmv6");
        
        edgeList.add("rmv5");
        edgeList.add("rmv7");
        
        edgeList.add("rmv6");
        edgeList.add("rmv5");
        
        edgeList.add("rmv7");
        edgeList.add("rmv8");
        
        edgeList.add("rmv8");
        edgeList.add("rmv10");
        
        edgeList.add("rmv9");
        edgeList.add("rmv10");
        
        //add
        edgeList.add("add1");
        edgeList.add("add2");
        
        edgeList.add("add1");
        edgeList.add("add3");
        
        edgeList.add("add2");
        edgeList.add("add11");
        
        edgeList.add("add3");
        edgeList.add("add4");
        
        edgeList.add("add3");
        edgeList.add("add5");
        
        edgeList.add("add4");
        edgeList.add("add11");
        
        edgeList.add("add5");
        edgeList.add("add6");
        
        edgeList.add("add5");
        edgeList.add("add9");
        
        edgeList.add("add6");
        edgeList.add("add7");
        
        edgeList.add("add7");
        edgeList.add("add8");
        
        edgeList.add("add7");
        edgeList.add("add9");
        
        edgeList.add("add8");
        edgeList.add("add11");
        
        edgeList.add("add9");
        edgeList.add("add10");
        
        edgeList.add("add10");
        edgeList.add("add11");
        
        //elementAt
        edgeList.add("elt1");
        edgeList.add("elt2");
        
        edgeList.add("elt1");
        edgeList.add("elt3");
        
        edgeList.add("elt2");
        edgeList.add("elt4");
        
        edgeList.add("elt3");
        edgeList.add("elt4");
         
        //make_a_free_Slot
        edgeList.add("mks1");
        edgeList.add("mks2");       
        
        edgeList.add("mks2");
        edgeList.add("mks3");
        
        edgeList.add("mks2");
        edgeList.add("mks4");
        
        edgeList.add("mks3");
        edgeList.add("mks2");
        
        edgeList.add("mks4");
        edgeList.add("mks5");
        
        //union
        edgeList.add("uni1");
        edgeList.add("uni2");        
        
        edgeList.add("uni2");
        edgeList.add("uni3");
        
        edgeList.add("uni3");
        edgeList.add("uni4");
        
        edgeList.add("uni3");
        edgeList.add("uni12");
        
        edgeList.add("uni4");
        edgeList.add("uni5");
        
        edgeList.add("uni4");
        edgeList.add("uni6");
        
        edgeList.add("uni5");
        edgeList.add("uni11");
        
        edgeList.add("uni5");
        edgeList.add("uni18");
        
        edgeList.add("uni6");
        edgeList.add("uni7");
        
        edgeList.add("uni6");
        edgeList.add("uni8");
        
        edgeList.add("uni7");
        edgeList.add("uni11");
        
        edgeList.add("uni7");
        edgeList.add("uni18");
        
        edgeList.add("uni8");
        edgeList.add("uni9");
        
        edgeList.add("uni8");
        edgeList.add("uni10");
        
        edgeList.add("uni9");
        edgeList.add("uni11");
        
        edgeList.add("uni9");
        edgeList.add("uni18");
        
        edgeList.add("uni10");
        edgeList.add("uni19");
        
        edgeList.add("uni11");
        edgeList.add("uni3");
        
        edgeList.add("uni12");
        edgeList.add("uni13");
        
        edgeList.add("uni12");
        edgeList.add("uni14");
        
        edgeList.add("uni13");
        edgeList.add("uni12");
        
        edgeList.add("uni13");
        edgeList.add("uni18");
        
        edgeList.add("uni14");
        edgeList.add("uni15");
        
        edgeList.add("uni14");
        edgeList.add("uni16");
        
        edgeList.add("uni15");
        edgeList.add("uni14");
        
        edgeList.add("uni15");
        edgeList.add("uni18");
        
        edgeList.add("uni16");
        edgeList.add("uni17");
        
        edgeList.add("uni17");
        edgeList.add("uni19");
        
        edgeList.add("uni18");
        edgeList.add("uni17");
        
        //toString
        edgeList.add("str1");
        edgeList.add("str2");       
        
        edgeList.add("str2");
        edgeList.add("str3");
        
        edgeList.add("str2");
        edgeList.add("str4");
        
        edgeList.add("str3");
        edgeList.add("str2");
        
        edgeList.add("str4");
        edgeList.add("str5");       
        
        HashMap defUseMap = new HashMap();       
        
        obs = new Observer(nodeList,defUseMap,edgeList,startNode, "OrdSet.Java");
        obs.setRecording(true);
    }
    
    private void addVisitedNode(String nodeName) {
    	//defSetSize
    	if (nodeName.equals("def1")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("def2")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("def9");
    	} else if (nodeName.equals("def3")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("def4")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("def9");	    		
    	} else if (nodeName.equals("def5")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("def6");	    		
    	} else if (nodeName.equals("def7")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("def9");	
    	} else if (nodeName.equals("def8")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("def9");	
    	//initSetArray	
    	} else if (nodeName.equals("init1")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("init2")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("init3")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    	} else if (nodeName.equals("init4")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("init6");	    		
    	} else if (nodeName.equals("init5")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("init6")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("init1");
   		//resizeArray
    	} else if (nodeName.equals("resz1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("resz2");    		
    	} else if (nodeName.equals("resz3")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("resz4");
    	} else if (nodeName.equals("resz5")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("resz4");
    	} else if (nodeName.equals("resz6")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("resz8");
    		if (obs.getLastVisited().equals("add6")) {obs.addVisitedNode("add7"); obs.removeLastVisited();}
    	} else if (nodeName.equals("resz7")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("resz8");
    		if (obs.getLastVisited().equals("add6")) {obs.addVisitedNode("add7"); obs.removeLastVisited();}
    	//binSearch
    	} else if (nodeName.equals("bsch1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("bsch2");    		
    	} else if (nodeName.equals("bsch3")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("bsch15");
    		if (obs.getLastVisited().equals("ctno3")) {obs.addVisitedNode("ctno3"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("rmv3")) {obs.addVisitedNode("rmv4"); obs.removeLastVisited();}
    	} else if (nodeName.equals("bsch4")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("bsch5")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("bsch15");	
    		if (obs.getLastVisited().equals("ctno3")) {obs.addVisitedNode("ctno3"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("rmv3")) {obs.addVisitedNode("rmv4"); obs.removeLastVisited();}
    	} else if (nodeName.equals("bsch6")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("bsch7")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("bsch8");    		
    	} else if (nodeName.equals("bsch9")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("bsch11");
    		obs.addVisitedNode("bsch6");
    	} else if (nodeName.equals("bsch10")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("bsch11");
    		obs.addVisitedNode("bsch6");
    	} else if (nodeName.equals("bsch12")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("bsch13")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("bsch15");
    		if (obs.getLastVisited().equals("ctno3")) {obs.addVisitedNode("ctno3"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("rmv3")) {obs.addVisitedNode("rmv4"); obs.removeLastVisited();}
    	} else if (nodeName.equals("bsch14")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("bsch15");
    		if (obs.getLastVisited().equals("ctno3")) {obs.addVisitedNode("ctno3"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("rmv3")) {obs.addVisitedNode("rmv4"); obs.removeLastVisited();}
    	//OrdSet(size)
    	} else if (nodeName.equals("oss1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("oss2");	
    		obs.addVisitedNode("oss3");
    		if (obs.getLastVisited().equals("uni1")) {obs.addVisitedNode("uni3"); obs.removeLastVisited();}
    	//OrdSet(array)
    	} else if (nodeName.equals("osv1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("osv2");
    	//getResizedTimes
    	} else if (nodeName.equals("grt1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("grt2");	
        //getActualSize
    	} else if (nodeName.equals("gas1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("gas2");	
        //getSetSize
    	} else if (nodeName.equals("gss1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("gss2");	
        //getSetLast
    	} else if (nodeName.equals("gsl1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("gsl2");
    		if (obs.getLastVisited().equals("eq1")) {obs.addVisitedNode("eq1"); obs.removeLastVisited();}
    		//else if (obs.getLastVisited().equals("eq2")) {obs.addVisitedNode("eq2"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("eq5")) {obs.addVisitedNode("eq5"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("ctno1")) {obs.addVisitedNode("ctno1"); obs.removeLastVisited();}
        //isEmpty
    	} else if (nodeName.equals("empt1")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("empt2")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("empt4");	
    	} else if (nodeName.equals("empt3")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("empt4");
        //getSetArray
    	} else if (nodeName.equals("gsa1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("gsa2");	
        //getSetElements
    	} else if (nodeName.equals("gse1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("gse2");
    	} else if (nodeName.equals("gse3")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("gse2");
    	} else if (nodeName.equals("gse4")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("gse5");    		
        //isOverflow
    	} else if (nodeName.equals("ovr1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("ovr2");	    		
    	//equals
    	} else if (nodeName.equals("eq1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    	} else if (nodeName.equals("eq2")) {
    		obs.addVisitedNode(nodeName);
    		//obs.addLastVisited(nodeName);
    		obs.addVisitedNode("eq10");	
    	} else if (nodeName.equals("eq3")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("eq4")) {
    		obs.addVisitedNode("eq3");
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("eq10");
    	} else if (nodeName.equals("eq5")) {
    		obs.addVisitedNode("eq3");
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    	} else if (nodeName.equals("eq6")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    		obs.addVisitedNode("eq7");
    	} else if (nodeName.equals("eq8")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("eq10");
    	} else if (nodeName.equals("eq9")) {
    		obs.addVisitedNode("eq5");	
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("eq10");	
    	} else if (nodeName.equals("eq11")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("eq5");	
   		//contains(n)
    	} else if (nodeName.equals("ctnn1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("ctnn2");
    	//contains(OrdSet)
    	} else if (nodeName.equals("ctno1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    	} else if (nodeName.equals("ctno2")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    		obs.addVisitedNode("ctno3");
    	} else if (nodeName.equals("ctno4")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("ctno6");
    	} else if (nodeName.equals("ctno5")) {
    		obs.addVisitedNode("ctno1");
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("ctno6");	
    	} else if (nodeName.equals("ctno7")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("ctno1");
    	//remove
    	} else if (nodeName.equals("rmv1")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("rmv2")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("rmv10");
    	} else if (nodeName.equals("rmv3")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    		obs.addVisitedNode("rmv4");
    	} else if (nodeName.equals("rmv5")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("rmv6")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("rmv5");
    	} else if (nodeName.equals("rmv7")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("rmv8");
    		obs.addVisitedNode("rmv10");
    	} else if (nodeName.equals("rmv9")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("rmv10");
    	//add
    	} else if (nodeName.equals("add1")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("add2")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("add11");
    		if (obs.getLastVisited().equals("init3")) {obs.addVisitedNode("init3"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni5")) {obs.addVisitedNode("uni5"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni7")) {obs.addVisitedNode("uni7"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni9")) {obs.addVisitedNode("uni9"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni13")) {obs.addVisitedNode("uni13"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni15")) {obs.addVisitedNode("uni15"); obs.removeLastVisited();}
    	} else if (nodeName.equals("add3")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("add4")) {
    		obs.addVisitedNode("add3");
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("add11");
    		if (obs.getLastVisited().equals("init3")) {obs.addVisitedNode("init3"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni5")) {obs.addVisitedNode("uni5"); obs.addVisitedNode("uni11"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni7")) {obs.addVisitedNode("uni7"); obs.addVisitedNode("uni11"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni9")) {obs.addVisitedNode("uni9"); obs.addVisitedNode("uni11"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni13")) {obs.addVisitedNode("uni13"); obs.addVisitedNode("uni12"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni15")) {obs.addVisitedNode("uni15"); obs.addVisitedNode("uni14"); obs.removeLastVisited();}
    	} else if (nodeName.equals("add5")) {
    		obs.addVisitedNode("add3");
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("add6")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    		obs.addVisitedNode("add7");
    	} else if (nodeName.equals("add8")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("add11"); 
    		if (obs.getLastVisited().equals("init3")) {obs.addVisitedNode("init3"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni5")) {obs.addVisitedNode("uni5"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni7")) {obs.addVisitedNode("uni7"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni9")) {obs.addVisitedNode("uni9"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni13")) {obs.addVisitedNode("uni13"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni15")) {obs.addVisitedNode("uni15"); obs.removeLastVisited();}
    	} else if (nodeName.equals("add9")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("add10");
    		obs.addVisitedNode("add11"); 
    		if (obs.getLastVisited().equals("init3")) {obs.addVisitedNode("init3"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni5")) {obs.addVisitedNode("uni5"); obs.addVisitedNode("uni11"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni7")) {obs.addVisitedNode("uni7"); obs.addVisitedNode("uni11"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni9")) {obs.addVisitedNode("uni9"); obs.addVisitedNode("uni11"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni13")) {obs.addVisitedNode("uni13"); obs.addVisitedNode("uni12"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("uni15")) {obs.addVisitedNode("uni15"); obs.addVisitedNode("uni14"); obs.removeLastVisited();}
    	//elementAt
    	} else if (nodeName.equals("elt1")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("elt2")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("elt4");
    		if (obs.getLastVisited().equals("eq6")) {obs.addVisitedNode("eq7"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("ctno2")) {obs.addVisitedNode("ctno3"); obs.removeLastVisited(); obs.addLastVisited("ctno3");}
    	} else if (nodeName.equals("elt3")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("elt4"); 
    		if (obs.getLastVisited().equals("eq6")) {obs.addVisitedNode("eq7"); obs.removeLastVisited();}
    		else if (obs.getLastVisited().equals("ctno2")) {obs.removeLastVisited(); obs.addLastVisited("ctno3");}
    	//make_a_free_slot
    	} else if (nodeName.equals("mks1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("mks2");
    	} else if (nodeName.equals("mks3")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("mks2");
    	} else if (nodeName.equals("mks4")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("mks5");      		
    	//union
    	} else if (nodeName.equals("uni1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    		obs.addVisitedNode("uni2");
    		obs.addVisitedNode("uni3");
    	} else if (nodeName.equals("uni4")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("uni5")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    	} else if (nodeName.equals("uni6")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("uni7")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    	} else if (nodeName.equals("uni8")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("uni9")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    	} else if (nodeName.equals("uni10")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("uni19");
    	} else if (nodeName.equals("uni11")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("uni3");  
    	} else if (nodeName.equals("uni12")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("uni13")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName);
    	} else if (nodeName.equals("uni14")) {
    		obs.addVisitedNode(nodeName);
    	} else if (nodeName.equals("uni15")) {
    		obs.addVisitedNode(nodeName);
    		obs.addLastVisited(nodeName); 
    	} else if (nodeName.equals("uni16")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("uni17");
    		obs.addVisitedNode("uni19");
    	} else if (nodeName.equals("uni18")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("uni17");  
    		obs.addVisitedNode("uni19");  
    	//toString
    	} else if (nodeName.equals("str1")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("str2");
    	} else if (nodeName.equals("str3")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("str2");
    	} else if (nodeName.equals("str4")) {
    		obs.addVisitedNode(nodeName);
    		obs.addVisitedNode("str5");       		
    		
    	} else {
    		obs.addVisitedNode(nodeName);
    	}
    }
}