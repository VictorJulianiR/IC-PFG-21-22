// This is mutant program.
// Author : ysma

public class OrdSet
{

    public static final int min_set_size = 4;

    public static final int max_set_size = 16;

    public static final int max_accepted_resizes = 2;

    private int _set_size;

    private int _resized_times;

    private int _last;

    private int[] _set;

    private boolean _overflow;

    private int defSetSize( int n )
    {
        int mod;
        if (n <= min_set_size) {
            return min_set_size;
        }
        if (n >= max_set_size) {
            return max_set_size;
        }
        mod = n / min_set_size;
        if (mod * min_set_size == n) {
            return n;
        } else {
            return (mod + 1) * min_set_size;
        }
    }

    private void initSetArray( int[] v )
    {
        int k;
        for (k = 0; k < v.length; k++) {
            try {
                if (!_overflow) {
                    this.add( v[k] );
                }
            } catch ( OverflowException e ) {
                System.out.println( "Array is too big." );
            }
        }
    }

    private void resizeArray()
    {
        int new_size = _set_size + min_set_size;
        if (new_size <= max_set_size && _resized_times < max_accepted_resizes) {
            int[] _new_set = new int[new_size];
            for (int k = 0; k < _last + 1; k++) {
                _new_set[k] = _set[k];
            }
            _set_size = new_size;
            _set = _new_set;
            _resized_times++;
        } else {
            _overflow = true;
        }
    }

    private int binSearch( int[] a, int nElts, int x )
    {
        int i = 0;
        int j = nElts - 1;
        int m = 0;
        if (j < 0) {
            return -1;
        }
        if (a[j] < x) {
            return -1;
        }
        while (i < j) {
            m = (i + j) / 2;
            if (x > a[m]) {
                i = m + 1;
            } else {
                j = m;
            }
        }
        if (x == a[i]) {
            return i;
        }
        return -1;
    }

    public OrdSet( int size )
    {
        _set_size = defSetSize( size );
        _set = new int[_set_size];
        _last = -1;
        _resized_times = 0;
        _overflow = false;
    }

    public OrdSet( int[] v )
    {
        this( v.length );
        initSetArray( v );
    }

    public int getResizedTimes()
    {
        return _resized_times;
    }

    public int getActualSize()
    {
        return _last + 1;
    }

    public int getSetSize()
    {
        return _set_size;
    }

    public int getSetLast()
    {
        return _last;
    }

    public boolean isEmpty()
    {
        if (_last < 0) {
            return true;
        }
        return false;
    }

    private int[] getSetArray()
    {
        return _set;
    }

    public int[] getSetElements()
    {
        int[] elts = new int[_last + 1];
        for (int i = 0; i <= _last; i++) {
            elts[i] = _set[i];
        }
        return elts;
    }

    public boolean isOverflow()
    {
        return _overflow;
    }

    public int equals( OrdSet x )
    {
        int k;
        int n;
        if (x.getSetLast() != _last) {
            return _last - x.getSetLast();
        }
        if (isEmpty() && x.isEmpty()) {
            return 0;
        }
        for (k = 0, n = 0; n < x.getSetLast() + 1; n++) {
            k = x.elementAt( n );
            if (k != _set[n]) {
                return 1;
            }
        }
        return 0;
    }

    public boolean contains( int n )
    {
        return binSearch( _set, _last + 1, n ) >= 0;
    }

    public boolean contains( OrdSet x )
    {
        int k;
        int n;
        for (n = 0, k = 0; n < x.getSetLast() + 1; n++) {
            k = x.elementAt( n );
            if (binSearch( _set, _last + 1, k ) < 0) {
                return false;
            }
        }
        return true;
    }

    public boolean remove( int val )
        throws OverflowException
    {
        if (_overflow) {
            throw new OverflowException();
        }
        int where = binSearch( _set, _last + 1, val );
        if (where >= 0) {
            int k;
            for (k = where; k++ < _last; k++) {
                _set[k] = _set[k + 1];
            }
            _last--;
            return true;
        } else {
            return false;
        }
    }

    public void add( int n )
        throws OverflowException
    {
        if (_overflow) {
            throw new OverflowException();
        }
        if (this.contains( n )) {
            return;
        }
        if (_last + 1 >= _set_size) {
            this.resizeArray();
            if (_overflow) {
                throw new OverflowException();
            }
        }
        int i = make_a_free_slot( n );
        _set[i] = n;
        _last++;
    }

    public int elementAt( int where )
    {
        if (where < 0 || where > _last) {
            System.err.println( "Out of bound element: " + where );
            return -1;
        }
        return _set[where];
    }

    private int make_a_free_slot( int n )
    {
        int where = _last + 1;
        while (where - 1 >= 0 && _set[where - 1] > n) {
            _set[where] = _set[where - 1];
            where--;
        }
        return where;
    }

    public OrdSet union( OrdSet s2 )
    {
        int[] set1 = this.getSetArray();
        int[] set2 = s2.getSetArray();
        int size1 = this.getSetLast() + 1;
        int size2 = s2.getSetLast() + 1;
        OrdSet set = new OrdSet( size1 + size2 );
        int lb1 = 0;
        int lb2 = 0;
        int pos = 0;
        try {
            while (lb1 < size1 && lb2 < size2) {
                if (set1[lb1] < set2[lb2]) {
                    set.add( set1[lb1] );
                    pos = pos + 1;
                    lb1 = lb1 + 1;
                } else {
                    if (set2[lb2] < set1[lb1]) {
                        set.add( set2[lb2] );
                        pos = pos + 1;
                        lb2 = lb2 + 1;
                    } else {
                        if (set1[lb1] == set2[lb2]) {
                            set.add( set2[lb2] );
                            pos = pos + 1;
                            lb1 = lb1 + 1;
                            lb2 = lb2 + 1;
                        } else {
                            System.exit( 1 );
                        }
                    }
                }
            }
            while (lb1 < size1) {
                set.add( set1[lb1] );
                pos = pos + 1;
                lb1 = lb1 + 1;
            }
            while (lb2 < size2) {
                set.add( set2[lb2] );
                pos = pos + 1;
                lb2 = lb2 + 1;
            }
            set._last = pos - 1;
        } catch ( OverflowException e ) {
            System.out.println( "The union caused an overflow; the union size exceeds the maximum set size" );
        }
        return set;
    }

    public java.lang.String toString()
    {
        java.lang.String output = "";
        int k = 0;
        for (k = 0; k <= _last; k++) {
            output += "" + _set[k] + " ";
        }
        return output;
    }

}
