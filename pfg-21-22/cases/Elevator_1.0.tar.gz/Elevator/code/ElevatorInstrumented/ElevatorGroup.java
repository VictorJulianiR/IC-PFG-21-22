import java.util.HashMap;
import java.util.Vector;

/*
 * This class represents the facade of the Elevator system. 
 * It is used to create the system, start its threads and shutdown the system.
 */
public class ElevatorGroup{

	public static ElevatorGroup theGroup;
	public static int numFloors;
	public static int numElevators;
	public static Thread[] elevatorThread;
	public static boolean[] threadStarted;
	public static Elevator[] e;
	public static FloorInterface[] fli;
	public static Floor[] floor;
	public static ElevatorInterface[] ebi;
	public static ArrivalSensor[] sensor;

	private static Observer obs;
	/*
	 * @return the singleton instance of ElevatorGroup. Only one system
	 * runs at a time.
	 */
	public static ElevatorGroup getGroup(int el, int fl) {
		if (theGroup == null) {
			theGroup = new ElevatorGroup(el, fl);
			addVisitedNode("gtg2");
			return theGroup;
		} else {
			addVisitedNode("gtg3");
			return theGroup;
		}
	}

	/*
	 * Constructor
	 *
	 * @param number of elevators, number of floors in the system
	 */
	  private ElevatorGroup(int el, int fl) {
		  if (obs == null) obs = new Observer();
		  this.addVisitedNode("elg1");
		  numFloors = fl;
		  numElevators = el;
		  elevatorThread = new Thread[numElevators];
		  threadStarted = new boolean[numElevators];
		  e = new Elevator[numElevators];
		  floor = new Floor[numFloors];
		  sensor = new ArrivalSensor[numFloors];
		  ebi = new ElevatorInterface[numElevators]; 
		  fli = new FloorInterface[numFloors];
	  }

	  /*
	   * This method starts one elevator's thread
	   */
	  public void startThread(int threadNum) {
		    addVisitedNode("stt1");
		    //System.out.println("Trying to start thread " + threadNum);
		    if(threadStarted[threadNum] == false){
		    	addVisitedNode("stt2");
				//System.out.println("Running Thread #"+threadNum);
				elevatorThread[threadNum].start();
				threadStarted[threadNum] = true;
		    }
		    addVisitedNode("stt3");
	  }

	  /*
	   * This method shutdown the system by killing its threads
	   */
	  public void stopGroup() {
		  addVisitedNode("stg1");
		  //System.out.println("Shutting down the system.");
		  for (int i = 0; i < numElevators; i++) {
			  addVisitedNode("stg2");
			  if(threadStarted[i] == true) {
				  addVisitedNode("stg3");
				  threadStarted[i] = false;
				  e[i].turnOff();
			  }
			  addVisitedNode("stg4");
		  }
		  addVisitedNode("stg5");
		  Floor.removeFloors();
		  Elevator.removeAllElevators();
		  theGroup = null;
	  }
	  
	  /*
	   * This method creates the objects in the system (elevators, floors, sensors ...)
	   * and starts the elevators threads
	   */
		public void startGroup() {
			addVisitedNode("str1");
			for (int i = 0; i < numFloors ; i++) {
				addVisitedNode("str2");
				//System.out.println(numFloors + " - " + i);
				floor[i] = new Floor(i);
				sensor[i] = new ArrivalSensor(floor[i]);
				fli[i] = new FloorInterface(sensor[i]);
			}
			addVisitedNode("str3");
			for (int i = 0; i < numElevators; i++) {
				addVisitedNode("str4");
				e[i] = new Elevator();
				elevatorThread[i] = new Thread(e[i],"Elevator Thread "+i);
				ebi[i] = new ElevatorInterface(e[i]);
				theGroup.startThread(i);
			}
			addVisitedNode("str5");
		}

		/*
		 * Simulates motor moving by sleeping the system for 2 seconds
		 */
		public void motorMoving(int elevatorID, int direction, int currentFloor) {
			try {
				ElevatorGroup.elevatorDisplay(elevatorID + 1, "Moving from floor " +(currentFloor)+" in direction "+ direction); //removed +1 from currentfloor
				ElevatorGroup.elevatorDisplay(elevatorID + 1, "Motor moving, sleeping to cause delay....");
				Thread.sleep(2000);
				addVisitedNode("mmg1");
			} catch (Exception e) {
				addVisitedNode("mmg2");
				System.out.println("Exception in motorMoving.");
			}	
			addVisitedNode("mmg3");
			fli[currentFloor].stopAtThisFloor(elevatorID, currentFloor+direction);
		}
		
		/*
		 * Used to show messages about status of elevators
		 */
		public static void elevatorDisplay(int eid, String message) {
			addVisitedNode("eld1");
			System.out.println("Elevator " + eid + ": " + message);
		}
		
		/*
		 * @return floor interface associated with a specific floor
		 */
		public FloorInterface getFloorInterface(int floorID) {
			addVisitedNode("gfi1");
			if (floorID >=0 && floorID < ElevatorGroup.numFloors) {
				addVisitedNode("gfi2");
				return fli[floorID];
			}
			else {
				addVisitedNode("gfi3");
				System.out.println("No Such floor.");
				return null;
			}
		}
		
		/*
		 * @return elevator interface associated with a specific elevator
		 */
		public ElevatorInterface getElevatorInterface(int elevatorID) {
			addVisitedNode("gei1");
			if (elevatorID >=0 && elevatorID < ElevatorGroup.numElevators) {
				addVisitedNode("gei2");
				return ebi[elevatorID];
			}
			else {
				addVisitedNode("gei3");
				System.out.println("No Such floor.");
				return null;
			}
		}
		
		   public static String getReport() {
			   	if (obs.isRecording()) {
			   		return obs.getReport();
			   	} else {
			   		return "";
			   	}
		   }
			   
		   public static void startRecording() {
			   	// Setup the observer here.
			   	HashMap nodeList = new HashMap();
			   	
			   	nodeList.put("gtg1","getGroup, Line 24: if (theGroup == null) {");   	
			   	nodeList.put("gtg2","getGroup, Line 25: theGroup = new ElevatorGroup(el, fl);");
			   	nodeList.put("gtg3","getGroup, Line 28: return theGroup;");
			   	
			   	nodeList.put("elg1","Constructor, Line 37: numFloors = fl;");
			   	nodeList.put("elg2","Constructor, Line 45: fli = new FloorInterface[numFloors];");
			   	   	
			   	nodeList.put("stt1","startThread, Line 54: if(threadStarted[threadNum] == false){");
			   	nodeList.put("stt2","startThread, Line 55: System.out.println(Running Thread #+threadNum);");
			   	nodeList.put("stt3","startThread, Line 58: }");
			   	
			   	nodeList.put("stg1","stopGroup, Line 66: for (int i = 0; i < numElevators; i++) {");			   	
			   	nodeList.put("stg2","stopGroup, Line 67: if(threadStarted[i] == true) {");   	
			   	nodeList.put("stg3","stopGroup, Line 68: threadStarted[i] = false;");
			   	nodeList.put("stg4","stopGroup, Line 71: }");
			   	nodeList.put("stg5","stopGroup, Line 74: theGroup = null;");
			   	
			   	nodeList.put("str1","startGroup, Line 80: for (int i = 0; i < numFloors ; i++) {");
			   	nodeList.put("str2","startGroup, Line 81: floor[i] = new Floor(i);");			   	
			   	nodeList.put("str3","startGroup, Line 85: for (int i = 0; i < numElevators; i++) {");   	
			   	nodeList.put("str4","startGroup, Line 86: e[i] = new Elevator();");
			   	nodeList.put("str5","startGroup, Line 92: }");
			   	
			   	nodeList.put("mmg1","motorMoving, Line 100: ElevatorGroup.elevatorDisplay(elevatorID + 1, Moving from floor  +(currentFloor)+ in direction + direction);");			   	
			   	nodeList.put("mmg2","motorMoving, Line 104: System.out.println(Exception in motorMoving.);");   	
			   	nodeList.put("mmg3","motorMoving, Line 106: fli[currentFloor].stopAtThisFloor(elevatorID, currentFloor+direction);");		   	
			   	
			   	nodeList.put("eld1","elevatorDisplay, Line 112: System.out.println(Elevator  + eid + :  + message);");
			   	nodeList.put("eld2","elevatorDisplay, Line 113: }");	
			   	
			   	nodeList.put("gfi1","getFloorInterface, Line 119: if (floorID >=0 && floorID < ElevatorGroup.numFloors)");
			   	nodeList.put("gfi2","getFloorInterface, Line 120: return fli[floorID];");			   	
			   	nodeList.put("gfi3","getFloorInterface, Line 122: System.out.println(No Such floor.);"); 
			   			   	
			   	nodeList.put("gei1","getElevatorInterface, Line 131: if (elevatorID >=0 && elevatorID < ElevatorGroup.numElevators)");
			   	nodeList.put("gei2","getElevatorInterface, Line 132: return ebi[elevatorID];");			   	
			   	nodeList.put("gei3","getElevatorInterface, Line 134: System.out.println(No Such floor.);"); 			   	
			   	
			   	Vector edgeList = new Vector();
				   	
			   	edgeList.add("gtg1");
			   	edgeList.add("gtg2");
			   	
			   	edgeList.add("gtg1");
			   	edgeList.add("gtg3");

			   	edgeList.add("elg1");
			   	edgeList.add("elg2");

			   	edgeList.add("stt1");
			   	edgeList.add("stt2");

			   	edgeList.add("stt2");
			   	edgeList.add("stt3");

			   	edgeList.add("stt1");
			   	edgeList.add("stt3");
			   	
			   	edgeList.add("stg1");
			   	edgeList.add("stg2");

			   	edgeList.add("stg1");
			   	edgeList.add("stg5");

			   	edgeList.add("stg2");
			   	edgeList.add("stg3");

			   	edgeList.add("stg2");
			   	edgeList.add("stg4");

			   	edgeList.add("stg3");
			   	edgeList.add("stg4");

			   	edgeList.add("stg4");
			   	edgeList.add("stg1");
			   	
			   	edgeList.add("str1");
			   	edgeList.add("str2");
			   	
			   	edgeList.add("str2");
			   	edgeList.add("str1");

			   	edgeList.add("str1");
			   	edgeList.add("str3");

			   	edgeList.add("str3");
			   	edgeList.add("str4");

			   	edgeList.add("str4");
			   	edgeList.add("str3");

			   	edgeList.add("str3");
			   	edgeList.add("str5");

			   	edgeList.add("mmg1");
			   	edgeList.add("mmg2");

			   	edgeList.add("mmg1");
			   	edgeList.add("mmg3");

			   	edgeList.add("mmg2");
			   	edgeList.add("mmg3");

			   	edgeList.add("eld1");
			   	edgeList.add("eld2");
			   	
			   	edgeList.add("gfi1");
			   	edgeList.add("gfi2");

			   	edgeList.add("gfi1");
			   	edgeList.add("gfi3");

			   	edgeList.add("gei1");
			   	edgeList.add("gei2");
			   	
			   	edgeList.add("gei1");
			   	edgeList.add("gei3");

			   	obs = new Observer(nodeList, null, edgeList, "elg1", "ElevatorGroup Class");
			   	obs.setRecording(true);
		   }

		   private static void addVisitedNode(String nodename) {
			   	if (obs == null || !obs.isRecording()) return;
			   	
			   	// Adding nodes here.
			   	if (nodename.equals("gtg2")) {
			   		obs.addVisitedNode("gtg1");
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("gtg3")) {
			   		obs.addVisitedNode("gtg1");
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("elg1")) {
			   		obs.addVisitedNode(nodename);
			   		obs.addVisitedNode("elg2");
			   	} else if (nodename.equals("stt1")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("stt2")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("stt3")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("stg1")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("stg2")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("stg3")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("stg4")) {
			   		obs.addVisitedNode(nodename);
			   		obs.addVisitedNode("stg1");
			   	} else if (nodename.equals("stg5")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("str1")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("str2")) {
			   		obs.addVisitedNode(nodename);
			   		obs.addVisitedNode("str1");
			   	} else if (nodename.equals("str3")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("str4")) {
			   		obs.addVisitedNode(nodename);
			   		obs.addVisitedNode("str3");
			   	} else if (nodename.equals("str5")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("mmg1")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("mmg2")) {
			   		obs.addVisitedNode("mmg1");
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("mmg3")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("eld1")) {
			   		obs.addVisitedNode(nodename);
			   		obs.addVisitedNode("eld2");
			   	} else if (nodename.equals("gfi1")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("gfi2")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("gfi3")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("gei1")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("gei2")) {
			   		obs.addVisitedNode(nodename);
			   	} else if (nodename.equals("gei3")) {
			   		obs.addVisitedNode(nodename);
			   	} else {
			   		obs.addVisitedNode(nodename);
			   	}
		   }
		
}//end class