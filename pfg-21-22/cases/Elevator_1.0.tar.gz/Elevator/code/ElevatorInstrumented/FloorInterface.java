import java.util.HashMap;
import java.util.Vector;

/**
 * This class represents the Input Interface for interaction with the
 * floor requests. When the user requests an up or down going elevator
 * the messages are sent to this class which calls methods from Floor 
 * Control to deal with the request.
 */

public class FloorInterface {

	FloorControl fc;
	ArrivalSensor sensor;
	private static Observer obs;
	
	/*
	 * Constructor
	 */
	public FloorInterface(ArrivalSensor sensor) {
		if (obs == null) obs = new Observer();
		this.addVisitedNode("fli1");
		this.sensor = sensor; //a sensor that determines if an elevator needs to stop when reaching a floor
	}
	
  /*
   * Makes a request for an elevator to stop at this floor,
   * heading up. Triggers RequestElevator Use Case for "up" direction.
   *
   * @return the best elevator that can provide the service
   */
    public Elevator requestUp(int floorID) {
    	this.addVisitedNode("rqu1");
    	Elevator e = null;
    	if (floorID >=0 && floorID < ElevatorGroup.numFloors) {
    		this.addVisitedNode("rqu2");
	    	fc = new FloorControl(sensor);
	    	e = fc.requestUp(floorID);
	    	fc = null;
    	} else {
    		this.addVisitedNode("rqu3");
    		System.out.println("No such floor " + floorID + ".");
    	}
    	return e;
    }

  /*
   * Makes a request for an elevator to stop at this floor,
   * heading up. Triggers RequestElevator Use Case for "Down" direction.
   *
   * @return the best elevator that can provide the service
   */
    public Elevator requestDown(int floorID) {
    	this.addVisitedNode("rqd1");
    	Elevator e = null;
    	if (floorID >=0 && floorID < ElevatorGroup.numFloors) {
    		this.addVisitedNode("rqd2");
	    	fc = new FloorControl(sensor);
	    	e = fc.requestDown(floorID);
	    	fc = null;
    	} else {
    		this.addVisitedNode("rqd3");
    		System.out.println("No such floor " + floorID + ".");
    	}
    	return e;
    }
    
    /*
     * When this method is called, the sensor signals an approaching
     * elevator to stop, if a stop has been requested on that floor.
     *
     */
      public void stopAtThisFloor(int elevatorID, int floorID) {
    	  this.addVisitedNode("saf1");
    	  fc = new FloorControl(sensor);
    	  fc.stopAtThisFloor(elevatorID, floorID);
    	  fc = null;
      }
      
      /*
       * @return the floor associated with this interface
       */
      public Floor getFloor() {
    	  this.addVisitedNode("gfl1");
    	  return sensor.getTheFloor();
      }
      
      public static String getReport() {
  	   	if (obs.isRecording()) {
  	   		return obs.getReport();
  	   	} else {
  	   		return "";
  	   	}
     }
  	   
     public static void startRecording() {
  	   	// Setup the observer here.
  	   	HashMap nodeList = new HashMap();
  	   	
  	   	nodeList.put("fli1","Constructor, Line 17: this.sensor = sensor;");   	
  	   	nodeList.put("fli2","Constructor, Line 18: }");
  	  
	  	nodeList.put("rqu1","requestUp, Line 28: if (floorID >=0 && floorID < ElevatorGroup.numFloors) {");
	  	nodeList.put("rqu2","requestUp, Line 29: fc = new FloorControl(sensor);");
	  	nodeList.put("rqu3","requestUp, Line 33: System.out.println(No such floor  + floorID + .);");
	  	nodeList.put("rqu4","requestUp, Line 35: }");
	  	
	  	nodeList.put("rqd1","requestDown, Line 46: if (floorID >=0 && floorID < ElevatorGroup.numFloors) {");
	  	nodeList.put("rqd2","requestDown, Line 47: fc = new FloorControl(sensor);");
	  	nodeList.put("rqd3","requestDown, Line 51: System.out.println(No such floor  + floorID + .);");
	  	nodeList.put("rqd4","requestDown, Line 53: }");
	  	
	  	nodeList.put("saf1","stopAtThisFloor, Line 62: fc = new FloorControl(sensor);");
	  	nodeList.put("saf2","stopAtThisFloor, Line 65: }");
	  	
	  	nodeList.put("gfl1","getFloor, Line 71: return sensor.getTheFloor();");
	  	nodeList.put("gfl2","getFloor, Line 72: }");
	  	
  	   	Vector edgeList = new Vector();
  		   	
  	   	edgeList.add("fli1");
  	   	edgeList.add("fli2");
  	   	
  	   	edgeList.add("rqu1");
	   	edgeList.add("rqu2");
  		   	
  	   	edgeList.add("rqu1");
	   	edgeList.add("rqu3");
  		   	
  	   	edgeList.add("rqu2");
	   	edgeList.add("rqu4");
  		   	
  	   	edgeList.add("rqu3");
	   	edgeList.add("rqu4");
  		   	
  	   	edgeList.add("rqd1");
	   	edgeList.add("rqd2");
  		   	
  	   	edgeList.add("rqd1");
	   	edgeList.add("rqd3");
  		   	
  	   	edgeList.add("rqd2");
	   	edgeList.add("rqd4");
  		   	
  	   	edgeList.add("rqd3");
	   	edgeList.add("rqd4");
  		   	
  	   	edgeList.add("saf1");
	   	edgeList.add("saf2");
  		   	
  	   	edgeList.add("gfl1");
	   	edgeList.add("gfl2");
  		   	
  	   	obs = new Observer(nodeList, null, edgeList, "fli1", "FloorInterface Class");
  	   	obs.setRecording(true);
     }

     private void addVisitedNode(String nodename) {
  	   	if (obs == null || !obs.isRecording()) return;
  	   	
  	   	// Adding nodes here.
  	   	if (nodename.equals("fli1")) {
  	   		obs.addVisitedNode(nodename);
  	   		obs.addVisitedNode("fli2");
  	   	} else if (nodename.equals("rqu1")) {
  	   		obs.addVisitedNode(nodename);
  	   	} else if (nodename.equals("rqu2")) {
  	   		obs.addVisitedNode(nodename);
  	   		obs.addVisitedNode("rqu4");
  	   	} else if (nodename.equals("rqu3")) {
  	   		obs.addVisitedNode(nodename);
  	   		obs.addVisitedNode("rqu4");
  	   	} else if (nodename.equals("rqd1")) {
  	   		obs.addVisitedNode(nodename);
  	   	} else if (nodename.equals("rqd2")) {
  	   		obs.addVisitedNode(nodename);
  	   		obs.addVisitedNode("rqd4");
  	   	} else if (nodename.equals("rqd3")) {
  	   		obs.addVisitedNode(nodename);
  	   		obs.addVisitedNode("rqd4");
  	   	} else if (nodename.equals("saf1")) {
  	   		obs.addVisitedNode(nodename);
  	   		obs.addVisitedNode("saf2");
  	   	} else if (nodename.equals("gfl1")) {
  	   		obs.addVisitedNode(nodename);
  	   		obs.addVisitedNode("gfl2");
 	   	} else {
  	   		obs.addVisitedNode(nodename);
  	   	}
     }
}

