import java.util.HashMap;
import java.util.Vector;

/**
 * This is the ArrivalSensor Class. It consists of a method that communicates * with the Elevator class to determine if an elevator needs to stop.
 */

public class ArrivalSensor {

	/*
	 * The elevator reaching a new floor
	 */
	private Elevator elevator;
	private static Observer obs;

	/*
	 * The floor to which the sensor is associated
	 */
	private Floor floor;

	/*
	 * Constructor that initializes the reference to Floor entity
	 */
    public ArrivalSensor(Floor floor){
    	if (obs == null) obs = new Observer();
    	this.addVisitedNode("ars1");
    	this.floor = floor;
    }

  /*
   * When this method is called, the sensor signals an approaching
   * elevator to stop, if a stop has been requested on that floor.
   *
   */
   public boolean stopAtThisFloor(int elevatorID) {
	   boolean stopped = false;
	   this.addVisitedNode("stf1");
	   elevator = Elevator.selectElevator(elevatorID);
    
	   stopped = elevator.notifyNewFloor(floor);
	   return stopped;
   }

  /*
   * @return the reference to the floor associated with the sensor
   */
   public Floor getTheFloor(){
	   this.addVisitedNode("gtf1");
	   return floor;
   }

   public static String getReport() {
   	if (obs.isRecording()) {
   		return obs.getReport();
   	} else {
   		return "";
   	}
   }
   
   public static void startRecording() {
   	// Setup the observer here.
   	HashMap nodeList = new HashMap();
   	String startNode = "ars1";
   	
   	nodeList.put("ars1","Constructor, Line 22: this.floor = floor;");
   	nodeList.put("ars2","Constructor, Line 23: }");
   	
   	nodeList.put("stf1","stopAtThisFloor, Line 32: elevator = Elevator.selectElevator(elevatorID);");
   	nodeList.put("stf2","stopAtThisFloor, Line 36: }");
   	
   	nodeList.put("gtf1","getTheFloor, Line 42: return floor;");
   	nodeList.put("gtf2","getTheFloor, Line 43: }");
   	
   	Vector edgeList = new Vector();
   	
   	edgeList.add("ars1");
   	edgeList.add("ars2");
   	
   	edgeList.add("stf1");
   	edgeList.add("stf2");
   	
   	edgeList.add("gtf1");
   	edgeList.add("gtf2");
   	
   	obs = new Observer(nodeList, null, edgeList, startNode, "ArrivalSensor Class");
   	obs.setRecording(true);
   }

   private void addVisitedNode(String nodename) {
   	if (obs == null || !obs.isRecording()) return;
   	
   	// Adding nodes here.
   	if (nodename.equals("ars1")) {
   		obs.addVisitedNode(nodename);
   		obs.addVisitedNode("ars2");
   	} else if (nodename.equals("stf1")) {
   		obs.addVisitedNode(nodename);
   		obs.addVisitedNode("stf2");
   	} else if (nodename.equals("gtf1")) {
   		obs.addVisitedNode(nodename);
   		obs.addVisitedNode("gtf2");
   	} else {
   		obs.addVisitedNode(nodename);
   	}
   }

}
