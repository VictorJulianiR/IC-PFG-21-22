import java.util.HashMap;
import java.util.Vector;

/*
 * This class controls floors and their sensors. Whenever a request 
 * has been made on a floor, the request is passed by the control 
 * instance to the corresponding floor.
 * 
 */
public class FloorControl {

	private Floor floor;
	private ArrivalSensor sensor;
	private Elevator elevator;
	private static Observer obs;

	public FloorControl (ArrivalSensor sensor) {
		if (obs == null) obs = new Observer();
		this.addVisitedNode("flc1");
		this.sensor = sensor;
	}
	
  /*
   * Makes a request for an elevator to stop at this floor,
   * heading up. Executes RequestElevator Use Case for "up" direction.
   *
   * @ return the best elevator that can provide the service
   */
    public Elevator requestUp(int floorID) {
    	 this.addVisitedNode("rqu1");
	     floor = Floor.selectFloor(floorID);
	     Elevator e = floor.requestUp();
	     return e;
    }

  /*
   * Makes a request for an elevator to stop at this floor,
   * heading up. Executes RequestElevator Use Case for "Down" direction.
   * 
   * @ return the best elevator that can provide the service
   */
    public Elevator requestDown(int floorID) {
    	 this.addVisitedNode("rqd1");
	     floor = Floor.selectFloor(floorID);
	     Elevator e = floor.requestDown();
	     return e;
    }
    
    /*
     * When this method is called, the sensor signals an approaching
     * elevator to stop, if a stop has been requested on that floor.
     *
     */
     public void stopAtThisFloor(int elevatorID, int floorID) {
    	 //this.addVisitedNode("saf1");
       elevator = Elevator.selectElevator(elevatorID);
       floor = Floor.selectFloor(floorID);
       sensor = floor.getSensor();
       boolean stop = sensor.stopAtThisFloor(elevatorID);
       this.addVisitedNode("saf2");
       if(stop == true){
    	   this.addVisitedNode("saf3");
          if(floor.getFloorID() == 0){
        	  this.addVisitedNode("saf4");
        	  floor.requestUpServiced();
          } else {
        	  this.addVisitedNode("saf5");
        	  if(floor.getFloorID() == Floor.getNoFloors()-1) {
        		  this.addVisitedNode("saf6");
        		  floor.requestDownServiced();
        	  } else {
        		  this.addVisitedNode("saf7");
        		  if(elevator.getDirection()  == -1) {
        			  this.addVisitedNode("saf8");
        			  if(floor.requestDownMade() == true) {
        				  this.addVisitedNode("saf9");
        				  floor.requestDownServiced();
        			  } 
        		  } else {
        			  this.addVisitedNode("saf10");
        			  if(elevator.getDirection() == 1) {
        				  this.addVisitedNode("saf11");
        				  if(floor.requestUpMade() == true) {
        					  this.addVisitedNode("saf12");
        					  floor.requestUpServiced();
        				  }
        			  }
        		  }
        	  }
          }
       }
       this.addVisitedNode("saf13");
     }
     
     public static String getReport() {
 	   	if (obs.isRecording()) {
 	   		return obs.getReport();
 	   	} else {
 	   		return "";
 	   	}
    }
 	   
    public static void startRecording() {
 	   	// Setup the observer here.
 	   	HashMap nodeList = new HashMap();
 	   	
 	   	nodeList.put("flc1","Constructor, Line 14: this.sensor = sensor;");   	
 	   	nodeList.put("flc2","Constructor, Line 15: }");
 	   
 	   	nodeList.put("rqu1","requestUp, Line 24: floor = Floor.selectFloor(floorID);");
 	   	nodeList.put("rqu2","requestUp, Line 27: }");

 	   	nodeList.put("rqd1","requestDown, Line 36: floor = Floor.selectFloor(floorID);");
 	   	nodeList.put("rqd2","requestDown, Line 39: }");

 	   	//nodeList.put("saf1","stopAtThisFloor, Line 48: elevator = Elevator.selectElevator(elevatorID);");
 	   	nodeList.put("saf2","stopAtThisFloor, Line 53: if(stop == true){");
 	   	nodeList.put("saf3","stopAtThisFloor, Line 54: if(floor.getFloorID() == 0){");
 	   	nodeList.put("saf4","stopAtThisFloor, Line 55: floor.requestUpServiced();");
 	   	nodeList.put("saf5","stopAtThisFloor, Line 56: } else if(floor.getFloorID() == Floor.getNoFloors()-1) {");
 	   	nodeList.put("saf6","stopAtThisFloor, Line 57: floor.requestDownServiced();");
 	   	nodeList.put("saf7","stopAtThisFloor, Line 59: if(elevator.getDirection()  == -1) {");
 	   	nodeList.put("saf8","stopAtThisFloor, Line 60: if(floor.requestDownMade() == true) {");
 	   	nodeList.put("saf9","stopAtThisFloor, Line 61: floor.requestDownServiced();");
 	   	nodeList.put("saf10","stopAtThisFloor, Line 63: else if(elevator.getDirection() == 1) {");
 	   	nodeList.put("saf11","stopAtThisFloor, Line 64: if(floor.requestUpMade() == true) {");
 	   	nodeList.put("saf12","stopAtThisFloor, Line 65: floor.requestUpServiced();");
 	   	nodeList.put("saf13","stopAtThisFloor, Line 69: }");

 	   	Vector edgeList = new Vector();
 		   	
 	   	edgeList.add("flc1");
 	   	edgeList.add("flc2");

 	   	edgeList.add("rqu1");
 	   	edgeList.add("rqu2");

 	   	edgeList.add("rqd1");
 	   	edgeList.add("rqd2");

 	   	//edgeList.add("saf1");
 	   	//edgeList.add("saf2");

 	   	edgeList.add("saf2");
 	   	edgeList.add("saf3");

 	   	edgeList.add("saf3");
 	   	edgeList.add("saf4");

 	   	edgeList.add("saf2");
 	   	edgeList.add("saf13");

 	   	edgeList.add("saf3");
 	   	edgeList.add("saf5");

 	   	edgeList.add("saf5");
 	   	edgeList.add("saf6");

 	   	edgeList.add("saf5");
 	   	edgeList.add("saf7");

 	   	edgeList.add("saf7");
 	   	edgeList.add("saf8");

 	   	edgeList.add("saf8");
 	   	edgeList.add("saf9");

 	   	edgeList.add("saf7");
 	   	edgeList.add("saf10");

 	   	edgeList.add("saf10");
 	   	edgeList.add("saf11");

 	   	edgeList.add("saf11");
 	   	edgeList.add("saf12");

 	   	edgeList.add("saf12");
 	   	edgeList.add("saf13");

 	   	edgeList.add("saf9");
 	   	edgeList.add("saf13");

 	   	edgeList.add("saf6");
 	   	edgeList.add("saf13");

 	   	edgeList.add("saf4");
 	   	edgeList.add("saf13");

 	   	edgeList.add("saf10");
 	   	edgeList.add("saf13");

 	   	edgeList.add("saf11");
 	   	edgeList.add("saf13");

	   	obs = new Observer(nodeList, null, edgeList, "flc1", "FloorControl Class");
 	   	obs.setRecording(true);
    }

    private void addVisitedNode(String nodename) {
 	   	if (obs == null || !obs.isRecording()) return;
 	   	
 	   	// Adding nodes here.
 	   	if (nodename.equals("flc1")) {
 	   		obs.addVisitedNode(nodename);
 	   		obs.addVisitedNode("flc2");
 	   	} else if (nodename.equals("rqu1")) {
 	   		obs.addVisitedNode(nodename);
 	   		obs.addVisitedNode("rqu2");
 	   	} else if (nodename.equals("rqd1")) {
 	   		obs.addVisitedNode(nodename);
 	   		obs.addVisitedNode("rqd2");
 	   	//} else if (nodename.equals("saf1")) {
 	   	//	obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf2")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf3")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf4")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf5")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf6")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf7")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf8")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf9")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf10")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf11")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf12")) {
 	   		obs.addVisitedNode(nodename);
 	   	} else if (nodename.equals("saf13")) {
 	   		obs.addVisitedNode(nodename);
	   	} else {
 	   		obs.addVisitedNode(nodename);
 	   	}
    }
}
