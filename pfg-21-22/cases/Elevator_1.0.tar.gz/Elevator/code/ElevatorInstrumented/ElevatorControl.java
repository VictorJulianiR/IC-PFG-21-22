import java.util.HashMap;
import java.util.Vector;

/*
 * This class receives requests for service and dispatches them
 * to the elevator associated with the control object
 */
public class ElevatorControl {
	private static String startNode;
	private Elevator myElevator;
	private ElevatorInterface ei;
	
	private static Observer obs;
	
	/*
	 * Constructor
	 */
	public ElevatorControl(Elevator elevator) {
		if (obs == null) obs = new Observer();
		addVisitedNode("ece1");
		startNode = "ece1";
		myElevator = elevator;
		ei = ElevatorInterface.getFromList(this);
    }
	
	/*
	 * Constructor
	 */
    public ElevatorControl(int EID) {
    	if (obs == null) obs = new Observer();
		addVisitedNode("eci1");
		startNode = "eci1";
		myElevator = Elevator.selectElevator(EID);
        ei = ElevatorInterface.getFromList(this);
    }
	
	/*
	 * Requests to stop the elevator upon arrival at a floor for which a stop is requested
	 */
    public void stopElevator() {
    	addVisitedNode("stp1");
        myElevator.stopElevator();
    }
	
	/*
	 * Simulates opening elevator's door
	 */
    public void openDoor() {
    	addVisitedNode("opd1");
        myElevator.openDoor();
    }
	
	/*
	 * Simulates closing elevator's door
	 */
    public void closeDoor() {
    	addVisitedNode("cld1");
        myElevator.closeDoor();
    }
	
	/*
	 * Requests a stop at a specified floor
	 */
    public void requestStop(int floor) {
    	addVisitedNode("rqs1");
        myElevator.addStop(floor,true);
    }
	
	/*
	 * @return the associated elevator
	 */
	public Elevator getElevator() {
		addVisitedNode("gel1");
		return myElevator;
	}
	
	/*
	 * Simulates motor moving down
	 */
	public void motorMoveDown() {
		addVisitedNode("mmd1");
		ei.motorMoveDown();
	}
	
	/*
	 * Simulates motor moving up
	 */
	public void motorMoveUp() {
		addVisitedNode("mmu1");
		ei.motorMoveUp();
	}
	
	/*
	 * Simulates stopping motor
	 */
	public void motorStop() {
		addVisitedNode("mst1");
		ei.motorStop();
	}
	
	   public static String getReport() {
		   	if (obs.isRecording()) {
		   		return obs.getReport();
		   	} else {
		   		return "";
		   	}
	   }
		   
	   public static void startRecording() {
		   	// Setup the observer here.
		   	HashMap nodeList = new HashMap();
		   	
		   	nodeList.put("ece1","Constructor(Elevator), Line 14: myElevator = elevator;");   	
		   	nodeList.put("ece2","Constructor(Elevator), Line 16: }");  
		   	
		   	nodeList.put("eci1","Constructor(int), Line 22: myElevator = Elevator.selectElevator(EID);");   	
		   	nodeList.put("eci2","Constructor(int), Line 24: }");  
		   	
		   	nodeList.put("stp1","stopElevator, Line 30: myElevator.stopElevator();");   	
		   	nodeList.put("stp2","stopElevator, Line 31: }");  
		   	
		   	nodeList.put("opd1","openDoor, Line 37: myElevator.openDoor();");   	
		   	nodeList.put("opd2","openDoor, Line 38: }");  
		   			   	
		   	nodeList.put("cld1","closeDoor, Line 44: myElevator.closeDoor();");   	
		   	nodeList.put("cld2","closeDoor, Line 45: }");  

		   	nodeList.put("rqs1","requestStop, Line 52: myElevator.addStop(floor,true);");   	
		   	nodeList.put("rqs2","requestStop, Line 53: }");  

		   	nodeList.put("gel1","getElevator, Line 59: return myElevator;");   	
		   	nodeList.put("gel2","getElevator, Line 60: }");  

		   	nodeList.put("mmd1","motorMoveDown, Line 66: ei.motorMoveDown();");   	
		   	nodeList.put("mmd2","motorMoveDown, Line 67: }");  

		   	nodeList.put("mmu1","motorMoveUp, Line 73: ei.motorMoveUp();");   	
		   	nodeList.put("mmu2","motorMoveUp, Line 74: }");		   	

		   	nodeList.put("mst1","motorStop, Line 80: ei.motorStop();");   	
		   	nodeList.put("mst2","motorStop, Line 81: }");
		   	
		   	Vector edgeList = new Vector();
			   	
		   	edgeList.add("ece1");
		   	edgeList.add("ece2");
			   	
		   	edgeList.add("eci1");
		   	edgeList.add("eci2");
			   	
		   	edgeList.add("stp1");
		   	edgeList.add("stp2");
			   	
		   	edgeList.add("opd1");
		   	edgeList.add("opd2");
			   	
		   	edgeList.add("cld1");
		   	edgeList.add("cld2");
			   	
		   	edgeList.add("rqs1");
		   	edgeList.add("rqs2");
			   	
		   	edgeList.add("gel1");
		   	edgeList.add("gel2");
			   	
		   	edgeList.add("mmd1");
		   	edgeList.add("mmd2");
			   	
		   	edgeList.add("mmu1");
		   	edgeList.add("mmu2");
			   	
		   	edgeList.add("mst1");
		   	edgeList.add("mst2");
			   	
		   	obs = new Observer(nodeList, null, edgeList, startNode, "ElevatorControl Class");
		   	obs.setRecording(true);
	   }

	   private void addVisitedNode(String nodename) {
		   	if (obs == null || !obs.isRecording()) return;
		   	
		   	// Adding nodes here.
		   	if (nodename.equals("ece1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("ece2");
		   	} else if (nodename.equals("eci1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("eci2");
		   	} else if (nodename.equals("stp1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("stp2");
		   	} else if (nodename.equals("opd1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("opd2");
		   	} else if (nodename.equals("cld1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("cld2");
		   	} else if (nodename.equals("rqs1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("rqs2");
		   	} else if (nodename.equals("gel1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("gel2");
		   	} else if (nodename.equals("mmd1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("mmd2");
		   	} else if (nodename.equals("mmu1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("mmu2");
		   	} else if (nodename.equals("mst1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("mst2");
		   	} else {
		   		obs.addVisitedNode(nodename);
		   	}
	   }
}
