
import java.io.*;

/**
 * 
 * @author Mike
 *
 */
public class Recorder {

	private static Recorder rec;
	
	private Recorder() {}
	
	public static Recorder getInstance() {
		if (rec == null) {
			rec = new Recorder();
		}
		
		return rec;
	}
	
	public void startRecording() {
		ArrivalSensor.startRecording();
		Elevator.startRecording();
		ElevatorControl.startRecording();
		ElevatorGroup.startRecording();
		ElevatorInterface.startRecording();
		Floor.startRecording();
		FloorControl.startRecording();
		FloorInterface.startRecording();
	}
	
	public void printReport() {
		String report = "";
		
		report += "Coverage Report";

		report += ArrivalSensor.getReport();
		report += Elevator.getReport();
		report += ElevatorControl.getReport();
		report += ElevatorGroup.getReport();
		report += ElevatorInterface.getReport();
		report += Floor.getReport();
		report += FloorControl.getReport();
		report += FloorInterface.getReport();

		File outputFile = new File("report.txt");
		if (outputFile.exists()) {
			outputFile.delete();
		}
		
		try {
			outputFile.createNewFile();
			
			PrintStream ps = new PrintStream(new FileOutputStream(outputFile));
			ps.print(report);
			ps.close();
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
			System.out.println("Unable to create report file. Dumping to console.");
			System.out.println(report);
		}
	}
}