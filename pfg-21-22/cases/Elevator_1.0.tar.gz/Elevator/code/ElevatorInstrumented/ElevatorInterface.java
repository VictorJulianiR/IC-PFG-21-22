/*
 * This class is the boundary class that allows the interaction with 
 * the different elevators and their button panels
 */
import java.util.HashMap;
import java.util.Vector;
import java.util.Enumeration;

public class ElevatorInterface {
	
	//	List of all ElevatorButtonInterface objects
    private static Vector list = new Vector(); 

    //  ID of the elevator this is matched to.
    private int elevatorID; 
    
    private static Observer obs;

    /*
     * Constructor
     */
	public ElevatorInterface(Elevator e){
		if (obs == null) obs = new Observer();
		addVisitedNode("eli1");
		list.add(this);
	    elevatorID = e.getElevatorID();
    }

	/*
	 * @return an elevator interface from a list of all interfaces
	 * 
	 * @param the elevator control object associated with the interface
	 */
	public static ElevatorInterface getFromList(ElevatorControl ec){
		addVisitedNode("gfl1");
		int EIDNeeded = ec.getElevator().getElevatorID();
        for (Enumeration e = list.elements(); e.hasMoreElements();) {  //Loop through all elevators
        	addVisitedNode("gfl2");  
        	ElevatorInterface testIF = (ElevatorInterface) e.nextElement();
	          if (testIF.elevatorID == EIDNeeded){
	        	  addVisitedNode("gfl3");
	        	  return testIF;
	          }
	          addVisitedNode("gfl4");
		}
        addVisitedNode("gfl5");
        return null;
    }

    /*
     * This method is called whenever a stop is requested from the 
     * elevator associated with the interface.
     * 
     * @param the floor to stop at
     */
	public void requestStop(int floor) {
		addVisitedNode("rqs1");
		if ((floor >= 0) && (floor < ElevatorGroup.numFloors)) {
			addVisitedNode("rqs2");
	        ElevatorControl ec = new ElevatorControl(elevatorID);
	        ec.requestStop(floor);
			ElevatorGroup.elevatorDisplay(elevatorID + 1, "Stop requested at floor " + (floor)); //removed +1 from floor
		} else {
			addVisitedNode("rqs3");
			System.out.println("No such floor: "+ floor + " .");
		}
    }

	/*
	 * @return the elevator unique ID
	 */
	public int getElevatorID() {
		addVisitedNode("gei1");
		return elevatorID;
	}

	/*
	 * To simulate elevator's motor movement down
	 */
	public void motorMoveDown() {
		addVisitedNode("mmd1");
		ElevatorGroup group = ElevatorGroup.getGroup(ElevatorGroup.numElevators, ElevatorGroup.numFloors);
		group.motorMoving(elevatorID,-1,Elevator.selectElevator(elevatorID).getFloor().getFloorID());
	}

	/*
	 * To simulate elevator's motor movement up
	 */
	public void motorMoveUp() {
		addVisitedNode("mmu1");
		ElevatorGroup group = ElevatorGroup.getGroup(ElevatorGroup.numElevators, ElevatorGroup.numFloors);
		group.motorMoving(elevatorID,1,Elevator.selectElevator(elevatorID).getFloor().getFloorID());
	}

	/*
	 * To simulate elevator's motor stop when arriving to a specific floor
	 */
	public void motorStop() {
		addVisitedNode("mst1");
		ElevatorGroup.elevatorDisplay(elevatorID + 1, "Motor stopped.");
	}
	
	   public static String getReport() {
		   	if (obs.isRecording()) {
		   		return obs.getReport();
		   	} else {
		   		return "";
		   	}
	   }
		   
	   public static void startRecording() {
		   	// Setup the observer here.
		   	HashMap nodeList = new HashMap();
		   	
		   	nodeList.put("eli1","Constructor, Line 20: list.add(this);");   	
		   	nodeList.put("eli2","Constructor, Line 22: }");   	
   	
		   	nodeList.put("gfl1","getFromList, Line 31: for (Enumeration e = list.elements(); e.hasMoreElements();) {");   	
		   	nodeList.put("gfl2","getFromList, Line 33: if (testIF.elevatorID == EIDNeeded)");   	
		   	nodeList.put("gfl3","getFromList, Line 33: return testIF;");   	
		   	nodeList.put("gfl4","getFromList, Line 34: }");   	
		   	nodeList.put("gfl5","getFromList, Line 35: return null;");   	

		   	nodeList.put("rqs1","requestStop, Line 45: if ((floor >= 0) && (floor < ElevatorGroup.numFloors)) {");   	
		   	nodeList.put("rqs2","requestStop, Line 46: ElevatorControl ec = new ElevatorControl(elevatorID);");   
		   	nodeList.put("rqs3","requestStop, Line 49: System.out.println(No such floor: + floor +  .);");
		   	nodeList.put("rqs4","requestStop, Line 50: }");

		   	nodeList.put("gei1","getElevatorID, Line 55: return elevatorID;");   	
		   	nodeList.put("gei2","getElevatorID, Line 56: }");   	

		   	nodeList.put("mmd1","motorMoveDown, Line 61: ElevatorGroup group = ElevatorGroup.getGroup(ElevatorGroup.numElevators, ElevatorGroup.numFloors);");   	
		   	nodeList.put("mmd2","motorMoveDown, Line 63: }");   	

		   	nodeList.put("mmu1","motorMoveUp, Line 69: ElevatorGroup group = ElevatorGroup.getGroup(ElevatorGroup.numElevators, ElevatorGroup.numFloors);");   	
		   	nodeList.put("mmu2","motorMoveUp, Line 71: }");   	

		   	nodeList.put("mst1","motorStop, Line 77: ElevatorGroup.elevatorDisplay(elevatorID + 1, Motor stopped.);");   	
		   	nodeList.put("mst2","motorStop, Line 78: }");   	

		   	Vector edgeList = new Vector();
			   	
		   	edgeList.add("eli1");
		   	edgeList.add("eli2");

		   	edgeList.add("gfl1");
		   	edgeList.add("gfl2");
		   	
		   	edgeList.add("gfl2");
		   	edgeList.add("gfl3");
		   	
		   	edgeList.add("gfl2");
		   	edgeList.add("gfl4");
		   	
		   	edgeList.add("gfl4");
		   	edgeList.add("gfl1");
		   	
		   	edgeList.add("gfl1");
		   	edgeList.add("gfl5");
		   
		   	edgeList.add("rqs1");
		   	edgeList.add("rqs2");
		   	
		   	edgeList.add("rqs1");
		   	edgeList.add("rqs3");
		   
		   	edgeList.add("rqs2");
		   	edgeList.add("rqs4");

		   	edgeList.add("rqs3");
		   	edgeList.add("rqs4");

		   	edgeList.add("gei1");
		   	edgeList.add("gei2");

		   	edgeList.add("mmd1");
		   	edgeList.add("mmd2");

		   	edgeList.add("mmu1");
		   	edgeList.add("mmu2");

		   	edgeList.add("mst1");
		   	edgeList.add("mst2");

		   	obs = new Observer(nodeList, null, edgeList, "eli1", "ElevatorInterface Class");
		   	obs.setRecording(true);
	   }

	   private static void addVisitedNode(String nodename) {
		   	if (obs == null || !obs.isRecording()) return;
		   	
		   	// Adding nodes here.
		   	if (nodename.equals("eli1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("eli2");
		   	} else if (nodename.equals("gfl1")) {
		   		obs.addVisitedNode(nodename);
		   	} else if (nodename.equals("gfl2")) {
		   		obs.addVisitedNode(nodename);
		   	} else if (nodename.equals("gfl3")) {
		   		obs.addVisitedNode(nodename);
		   	} else if (nodename.equals("gfl4")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("gfl1");
		   	} else if (nodename.equals("gfl5")) {
		   		obs.addVisitedNode(nodename);
		   	} else if (nodename.equals("rqs1")) {
		   		obs.addVisitedNode(nodename);
		   	} else if (nodename.equals("rqs2")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("rqs4");
		   	} else if (nodename.equals("rqs3")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("rqs4");
		   	} else if (nodename.equals("gei1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("gei2");
		   	} else if (nodename.equals("mmd1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("mmd2");
		   	} else if (nodename.equals("mmu1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("mmu2");
		   	} else if (nodename.equals("mst1")) {
		   		obs.addVisitedNode(nodename);
		   		obs.addVisitedNode("mst2");
		   	} else {
		   		obs.addVisitedNode(nodename);
		   	}
	   }
}
