/*
 * This class represents one elevator in the system. An elevator is a thread 
 * that receives requests from its button panel and from floors.
 */
import java.util.HashMap;
import java.util.Vector;
import java.util.Enumeration;

public class Elevator implements Runnable {

    private static Vector allElevators = new Vector();
    private int elevatorID;
    private boolean running;
    private static Observer obs;
    
    // direction in which the elevator is heading (1 for Up and -1 for Down; 0 when elevator is idle)
    public int direction;

    // An elevator can be in one of 4 states (IDLE, PREPARE, MOVING and FINDNEXT)
    private int state;

	// The floor on which the elevator is currently
	private Floor currentFloor;

	// The stops that an elevator has to serve
    private boolean[] stops = new boolean[Floor.getNoFloors()];
    private int nStops;
	private boolean motorMoving;
	private boolean doorOpen;

    public final static int IDLE=0;
	public final static int PREPARE=1;
	public final static int MOVING=2;
	public final static int FINDNEXT=3;


	//  Constructor
    public Elevator() {
    	if (obs == null) obs = new Observer();
		int newIndex = allElevators.size();
		this.addVisitedNode("elv1");
		this.elevatorID = newIndex;
		//System.out.println("\nNew Elevator, ID #" + elevatorID);
		allElevators.add(this);
	    this.direction = 0; /* 0 when idle, 1 for up direction and -1 for down direction */
	    currentFloor = Floor.selectFloor(0); //New Elevators start at the bottom.
	    state=Elevator.IDLE;
	    nStops = 0;
	    doorOpen = true;
	    motorMoving = false;
	    running = true;
	    
	    //Define the stops, based on the Floors.
	    for(int i = 0; i < Floor.getNoFloors(); i++) {
	    	this.addVisitedNode("elv3");
			Floor floor = Floor.selectFloor(i);
			stops[floor.getFloorID()] = false;
        }
	    this.addVisitedNode("elv4");
	}

    /*
     * @return an elevator corresponding to a unique ID
     */
    public static Elevator selectElevator(int elevatorID) {
    	addVisitedNode("slc1");
        return (Elevator) allElevators.elementAt(elevatorID);
    }

    /*
     * Called by a Floor wanting an elevator to service a request, 
     * this method returns the best elevator for the job - an idle 
     * Elevator is preferred, then a moving elevator headed towards 
     * this floor and a moving elevator headed away if nothing else 
     * is available. 
     */
    public static Elevator getBestElevator(int floorID) {

        //A simple bubble sort

       Elevator bestElevator = null;
       addVisitedNode("gbe1");
       for (Enumeration e = allElevators.elements(); e.hasMoreElements();) {  //Loop through all elevators
    	   Elevator testElevator= (Elevator) e.nextElement();
    	   addVisitedNode("gbe2");
    	   if (bestElevator == null) { 
    		   bestElevator = testElevator;
        	   addVisitedNode("gbe3");
    	   }
    	   else {
        	   addVisitedNode("gbe4");
    		   if (bestElevator.getState() != Elevator.IDLE && testElevator.getState() == Elevator.IDLE) {
    		   		bestElevator=testElevator; //Idle is better than anything else
    		    	addVisitedNode("gbe5");
    		   }
			 	else {
			    	addVisitedNode("gbe6");
			 		if (bestElevator.getState() == Elevator.IDLE && testElevator.getState() == Elevator.IDLE) {//both Idle;
			 		int bestDistance= java.lang.Math.abs(bestElevator.getFloor().getFloorID() - floorID);
			 		int testDistance= java.lang.Math.abs(testElevator.getFloor().getFloorID() - floorID);
			    	addVisitedNode("gbe7");
			 		if (testDistance<bestDistance) {
			     	   addVisitedNode("gbe8");
			 			bestElevator=testElevator;  //If test is closer, test is now best.
			 		}
			 		} else {
			 			addVisitedNode("gbe9");
			 			if (bestElevator.getState()!=Elevator.IDLE && testElevator.getState()!=Elevator.IDLE) { //if both are active
			 				addVisitedNode("gbe10");
			 				if ((testElevator.getFloor().getFloorID() - floorID) * testElevator.direction <=0) { //if test is heading in the right direction or is here
			 					addVisitedNode("gbe11");
			 					if ((bestElevator.getFloor().getFloorID() - floorID) * bestElevator.direction > 0) {//Best is heading away
			 						addVisitedNode("gbe12");
			 						bestElevator=testElevator;
			 					} else {// Both heading towards this floor
			 						int bestDistance= java.lang.Math.abs(bestElevator.getFloor().getFloorID() - floorID);
			 						int testDistance= java.lang.Math.abs(testElevator.getFloor().getFloorID() - floorID);
			 						addVisitedNode("gbe13");
			 						if (testDistance<bestDistance) {  
			 							bestElevator=testElevator;  //If test is closer, test is now best.
			 							addVisitedNode("gbe14");
			 						}
			 					}
			 				} // End if test is heading this way
			 			}// end if both are active
			 		}
			 	}
    	   }
    	   addVisitedNode("gbe16");
       }  //End enumeration loop.
       //System.out.println("Best Elevator is: "+ (bestElevator.getElevatorID()+1));
       addVisitedNode("gbe15");
       return bestElevator;
    }

   /*
    * Called by ArrivalSensor to tell the elevator that it's reached a new floor.
    * 
    * @return true if the elevator has to stop, and false otherwise
    */
   public boolean notifyNewFloor(Floor newFloor) {
		currentFloor = newFloor;
 	    this.addVisitedNode("nnf1");
		ElevatorGroup.elevatorDisplay(elevatorID+1 ,"Reached floor "+(newFloor.getFloorID())); //removed +1 from floor

		if (stops[newFloor.getFloorID()] == true) {
			this.addVisitedNode("nnf2");
			stopElevator();
		    return true;
        } else {
        	this.addVisitedNode("nnf3");
        	if((newFloor.requestUpMade()) && (direction == 1)) {
        		this.addVisitedNode("nnf4");
        		stopElevator();
        		return true;
        	} else {
        		this.addVisitedNode("nnf5");
        		if((newFloor.requestDownMade()) && (direction == -1)) {
        			this.addVisitedNode("nnf6");
        			stopElevator();
        			return true;
        		} else {
        			this.addVisitedNode("nnf7");
        			if (direction==1) {
        				this.addVisitedNode("nnf8");
        				motorMoveUp();
        			} else {
        				this.addVisitedNode("nnf9");
        				motorMoveDown();
        			}
        			this.addVisitedNode("nnf10");
        			return false;
        		}
        	}
        }//end else
   }

   /*
    * Simulates elevator's motor movement down
    */
   private void motorMoveDown() {
	    this.addVisitedNode("mmd1");
		ElevatorControl ec = new ElevatorControl(this);
		motorMoving = true;
		ec.motorMoveDown();
		ec = null;
    }

   /*
    * Simulates elevator's motor movement up
    */
   private void motorMoveUp() {
	   this.addVisitedNode("mmu1");
	   ElevatorControl ec = new ElevatorControl(this);
		motorMoving = true;
		ec.motorMoveUp();
		ec = null;
	}

	/*
     * If there is a floor with a request in the current direction, move one floor in the current direction.
     * Else reverse direction and check again. 
     */
    public void moveElevator() {

		/* Three-phase movement cycle.  
		 * Prepare/move/check.  
		 * Does not loop here, since it returns control to run()
         * which calls this again if it hasn't set itself to Idle.
         */

        //  PREPARE:
    	addVisitedNode("mve1");
        if (this.state == PREPARE) {
		   ElevatorGroup.elevatorDisplay(elevatorID + 1 ,"Door closed.");
           closeDoor();
           this.state = MOVING;
           addVisitedNode("mve2");
           if (direction==1) {
        	   addVisitedNode("mve3");
        	   motorMoveUp();
           } else {
        	   addVisitedNode("mve4");
        	   motorMoveDown();
           }
        }
        addVisitedNode("mve5");
        // MOVING:
        while (this.state==MOVING) {
            //Do nothing - we're waiting to be interrupted by ArrivalSensor telling us we've reached a new floor.
        	addVisitedNode("mve6");
			try {
				addVisitedNode("mve7");
				Thread.sleep(500);
			} catch (Exception e) {
				addVisitedNode("mve8");
			}
			addVisitedNode("mve9");
        }
        addVisitedNode("mve10");
        getNextDestination();
    }
    
    /*
     * @return floor id to service or -1 if no more requests
     */
    public int getNextDestination() {
    	addVisitedNode("gnd1");
		while (this.state==FINDNEXT) {
			addVisitedNode("gnd2");
            if (nStops == 0) {
            	addVisitedNode("gnd3");
            	this.state = Elevator.IDLE;
        		direction = 0;
				ElevatorGroup.elevatorDisplay(elevatorID + 1 ,"All stops handled.  Idling.");
				return -1;
            } else {
				int stopToCheck = currentFloor.getFloorID() + direction;
				addVisitedNode("gnd4");
	            while (Floor.selectFloor(stopToCheck)!=null && state==FINDNEXT) {
	            	addVisitedNode("gnd5");
	            	if (stops[stopToCheck]==true) {
	            		addVisitedNode("gnd6");
						this.state=PREPARE;
						ElevatorGroup.elevatorDisplay(elevatorID + 1,"Next Stop = floor "+(stopToCheck));
	 					return stopToCheck;
					} else {
						addVisitedNode("gnd7");
						stopToCheck += direction;
					}
	            }
	            addVisitedNode("gnd8");
	            if (Floor.selectFloor(stopToCheck)==null && state == FINDNEXT) { //If we ran out of floors before finding a stop
	            	addVisitedNode("gnd9");
	            	direction = -direction; //reverse direction
	            } 
            }
            addVisitedNode("gnd10");
        }
		addVisitedNode("gnd11");
		return -1;
    }


    /*
     * When an elevator reaches a stop, it stops its motor, open the door
     * and removes the served stop from the list of stops
     */
    public void stopElevator() {
    	addVisitedNode("ste1");
    	state=FINDNEXT;
    	motorStop();
		ElevatorGroup.elevatorDisplay(elevatorID + 1 ,"Stopped.  ");
		ElevatorGroup.elevatorDisplay(elevatorID + 1 ,"Door open.");
        openDoor();
		addStop(currentFloor.getFloorID(),false); //to remove stop from list of stops
    }

    /*
     * Simulates motor stopping
     */
    private void motorStop() {
    	addVisitedNode("mts1");
		ElevatorControl ec = new ElevatorControl(this);
		motorMoving = false;
		ec.motorStop();
		ec = null;
	}

    /*
     * Simulates elevator's door opening
     */
	public void openDoor() {
        ElevatorGroup.elevatorDisplay(elevatorID+1, "Door is open on floor " + getFloor().getFloorID() + ".");
        try {
        	doorOpen = true;
			Thread.sleep(1000);
			addVisitedNode("opd1");
		} catch (InterruptedException e) {
			addVisitedNode("opd2");
		}
		addVisitedNode("opd3");
    }

	/*
	 * Simulates elevator's door closing
	 */
    public void closeDoor() {
        ElevatorGroup.elevatorDisplay(elevatorID+1, "Door is closed on floor " + getFloor().getFloorID() + ".");
        try {
        	doorOpen = false;
			Thread.sleep(1000);
			addVisitedNode("cld1");
		} catch (InterruptedException e) {
			addVisitedNode("cld2");
		}
		addVisitedNode("cld3");
    }

    /*
     * A stop is added to the list of elevator stops whenever a stop is requested
     * from the elevator or a request from floor has been directed to the elevator
     * after selecting it as the best elevator to do the job
     * 
     * @param floorID: the floor where to stop or to remove a stop after reaching it
     *        stopState: true if a stop is added, false if a stop at a floor is to be 
     *                   removed after reaching the floor
     */
    public void addStop(int floorID, boolean stopState) {
    	addVisitedNode("ads1");
		if (stopState) {
			addVisitedNode("ads2");
			if (floorID != currentFloor.getFloorID()) {
				nStops++;
				stops[floorID] = stopState;
				addVisitedNode("ads4");
	            if (this.state == Elevator.IDLE) {
	            	addVisitedNode("ads6");
			       if (this.currentFloor.getFloorID()<floorID) { //If the requested floor is above the current one
			    	   addVisitedNode("ads7");
			    	   direction = 1;
			    	   this.state = PREPARE;  //Start the motion cycle
	                } else {
	                	addVisitedNode("ads8");
	                	direction = -1;
					    this.state=PREPARE; 
	                }
				}
			} else {
				addVisitedNode("ads5");
				ElevatorGroup.elevatorDisplay(elevatorID+1, "Elevator is at requested floor.");
			}
            
        } else {
        	addVisitedNode("ads3");
             stops[floorID] = stopState;
             nStops--;
		}
		addVisitedNode("ads9");
    }

    public void run() {
    	//ElevatorGroup.elevatorDisplay(elevatorID + 1, "running.");
    	addVisitedNode("run1");
    	while (running) {
	        try {
	        	addVisitedNode("run2");
	        	if (this.state==Elevator.IDLE) {
	        		Thread.sleep(100);  
	        		addVisitedNode("run3");
	        		//If you're idle, sleep for a short time.
				} else {
					//ElevatorGroup.elevatorDisplay(this.getElevatorID()+1, "called MoveElevator()");
					addVisitedNode("run4");
					moveElevator();
				}
			} catch (Exception e) { //If you're interrupted, wake up and do nothing.
				addVisitedNode("run5");
	        }
	    }
    	addVisitedNode("run6");
    }

    /*
     * @return the direction in which the elevator is heading
     */
	public int getDirection() {
		addVisitedNode("gtd1");
		return direction;
	}

	/*
     * @return the state of the elevator
     */
	public int getState() {
		addVisitedNode("gts1");
		return state;
	}

	/*
     * @return the current floor on which the elevator is
     */
	public Floor getFloor(){
		addVisitedNode("gtf1");
		return currentFloor;
	}

	/*
     * @return the elevator's unique ID
     */
	public int getElevatorID() {
		addVisitedNode("gei1");
		return elevatorID;
	}

	/*
     * @return true if elevator's door is open and false otherwise
     */
	public boolean getDoorOpen() {
		addVisitedNode("dgo1");
		return doorOpen;
	}

	/*
     * @return true if elevator's motor is moving and false otherwise
     */
	public boolean getMotorMoving() {
		addVisitedNode("gmm1");
		return motorMoving;
	}
	
	/*
	 * @param i floor number
	 * @return true if there is a stop requested for floor i
	 */
	public boolean getStop (int i) {
		addVisitedNode("gst1");
		return stops[i];
	}
	
	public int getNumberOfStops() {
		addVisitedNode("gns1");
		return nStops;
	}
	
	public static void removeElevator(int elevatorID) {
		//addVisitedNode("rel1");
		Elevator elevator = Elevator.selectElevator(elevatorID);
		allElevators.removeElement(elevator);
	}
	
	public static void removeAllElevators() {
		addVisitedNode("rae1");
		allElevators.removeAllElements();
	}
	
	public void setToIdle() {
		//addVisitedNode("sti1");
		currentFloor = Floor.selectFloor(0); //New Elevators start at the bottom.
	    state = Elevator.IDLE;
	    nStops = 0;
	    doorOpen = true;
	    motorMoving = false;
	    
	    for(int i = 0; i < Floor.getNoFloors(); i++) {
	    	//addVisitedNode("sti3");
			Floor floor = Floor.selectFloor(i);
			stops[floor.getFloorID()] = false;
       }
	    //addVisitedNode("sti4");
	}
	
	public void turnOff() {
		addVisitedNode("tof1");
		running = false;
	}
	
   public static String getReport() {
	   	if (obs.isRecording()) {
	   		return obs.getReport();
	   	} else {
	   		return "";
	   	}
   }
	   
   public static void startRecording() {
	   	// Setup the observer here.
	   	HashMap nodeList = new HashMap();
	   	
	   	nodeList.put("elv1","Constructor, Line 37: int newIndex = allElevators.size();"); 
	   	nodeList.put("elv2","Constructor, Line 50: for(int i = 0; i < Floor.getNoFloors(); i++) {");
	   	nodeList.put("elv3","Constructor, Line 51: Floor floor = Floor.selectFloor(i);");
	   	nodeList.put("elv4","Constructor, Line 53: }");
	   	
	   	nodeList.put("slc1","selectElevator, Line 60: return (Elevator) allElevators.elementAt(elevatorID);");
	   	nodeList.put("slc2","selectElevator, Line 61: }");
	   	
	   	nodeList.put("gbe1","getBestElevator, Line 75: for (Enumeration e = allElevators.elements(); e.hasMoreElements();) {");
	   	nodeList.put("gbe2","getBestElevator, Line 78: if (bestElevator == null)");
	   	nodeList.put("gbe3","getBestElevator, Line 79: bestElevator = testElevator;");
	   	nodeList.put("gbe4","getBestElevator, Line 80: else if (bestElevator.getState() != Elevator.IDLE && testElevator.getState() == Elevator.IDLE)");
	   	nodeList.put("gbe5","getBestElevator, Line 81: bestElevator=testElevator;");
	   	nodeList.put("gbe6","getBestElevator, Line 82: else if (bestElevator.getState() == Elevator.IDLE && testElevator.getState() == Elevator.IDLE) {");
	   	nodeList.put("gbe7","getBestElevator, Line 85: if (testDistance<bestDistance)");
	   	nodeList.put("gbe8","getBestElevator, Line 86: bestElevator=testElevator;");
	   	nodeList.put("gbe9","getBestElevator, Line 87: else if (bestElevator.getState()!=Elevator.IDLE && testElevator.getState()!=Elevator.IDLE) {");
	   	nodeList.put("gbe10","getBestElevator, Line 88: if ((testElevator.getFloor().getFloorID() - floorID) * testElevator.direction <=0) {");
	   	nodeList.put("gbe11","getBestElevator, Line 89: if ((bestElevator.getFloor().getFloorID() - floorID) * bestElevator.direction > 0) {");
	   	nodeList.put("gbe12","getBestElevator, Line 90: bestElevator=testElevator;");
	   	nodeList.put("gbe13","getBestElevator, Line 94: if (testDistance<bestDistance)");
	   	nodeList.put("gbe14","getBestElevator, Line 95: bestElevator=testElevator;");
	   	nodeList.put("gbe15","getBestElevator, Line 101: return bestElevator;");
	   	nodeList.put("gbe16","getBestElevator, Line 98: }");
	   	
	   	nodeList.put("nnf1","notifyNewFloor, Line 113: if (stops[newFloor.getFloorID()] == true) {");
	   	nodeList.put("nnf2","notifyNewFloor, Line 114: stopElevator();");
	   	nodeList.put("nnf3","notifyNewFloor, Line 116: } else if((newFloor.requestUpMade()) && (direction == 1)) {");
	   	nodeList.put("nnf4","notifyNewFloor, Line 117: stopElevator();");
	   	nodeList.put("nnf5","notifyNewFloor, Line 119: else if((newFloor.requestDownMade()) && (direction == -1)) {");
	   	nodeList.put("nnf6","notifyNewFloor, Line 120: stopElevator();");
	   	nodeList.put("nnf7","notifyNewFloor, Line 123: if (direction==1) {");
	   	nodeList.put("nnf8","notifyNewFloor, Line 124: motorMoveUp();");
	   	nodeList.put("nnf9","notifyNewFloor, Line 126: motorMoveDown();");
	   	nodeList.put("nnf10","notifyNewFloor, Line 128: return false;");
	   	
	   	nodeList.put("mmd1","motorMoveDown, Line 136: ElevatorControl ec = new ElevatorControl(this);");
	   	nodeList.put("mmd2","motorMoveDown, Line 139: ec = null;");
		   	
	   	nodeList.put("mmu1","motorMoveUp, Line 146: ElevatorControl ec = new ElevatorControl(this);");
	   	nodeList.put("mmu2","motorMoveUp, Line 149: ec = null;");
	   	
	   	nodeList.put("ste1","stopElevator, Line 217: state=FINDNEXT;");
	   	nodeList.put("ste2","stopElevator, Line 222: addStop(currentFloor.getFloorID(),false);");
	   	
	   	nodeList.put("mts1","motorStop, Line 228: ElevatorControl ec = new ElevatorControl(this);");
	   	nodeList.put("mts2","motorStop, Line 231: ec = null;");
	   	
	   	nodeList.put("opd1","openDoor, Line 241: Thread.sleep(1000);");
	   	nodeList.put("opd2","openDoor, Line 242: catch (InterruptedException e) {");
	   	nodeList.put("opd3","openDoor, Line 244: }");
	   	
	   	nodeList.put("mve1","moveElevator, Line 165: if (this.state == PREPARE) {");
	   	nodeList.put("mve2","moveElevator, Line 169: if (direction==1) {");
	   	nodeList.put("mve3","moveElevator, Line 170: motorMoveUp();");
	   	nodeList.put("mve4","moveElevator, Line 172: motorMoveDown();");
	   	nodeList.put("mve5","moveElevator, Line 177: while (this.state==MOVING) {");
	   	nodeList.put("mve6","moveElevator, Line 179: try {");
	   	nodeList.put("mve7","moveElevator, Line 180: Thread.sleep(500);");
	   	nodeList.put("mve8","moveElevator, Line 181: catch (Exception e) {");
	   	nodeList.put("mve9","moveElevator, Line 183: }");
	   	nodeList.put("mve10","moveElevator, Line 184: getNextDestination();");
	   	
	   	nodeList.put("gnd1","getNextDestination, Line 190: while (this.state==FINDNEXT) {");
	   	nodeList.put("gnd2","getNextDestination, Line 191: if (nStops == 0) {");
	   	nodeList.put("gnd3","getNextDestination, Line 192: this.state = Elevator.IDLE;");
	   	nodeList.put("gnd4","getNextDestination, Line 198: while (Floor.selectFloor(stopToCheck)!=null && state==FINDNEXT) {");
	   	nodeList.put("gnd5","getNextDestination, Line 199: if (stops[stopToCheck]==true) {");
	   	nodeList.put("gnd6","getNextDestination, Line 202: return stopToCheck;");
	   	nodeList.put("gnd7","getNextDestination, Line 204: stopToCheck += direction;");
	   	nodeList.put("gnd8","getNextDestination, Line 207: if (Floor.selectFloor(stopToCheck)==null && state == FINDNEXT) {");
	   	nodeList.put("gnd9","getNextDestination, Line 208: direction = -direction;");
	   	nodeList.put("gnd10","getNextDestination, Line 209: }");
	   	nodeList.put("gnd11","getNextDestination, Line 211: return -1;");
	   	
	   	nodeList.put("cld1","closeDoor, Line 253: Thread.sleep(1000);");
	   	nodeList.put("cld2","closeDoor, Line 254: catch (InterruptedException e) {");
	   	nodeList.put("cld3","closeDoor, Line 256: }");
	   	
	   	nodeList.put("ads1","addStop, Line 268: if (stopState) {");
	   	nodeList.put("ads2","addStop, Line 269: if ((floorID != currentFloor.getFloorID()) || (this.getState() == Elevator.MOVING)) {");
	   	nodeList.put("ads3","addStop, Line 286: stops[floorID] = stopState;");
	   	nodeList.put("ads4","addStop, Line 272: if (this.state == Elevator.IDLE) {");
	   	nodeList.put("ads5","addStop, Line 282: ElevatorGroup.elevatorDisplay(elevatorID+1, Elevator is at requested floor.);");
	   	nodeList.put("ads6","addStop, Line 273: if (this.currentFloor.getFloorID()<floorID) {");
	   	nodeList.put("ads7","addStop, Line 274: direction = 1;");
	   	nodeList.put("ads8","addStop, Line 277: direction = -1;");
	   	nodeList.put("ads9","addStop, Line 289: }");
	   	
	   	nodeList.put("run1","run, Line 293: while (running) {");
	   	nodeList.put("run2","run, Line 295: if (this.state==Elevator.IDLE) {");
	   	nodeList.put("run5","run, Line 302: catch (Exception e) {");
	   	nodeList.put("run3","run, Line 296: Thread.sleep(500); ");
	   	nodeList.put("run4","run, Line 300: moveElevator();");
	   	nodeList.put("run6","run, Line 305: }");
	   	
	   	nodeList.put("gtd1","getDirection, Line 311: return direction;");
	   	nodeList.put("gtd2","getDirection, Line 312: }");
	   	
	   	nodeList.put("gts1","getState, Line 318: return state;");
	   	nodeList.put("gts2","getState, Line 319: }");
	   	
	   	nodeList.put("gtf1","getFloor, Line 325: return currentFloor;");
	   	nodeList.put("gtf2","getFloor, Line 326: }");
	   	
	   	nodeList.put("gei1","getElevatorID, Line 332: return elevatorID;");
	   	nodeList.put("gei2","getElevatorID, Line 333: }");
	   	
	   	nodeList.put("gdo1","getDoorOpen, Line 339: return doorOpen;");
	   	nodeList.put("gdo2","getDoorOpen, Line 340: }");
	   	
	   	nodeList.put("gmm1","getMotorMoving, Line 346: return motorMoving;");
	   	nodeList.put("gmm2","getMotorMoving, Line 347: }");
	   	
	   	nodeList.put("gst1","getStop, Line 354: return stops[i];");
	   	nodeList.put("gst2","getStop, Line 355: }");
	   	
	   	nodeList.put("gns1","getNumberOfStops, Line 358: return nStops;");
	   	nodeList.put("gns2","getNumberOfStops, Line 359: }");
	   	
	   	nodeList.put("rae1","removeAllElevators, Line 367: allElevators.removeAllElements();");
	   	nodeList.put("rae2","removeAllElevators, Line 368: }");
	   	
	   	nodeList.put("tof1","turnOff, Line 384: running = false;");
	   	nodeList.put("tof2","turnOff, Line 385: }");
	   	
	   	//nodeList.put("rel1","removeElevator, Line 362: Elevator elevator = Elevator.selectElevator(elevatorID);");
	   	//nodeList.put("rel2","removeElevator, Line 364: }");
	   	
	   	//nodeList.put("sti1","setToIdle, Line 371: currentFloor = Floor.selectFloor(0); ");
	   	//nodeList.put("sti2","setToIdle, Line 377: for(int i = 0; i < Floor.getNoFloors(); i++) {");
	   	//nodeList.put("sti3","setToIdle, Line 378: Floor floor = Floor.selectFloor(i);");
	   	//nodeList.put("sti3","setToIdle, Line 381: }");
	   	
	   	Vector edgeList = new Vector();
		   	
	   	edgeList.add("elv1");
	   	edgeList.add("elv2");
	   	
	   	edgeList.add("elv2");
	   	edgeList.add("elv3");
	   	
	   	edgeList.add("elv3");
	   	edgeList.add("elv2");
	   	
	   	edgeList.add("elv2");
	   	edgeList.add("elv4");
	   	
	   	edgeList.add("slc1");
	   	edgeList.add("slc2");
	   	
	   	edgeList.add("gbe1");
	   	edgeList.add("gbe2");
		   	
	   	edgeList.add("gbe1");
	   	edgeList.add("gbe15");
	   	
	   	edgeList.add("gbe2");
	   	edgeList.add("gbe3");
	   	
	   	edgeList.add("gbe2");
	   	edgeList.add("gbe4");
		
	   	edgeList.add("gbe3");
	   	edgeList.add("gbe16");
		
	   	edgeList.add("gbe4");
	   	edgeList.add("gbe5");
		
	   	edgeList.add("gbe4");
	   	edgeList.add("gbe6");
	   	
	   	edgeList.add("gbe5");
	   	edgeList.add("gbe16");
		
	   	edgeList.add("gbe6");
	   	edgeList.add("gbe7");
		
	   	edgeList.add("gbe6");
	   	edgeList.add("gbe9");
		
	   	edgeList.add("gbe7");
	   	edgeList.add("gbe8");
		
	   	edgeList.add("gbe8");
	   	edgeList.add("gbe16");
	   	
	   	edgeList.add("gbe9");
	   	edgeList.add("gbe10");
	   	
	   	edgeList.add("gbe9");
	   	edgeList.add("gbe16");
		
	   	edgeList.add("gbe10");
	   	edgeList.add("gbe11");
	   	
	   	edgeList.add("gbe10");
	   	edgeList.add("gbe16");
	   	
	   	edgeList.add("gbe11");
	   	edgeList.add("gbe12");
		
	   	edgeList.add("gbe11");
	   	edgeList.add("gbe13");
		
	   	edgeList.add("gbe12");
	   	edgeList.add("gbe16");
		
	   	edgeList.add("gbe13");
	   	edgeList.add("gbe14");
		
	   	edgeList.add("gbe14");
	   	edgeList.add("gbe16");
	   	
	   	edgeList.add("gbe13");
	   	edgeList.add("gbe16");
	   	
	   	edgeList.add("gbe16");
	   	edgeList.add("gbe1");
	   	
	   	edgeList.add("nnf1");
	   	edgeList.add("nnf2");
	   	
	   	edgeList.add("nnf1");
	   	edgeList.add("nnf3");
	   	
	   	edgeList.add("nnf3");
	   	edgeList.add("nnf4");
	   	
	   	edgeList.add("nnf3");
	   	edgeList.add("nnf5");
	   	
	   	edgeList.add("nnf5");
	   	edgeList.add("nnf6");
	   	
	   	edgeList.add("nnf5");
	   	edgeList.add("nnf7");
	   	
	   	edgeList.add("nnf7");
	   	edgeList.add("nnf8");
	   	
	   	edgeList.add("nnf7");
	   	edgeList.add("nnf9");
	   	
	   	edgeList.add("nnf8");
	   	edgeList.add("nnf10");
		
	   	edgeList.add("nnf9");
	   	edgeList.add("nnf10");
	   	
	   	edgeList.add("mmd1");
	   	edgeList.add("mmd2");
	   	
	   	edgeList.add("mmu1");
	   	edgeList.add("mmu2");
	   	
	   	edgeList.add("ste1");
	   	edgeList.add("ste2");
	   	
	   	edgeList.add("mts1");
	   	edgeList.add("mts2");
	   	
	   	edgeList.add("opd1");
	   	edgeList.add("opd2");
	   	
	   	edgeList.add("opd1");
	   	edgeList.add("opd3");
	   	
	   	edgeList.add("opd2");
	   	edgeList.add("opd3");
	   	
	   	edgeList.add("cld1");
	   	edgeList.add("cld2");
	   	
	   	edgeList.add("cld1");
	   	edgeList.add("cld3");
	   	
	   	edgeList.add("cld2");
	   	edgeList.add("cld3");

	   	edgeList.add("mve1");
	   	edgeList.add("mve2");
	   	
	   	edgeList.add("mve2");
	   	edgeList.add("mve3");
	   	
	   	edgeList.add("mve2");
	   	edgeList.add("mve4");
	   	
	   	edgeList.add("mve3");
	   	edgeList.add("mve5");
	   	
	   	edgeList.add("mve4");
	   	edgeList.add("mve5");
	   	
	   	edgeList.add("mve1");
	   	edgeList.add("mve5");
	   	
	   	edgeList.add("mve5");
	   	edgeList.add("mve6");
	   	
	   	edgeList.add("mve5");
	   	edgeList.add("mve10");
	   	
	   	edgeList.add("mve6");
	   	edgeList.add("mve7");
	   	
	   	edgeList.add("mve7");
	   	edgeList.add("mve8");
	   	
	   	edgeList.add("mve7");
	   	edgeList.add("mve9");
	   	
	   	edgeList.add("mve8");
	   	edgeList.add("mve9");
	   	
	   	edgeList.add("mve9");
	   	edgeList.add("mve5");
	   	
	   	edgeList.add("gnd1");
	   	edgeList.add("gnd2");
	   	
	   	edgeList.add("gnd1");
	   	edgeList.add("gnd11");
	   	
	   	edgeList.add("gnd2");
	   	edgeList.add("gnd3");
	   	
	   	edgeList.add("gnd2");
	   	edgeList.add("gnd4");
	   	
	   	edgeList.add("gnd4");
	   	edgeList.add("gnd5");
	   	
	   	edgeList.add("gnd4");
	   	edgeList.add("gnd8");
	   	
	   	edgeList.add("gnd5");
	   	edgeList.add("gnd6");
	   	
	   	edgeList.add("gnd5");
	   	edgeList.add("gnd7");
	   	
	   	edgeList.add("gnd7");
	   	edgeList.add("gnd4");
	   	
	   	edgeList.add("gnd8");
	   	edgeList.add("gnd9");
	   	
	   	edgeList.add("gnd9");
	   	edgeList.add("gnd10");
	   	
	   	edgeList.add("gnd8");
	   	edgeList.add("gnd10");
	   	
	   	edgeList.add("gnd10");
	   	edgeList.add("gnd1");
	   	
	   	edgeList.add("ads1");
	   	edgeList.add("ads2");
	   	
	   	edgeList.add("ads1");
	   	edgeList.add("ads3");
	   	
	   	edgeList.add("ads2");
	   	edgeList.add("ads4");
	   	
	   	edgeList.add("ads2");
	   	edgeList.add("ads5");
	   	
	   	edgeList.add("ads4");
	   	edgeList.add("ads6");
	   	
	   	edgeList.add("ads6");
	   	edgeList.add("ads7");
	   	
	   	edgeList.add("ads6");
	   	edgeList.add("ads8");
	   	
	   	edgeList.add("ads7");
	   	edgeList.add("ads9");
	   	
	   	edgeList.add("ads8");
	   	edgeList.add("ads9");
	   	
	   	edgeList.add("ads3");
	   	edgeList.add("ads9");
	   	
	   	edgeList.add("ads4");
	   	edgeList.add("ads9");
	   	
	   	edgeList.add("ads5");
	   	edgeList.add("ads9");
	   	
	   	edgeList.add("run1");
	   	edgeList.add("run2");
 	   	
	   	edgeList.add("run1");
	   	edgeList.add("run6");
	   	
	   	edgeList.add("run2");
	   	edgeList.add("run3");
	   	
	   	edgeList.add("run3");
	   	edgeList.add("run4");
	   	
	   	edgeList.add("run3");
	   	edgeList.add("run1");
	   	
	   	edgeList.add("run3");
	   	edgeList.add("run5");
	   	
	   	edgeList.add("run4");
	   	edgeList.add("run1");
	   	
	   	edgeList.add("run5");
	   	edgeList.add("run1");
	   		   	
	   	edgeList.add("gtd1");
	   	edgeList.add("gtd2");
	   	
	   	edgeList.add("gts1");
	   	edgeList.add("gts2");
	   	
	   	edgeList.add("gtf1");
	   	edgeList.add("gtf2");
	   	
	   	edgeList.add("gei1");
	   	edgeList.add("gei2");
	   	
	   	edgeList.add("gdo1");
	   	edgeList.add("gdo2");
	   	
	   	edgeList.add("gmm1");
	   	edgeList.add("gmm2");
	   	
	   	edgeList.add("gst1");
	   	edgeList.add("gst2");
	   	
	   	edgeList.add("gns1");
	   	edgeList.add("gns2");
	   	
	   	edgeList.add("rae1");
	   	edgeList.add("rae2");
	   	
	   	edgeList.add("tof1");
	   	edgeList.add("tof2");
	   	
	   	/*edgeList.add("rel1");
	   	edgeList.add("rel2");
	   	
	   	edgeList.add("sti1");
	   	edgeList.add("sti2");
	   	
	   	edgeList.add("sti2");
	   	edgeList.add("sti3");
	   	
	   	edgeList.add("sti2");
	   	edgeList.add("sti4");
	   	
	   	edgeList.add("sti3");
	   	edgeList.add("sti2");*/
	   	
	   	obs = new Observer(nodeList, null, edgeList, "elv1", "Elevator Class");
	   	obs.setRecording(true);
   }

   private static void addVisitedNode(String nodename) {
	   	if (obs == null || !obs.isRecording()) return;
	   	
	   	// Adding nodes here.
	   	if (nodename.equals("elv1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("elv2");
	   	} else if (nodename.equals("elv3")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("elv2");
	   	} else if (nodename.equals("elv4")) {
		   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("slc1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("slc2");
	   	} else if (nodename.equals("gbe1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe4")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe5")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe6")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe7")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe8")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe9")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe10")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe11")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe12")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe13")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe14")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe15")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gbe16")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gbe1");
	   	} else if (nodename.equals("nnf1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("nnf2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("nnf3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("nnf4")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("nnf5")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("nnf6")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("nnf7")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("nnf8")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("nnf9")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("nnf10")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("mmd1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("mmd2");
	   	} else if (nodename.equals("mmu1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("mmu2");	   	
	   	} else if (nodename.equals("ste1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("ste2");
	   	} else if (nodename.equals("mts1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("mts2");
	   	} else if (nodename.equals("opd1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("opd2")) {
	   		obs.addVisitedNode("opd1");
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("opd3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("mve1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("mve2")) {
	   		obs.addVisitedNode(nodename);	   	
	   	} else if (nodename.equals("mve3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("mve4")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("mve5")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("mve6")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("mve7")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("mve8")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("mve9")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("mve5");
	   	} else if (nodename.equals("mve10")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnd1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnd2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnd3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnd4")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnd5")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnd6")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnd7")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gnd4");
	   	} else if (nodename.equals("gnd8")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnd9")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnd10")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gnd1");
	   	} else if (nodename.equals("gnd11")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("cld1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("cld2")) {
	   		obs.addVisitedNode("cld1");	
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("cld3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("ads1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("ads2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("ads3")) {
	   		obs.addVisitedNode(nodename);	
	   	} else if (nodename.equals("ads4")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("ads5")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("ads6")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("ads7")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("ads8")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("ads9")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("run1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("run2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("run3")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("run1");
	   	} else if (nodename.equals("run4")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("run1");
	   	} else if (nodename.equals("run5")) {
	   		obs.addVisitedNode("run3");
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("run1");
	   	} else if (nodename.equals("run6")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gtd1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gtd2");
	   	} else if (nodename.equals("gts1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gts2");
	   	} else if (nodename.equals("gtf1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gtf2");
	   	} else if (nodename.equals("gei1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gei2");
	   	} else if (nodename.equals("gdo1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gdo2");
	   	} else if (nodename.equals("gmm1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gmm2");
	   	} else if (nodename.equals("gst1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gst2");
	   	} else if (nodename.equals("gns1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gns2");
	   	} else if (nodename.equals("rae1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("rae2");
	   	} else if (nodename.equals("tof1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("tof2");
	   /*	} else if (nodename.equals("rel1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("rel2");
	   	} else if (nodename.equals("sti1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("sti2");
	   	} else if (nodename.equals("sti3")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("sti2");
	   	} else if (nodename.equals("sti4")) {
	   		obs.addVisitedNode(nodename);*/
	   	} else {
	   		obs.addVisitedNode(nodename);
	   	}
   }
}
