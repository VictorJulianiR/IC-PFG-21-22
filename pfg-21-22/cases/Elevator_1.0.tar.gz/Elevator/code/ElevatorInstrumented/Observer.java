import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import java.io.*;

/**
 * @author mike
 *
 */
class Observer {

	// MUST BE EVEN!!
	private final static int MAX_RECORDS = 1000;
	
	private Vector nodesVisited;
	private HashMap nodeList;
	private HashMap defUseMap;
	private Vector edgeList;
	private boolean recording;
	private String startNode;
	private String methodName;
	
	private boolean hasFileInfo;
	private File tempFile;
	private String fileName;
	private boolean bufferToFile;
	private PrintStream ps = null;
	private BufferedReader br = null;
	private StreamTokenizer inputStream = null;
	
	public Observer() {
		this(null,null,null,null,"");
		this.recording = false;
	}
	
	public Observer(HashMap nodeList,
					HashMap defUseMap,
					Vector edgeList,
					String startNode,
					String methodName) {
		this.nodeList = nodeList;
		this.defUseMap = defUseMap;
		this.edgeList = edgeList;
		this.startNode = startNode;
		this.methodName = methodName;
		
		nodesVisited = new Vector();
		
		this.hasFileInfo = false;
		this.fileName = "tmp_" + methodName + ".txt";
		this.bufferToFile = true;
	}
	
	public void setRecording(boolean recording) {
		this.recording = recording;
	}
	
	public boolean isRecording() {
		return this.recording;
	}
	
	public void setNodesVisited(Vector v) {
		this.nodesVisited = v;
	}
	
	public void addVisitedNode(String node) {
		synchronized(this) {
			nodesVisited.add(node);
			if (nodesVisited.size() > MAX_RECORDS) {
				boolean saved = this.outToFile(nodesVisited);
				
				if (saved) {
					nodesVisited.clear();
				}
			}
		}
	}
	
	public String getReport() {
		String report;
		
		synchronized(this) {
			// System.out.println("Report for " + this.methodName);
	    	if (!recording) return "";
	
	    	// Check if this method was never called.
	    	if (!hasFileInfo && nodesVisited.isEmpty()) {
	    		return "";
	    	}
	
	    	// If the nodes visited have been written out to a file, clear
	    	// the list and retrieve the list piece at a time.    	
	    	if (hasFileInfo) {
	    		if (!nodesVisited.isEmpty()) {
	    			this.outToFile(nodesVisited);
	    		}
	    		this.nodeListFinished();
	    		
	    		try {
	    			nodesVisited = this.readFromFile(null);
	    		} catch (Exception e) {
	    			System.out.println(e.toString());
	    			return "";
	    		}
	    	}
	    	      	
	    	boolean hasMoreNodes = true;
	    	boolean nodes[] = new boolean[nodeList.size()];
	    	boolean edges[] = new boolean[edgeList.size() / 2];
	    	int nodesFound = 0;
	    	int edgesFound = 0;
	    	Iterator iterator;
	    	
	    	while(hasMoreNodes) {
		    	// NODE COVERAGE
		    	// Figure out how many of the nodes have been covered.
		    	iterator = nodeList.keySet().iterator();
		    	int counter = 0;
		    	while (iterator.hasNext()) {
		    		String node = (String)iterator.next();
		    		if (nodesVisited.contains(node) && (!nodes[counter])) {
		    			nodes[counter] = true;
		    			nodesFound++;
		    		}
		    		counter++;
		    	}
		    	
				// EDGE COVERAGE
				
				// Check to see if the nodesVisited contains all of the edges.
				// Only need to check if the start of an edge series was visited.
				int index = 0;
				boolean edgeFound = false;
				
				for (int j = 0; j < edgeList.size(); j = j + 2) {
					// If the edge hasn't already been found.
					if (!edges[(j / 2)]) { 
						edgeFound = false;
						
						index = nodesVisited.indexOf(edgeList.elementAt(j));
						if (index == (nodesVisited.size() - 1)) index = -1;
						
						while((index != -1) && !edgeFound) {
							if (nodesVisited.elementAt(index + 1).equals(edgeList.elementAt(j+1))) {
								edgeFound = true;
							} else {
								index = index + 1;
							}
							index = nodesVisited.indexOf(edgeList.elementAt(j),index);
							if (index == (nodesVisited.size() - 1)) index = -1;
						}
						if (edgeFound) {
							edges[(j / 2)] = true;
							edgesFound++;
						}
					}
				}			
		/*		
				// ALL-DEFINITIONS COVERAGE
				report += "\n\tAll-Definitions Coverage\n";
				report += "\t-------------\n";
		
				i = defUseMap.keySet().iterator();
				countNodes = 0;
				String variableName = "";
				
				while(i.hasNext()) {
					String definition = (String)i.next();
					Vector useList = (Vector)defUseMap.get(definition);
					variableName = (String)useList.elementAt(0);
		
					// Get each definition in the paths taken. If there is a def-clear path to
					// a use for that definition, then that definition is covered.
					boolean pathFound = false;
					boolean breakout = false;
					int j = nodesVisited.indexOf(definition);
		
					if (j != -1) {
						for (j = nodesVisited.indexOf(definition); ((j < nodesVisited.size()) && !pathFound && !breakout); j++) {
							if (useList.contains(nodesVisited.elementAt(j))) {
								pathFound = true;
							} else if (nodesVisited.elementAt(j).equals(startNode)) {
								j = nodesVisited.indexOf(definition,j);
								breakout = (j == -1);
							}
						}
						
						if (!pathFound) {
							report += "\t\t Definition of " + variableName + " defined at " + nodeList.get(definition) + " not covered. \n";
						} else {
							countNodes++;
						}
					} else {
						// The defintion was not found, so it was not covered.
						report += "\t\t Definition of " + variableName + " defined at " + nodeList.get(definition) + " not covered. \n";
					}
				}
		
				percentCoverage = ((double)countNodes / (double)defUseMap.keySet().size() * 100);
				report += "\t" + percentCoverage + "% all-definitions covered.\n";
		
				// ALL-USES COVERAGE
				report += "\n\tAll-Uses Coverage\n";
				report += "\t-------------\n";
		
				i = defUseMap.keySet().iterator();
				countNodes = 0;
				int totalUses = 0;
				variableName = "";
				
				while(i.hasNext()) {
					String definition = (String)i.next();
					Vector useList = (Vector)defUseMap.get(definition);
					variableName = (String)useList.elementAt(0);
		
					// Get each definition in the paths taken. If there is a def-clear path to
					// a use for that definition, then that definition is covered.
					boolean pathFound = false;
					boolean useMissed = false;
					boolean breakout = false;
					
					totalUses += useList.size() - 1;
					
					int j = nodesVisited.indexOf(definition);
					if (j != -1) {
						for (int k = 1; k < useList.size() && !useMissed; k++) {
							
							pathFound = false;
							
							String currentUse = (String)useList.elementAt(k);
							
							for (j = nodesVisited.indexOf(definition); ((j < nodesVisited.size()) && !pathFound && !breakout); j++) {
								if (nodesVisited.elementAt(j).equals(currentUse)) {
									pathFound = true;
								} else if (nodesVisited.elementAt(j).equals(startNode)) {
									j = nodesVisited.indexOf(definition,j);
									breakout = (j == -1);
								}
							}
						
							if (!pathFound) {
								report += "\t\t Use of " + variableName + " at " + nodeList.get(currentUse) + " not covered. \n";
							} else {
								countNodes++;
							}
						}
					} else {
						// The defintion was not found, so it was not covered.
						report += "\t\t Definition of " + variableName + " not covered, so no uses covered. \n";
					}
				}
		
				percentCoverage = ((double)countNodes / (double)totalUses * 100);
				report += "\t" + percentCoverage + "% all-uses covered.\n";
		*/
				if(hasFileInfo) {
					try {
						String last = (String)nodesVisited.lastElement();
						nodesVisited.clear();
						nodesVisited = this.readFromFile(last);
					} catch (Exception e) {
						System.out.println("Error: " + e.toString());
						hasMoreNodes = false;
					}
				} else {
					hasMoreNodes = false;
				}
	    	}
	    	
	    	/* Create the report */
	    	report = "\n" + methodName + "\n";
	    	report += "===========================\n";
	    	
	    	report += "\tNode Coverage\n";
	    	report += "\t-------------\n";
	
	    	iterator = nodeList.keySet().iterator();
	    	int index = 0;
	    	while (iterator.hasNext()) {
	    		String node = (String)iterator.next();
	    		if (!nodes[index]) {
	    			report += "\t\t" + nodeList.get(node).toString() + " not covered. \n";
	    		}  
	    		index++;
	    	}    	
	    	double percentCoverage = ((double)(nodesFound) / (double)(nodeList.size())) * 100;    	    	
	    	report += "\t" + percentCoverage + "% nodes covered.\n";
	
			report += "\n\tEdge Coverage\n";
			report += "\t-------------\n";
			
			for (index = 0; index < edgeList.size(); index = index + 2) {
				if (!edges[index / 2]) {
					report += "\t\t Edge starting at " + nodeList.get(edgeList.elementAt(index)).toString() + " and ending at " + nodeList.get(edgeList.elementAt(index+1)).toString() + " not covered. \n";
				}
			}
			percentCoverage = ((double)edgesFound / ((double)edgeList.size() / 2) * 100);
			report += "\t" + percentCoverage + "% edges covered.\n";
	
			removeFile();
		}
		return report;		
	}
	
	private boolean outToFile(Vector list) {
		if (!this.bufferToFile) return false;
		
		if (!this.hasFileInfo || (this.tempFile == null)) { 
			tempFile = new File(this.fileName);
			try {
				if (tempFile.exists()) tempFile.delete();
				tempFile.createNewFile();
				ps = new PrintStream(new FileOutputStream(tempFile));
			} catch (Exception e) {
				bufferToFile = false;
				hasFileInfo = false;
				System.out.println("Unable to create file buffer for node list!! Output to file disabled.");
				return false;
			}
		}
		
		for (int i = 0; i < list.size(); i++) {
			String node = list.elementAt(i) + " ";
			ps.print(node);	
		}
		
		this.hasFileInfo = true;
		return true;
	}
	
	private void nodeListFinished() {
		if (ps != null) {
			bufferToFile = false;
			ps.close();
		}
		
	}
	
	private Vector readFromFile(String node) throws Exception {
		if (!this.hasFileInfo) return null;
				
		if (this.inputStream == null) {
			try {
				br = new BufferedReader(new FileReader(this.fileName));
				this.inputStream = new StreamTokenizer(br);
			} catch (Exception e) {
				throw new Exception ("Unable to read from the temp file. Cannot get buffered node list. Error was: " + e.toString());				
			}
		}
		
		Vector list = new Vector();
		
		int toAdd = MAX_RECORDS;
		if (node != null) {
			list.add(node);
			toAdd--;
		}
		
		for (int i = 0; i < toAdd; i++) {
			int token = this.inputStream.nextToken();
			if (token == StreamTokenizer.TT_EOF) {
				// End of file
				this.hasFileInfo = false;
				break;
			}
			else if (token == StreamTokenizer.TT_WORD) {
				list.add(inputStream.sval);
			}
		}

		if (!hasFileInfo) {
			this.br.close();
			this.br = null;
			this.inputStream = null;
		}
		
		return list;
	}
	
	private void removeFile() {
		try {
			hasFileInfo = false;
			bufferToFile = false;
			
			if (tempFile != null) {
				if (br != null) {
					this.br.close();
					this.br = null;
				}
				if (ps != null) {
					this.ps.close();
					this.br = null;
				}
				tempFile.delete();
				//tempFile.deleteOnExit();
			}
		} catch (Exception e) {
			System.out.println("Unable to delete file. Error was: " + e.toString());
			e.printStackTrace();
		}
	}
}