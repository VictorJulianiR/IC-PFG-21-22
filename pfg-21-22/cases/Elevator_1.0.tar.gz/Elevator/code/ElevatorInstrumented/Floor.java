import java.util.HashMap;
import java.util.Vector;

/**
 * This is the Floor Class. It consists of a list of the floors in the system
 * and each Floor object has its unique ID and an arrival sensor. Methods from 
 * this class interact with the Elevator class in order to service requests from 
 * users at a floor.
 */

public class Floor {

	private ArrivalSensor arrivalsensor;
	//public static int numFloors = ElevatorGroup.numFloors;
	private Elevator elevator;
	private static Observer obs;

	/*
	 * List of all the floors in the system
	 */
	private static Floor[] allFloors = null;


    /*
     * Unique floor number, sequential integers 0 to (numFloors - 1)
     */
    private int floorID;

   /*
    * button set to true when a request for elevator going up has been
    * made
    */
    private boolean upButtonPressed = false;

   /*
    * button set to true when a request for elevator going down has been
    * made
    */
    private boolean downButtonPressed = false;

   /*
    * Constructor that initializes reference to class ArrivalSensor
    * and adds this floor object to the list of floors
    */
    public Floor(int floorID){
    	if (obs == null) obs = new Observer();
		Floor.addVisitedNode("flr1");
		if (allFloors == null) {
    		Floor.addVisitedNode("flr2");
    		allFloors = new Floor[ElevatorGroup.numFloors];
    	}
		arrivalsensor = new ArrivalSensor(this);
	    this.floorID = floorID;
	    Floor.addVisitedNode("flr3");
	    Floor.allFloors[floorID] = this;
    }

   /*
    * @ return the reference to the desired
    * floor object from a list of floors in the system
    */
    public static Floor selectFloor(int floorID) {
    	addVisitedNode("sfl1");
    	if ((floorID < ElevatorGroup.numFloors) && (floorID > -1)) {
    		addVisitedNode("sfl2");
    		return allFloors[floorID];  
    	} else {
    		addVisitedNode("sfl3");
    		return null;
    	}
    }

   /*
    * @return number of floors in the system
    */
    public static int getNoFloors() {
    	addVisitedNode("gnf1");
    	return ElevatorGroup.numFloors;
    }

  /*
   * Makes a request for an elevator to stop at this floor, heading up.
   * This method is called by FloorControl, to get an elevator to service
   * the request and add the stop to the elevator's list of stops
   * 
   * @return the best elevator that can provide the service
   */
    public Elevator requestUp() {
    	addVisitedNode("rqu1");
	    upButtonPressed = true;
	    elevator = Elevator.getBestElevator(floorID);
	    if (floorID == ElevatorGroup.numFloors-1) {
	    	addVisitedNode("rqu2");
	    	System.out.println("No up requests are permitted at this floor.");
	    } else {
	    	addVisitedNode("rqu3");
	    	if (elevator.getFloor().getFloorID() != this.getFloorID()){
	    		addVisitedNode("rqu4");
	    		System.out.println("Request for elevator going UP made at floor " + floorID);
	    		System.out.println("Best Elevator is: "+ (elevator.getElevatorID()+1));
	    		elevator.addStop(floorID,true);
	    		System.out.println("Stop added at " +floorID);
	    	} else {
	    		addVisitedNode("rqu5");
	    		elevator.addStop(floorID,true);
	    	}
	    }
	    addVisitedNode("rqu6");
	    return elevator;
    }

  /*
   * Makes a request for an elevator to stop at this floor, heading down.
   * This method is called by FloorControl, to get an elevator to service 
   * the request and add the stop to the elevator's list of stops
   * 
   * @return the best elevator that can provide the service
   */
    public Elevator requestDown() {
    	addVisitedNode("rqd1");
	    downButtonPressed = true;
	    elevator = Elevator.getBestElevator(floorID); 
	    if (floorID == 0) {
	    	addVisitedNode("rqd2");
	    	System.out.println("No down requests are permitted at this floor.");
	    } else {
	    	addVisitedNode("rqd3");
	    	if (elevator.getFloor().getFloorID() != this.getFloorID()){
	    		addVisitedNode("rqd4");
	    		System.out.println("Request for elevator going DOWN made at floor " + floorID);
		    	System.out.println("Best Elevator is: "+ (elevator.getElevatorID()+1));
		    	elevator.addStop(floorID,true);
		    	System.out.println("Stop added at " + floorID);
	    	} else {
	    		addVisitedNode("rqd5");
	    		elevator.addStop(floorID,true);
	    	}
	    } 
	    addVisitedNode("rqd6");
	    return elevator;
	}

   /*
    * @return true when a request for elevator going up has already been
    * made
    */
    public boolean requestUpMade() {
    	addVisitedNode("rum1");
    	if(upButtonPressed == true) {
    		addVisitedNode("rum2");
	       return true;
        } else { 
        	addVisitedNode("rum3");
        	return false; 
        }
    }

   /*
    * @return true when a request for elevator going down has already been
    * made
    */
    public boolean requestDownMade() {
    	addVisitedNode("rdm1");
	    if (downButtonPressed == true) {
	    	addVisitedNode("rdm2");
	    	return true;
        } else { 
        	addVisitedNode("rdm3");
        	return false; 
        }
    }

   /*
    * Method called when a request for elevator going up has been serviced.
    * Resets the button for that floor.
    */
    public void requestUpServiced() {
    	addVisitedNode("rus1");
	    System.out.println("Elevator going UP has arrived at floor " + floorID+ ".");
	    upButtonPressed = false;
    }

   /*
    * Method called when a request for elevator going down has been serviced.
    * Resets the button for that floor.
    */
    public void requestDownServiced() {
    	addVisitedNode("rds1");
	    System.out.println("Elevator going DOWN has arrived at floor " + floorID+ ".");
	    downButtonPressed = false;
    }

	/*
	 * @return the ID of the floor object
	 */
	public int getFloorID() {
		addVisitedNode("gfi1");
		return floorID;
	}
	
	public static void removeFloors() {
		addVisitedNode("rmf1");
		allFloors = null;
	}

   /*
    * @return reference to the arrival sensor for the floor object
    */
    public ArrivalSensor getSensor(){
    	addVisitedNode("gas1");
    	return arrivalsensor;
    }
    
    public static String getReport() {
	   	if (obs.isRecording()) {
	   		return obs.getReport();
	   	} else {
	   		return "";
	   	}
   }
	   
   public static void startRecording() {
	   	// Setup the observer here.
	   	HashMap nodeList = new HashMap();
	   	
	   	nodeList.put("flr1","Constructor, Line 39: if (allFloors == null) ");   	
	   	nodeList.put("flr2","Constructor, Line 40: allFloors = new Floor[ElevatorGroup.numFloors];");   
	   	nodeList.put("flr3","Constructor, Line 44: Floor.allFloors[floorID] = this;");
	   	
	   	nodeList.put("sfl1","selectFloor, Line 52: if ((floorID < numFloors) && (floorID > -1)) {");
	   	nodeList.put("sfl2","selectFloor, Line 53: return allFloors[floorID];");
	   	nodeList.put("sfl3","selectFloor, Line 55: return null;");
	   	
	   	nodeList.put("gnf1","getNoFloors, Line 62: return numFloors;");
	   	nodeList.put("gnf2","getNoFloors, Line 63: }");
	   	
	   	nodeList.put("rum1","requestUpMade, Line 116: if(upButtonPressed == true) {");
	   	nodeList.put("rum2","requestUpMade, Line 117: return true;");
	   	nodeList.put("rum3","requestUpMade, Line 119: return false;");
	   	
	   	nodeList.put("rqu1","requestUp, Line 75: if (floorID == ElevatorGroup.numFloors-1) {");
	   	nodeList.put("rqu2","requestUp, Line 76: System.out.println(No up requests are permitted at this floor.);");
	   	nodeList.put("rqu3","requestUp, Line 77: } else if (elevator.getFloor().getFloorID() != this.getFloorID()){");
	   	nodeList.put("rqu4","requestUp, Line 78: System.out.println(Request for elevator going UP made at floor  + floorID);");
	   	nodeList.put("rqu5","requestUp, Line 83: elevator.addStop(floorID,true);");
	   	nodeList.put("rqu6","requestUp, Line 85: return elevator;");
	   	
	   	nodeList.put("rqd1","requestDown, Line 98: if (floorID == 0) {");
	   	nodeList.put("rqd2","requestDown, Line 99: System.out.println(No down requests are permitted at this floor.);");
	   	nodeList.put("rqd3","requestDown, Line 100: } else if (elevator.getFloor().getFloorID() != this.getFloorID()){");
	   	nodeList.put("rqd4","requestDown, Line 101: System.out.println(Request for elevator going DOWN made at floor  + floorID);");
	   	nodeList.put("rqd5","requestDown, Line 106: elevator.addStop(floorID,true);");
	   	nodeList.put("rqd6","requestDown, Line 108: return elevator;");
	   	
	   	nodeList.put("rdm1","requestDownMade, Line 128: if (downButtonPressed == true) {");
	   	nodeList.put("rdm2","requestDownMade, Line 129: return true;");
	   	nodeList.put("rdm3","requestDownMade, Line 131: return false;");
	   	
	   	nodeList.put("rus1","requestUpServiced, Line 140: System.out.println(Elevator going UP has arrived at floor  + floorID+ .);");
	   	nodeList.put("rus2","requestUpServiced, Line 142: }");
	   	
	   	nodeList.put("rds1","requestDownServiced, Line 149: System.out.println(Elevator going DOWN has arrived at floor  + floorID+ .);");
	   	nodeList.put("rds2","requestDownServiced, Line 151: }");
	   	
	   	nodeList.put("gfi1","getFloorID, Line 157: return floorID;");
	   	nodeList.put("gfi2","getFloorID, Line 158: }");
	   	
	   	nodeList.put("gas1","getSensor, Line 164: return arrivalsensor;");
	   	nodeList.put("gas2","getSensor, Line 165: }");
	   	
	   	nodeList.put("rmf1","removeFloors, Line 168: allFloors = null;");
	   	nodeList.put("rmf2","removeFloors, Line 169: }");
	   	
	   	Vector edgeList = new Vector();
		   	
	   	edgeList.add("flr1");
	   	edgeList.add("flr2");
		 
	   	edgeList.add("flr1");
	   	edgeList.add("flr3");
		 
	   	edgeList.add("flr2");
	   	edgeList.add("flr3");
		 
	   	edgeList.add("sfl1");
	   	edgeList.add("sfl2");
	   	
	   	edgeList.add("sfl1");
	   	edgeList.add("sfl3");
	   	
	   	edgeList.add("gnf1");
	   	edgeList.add("gnf2");
	   	
	   	edgeList.add("rum1");
	   	edgeList.add("rum2");
	   	
	   	edgeList.add("rum1");
	   	edgeList.add("rum3");
	   	
	   	edgeList.add("rqu1");
	   	edgeList.add("rqu2");
	   	
	   	edgeList.add("rqu1");
	   	edgeList.add("rqu3");
	   	
	   	edgeList.add("rqu2");
	   	edgeList.add("rqu6");
	   	
	   	edgeList.add("rqu3");
	   	edgeList.add("rqu4");
	   	
	   	edgeList.add("rqu3");
	   	edgeList.add("rqu5");
	   	
	   	edgeList.add("rqu4");
	   	edgeList.add("rqu6");
	   	
	   	edgeList.add("rqu5");
	   	edgeList.add("rqu6");
	   	
	   	edgeList.add("rqd1");
	   	edgeList.add("rqd2");
	   	
	   	edgeList.add("rqd1");
	   	edgeList.add("rqd3");
	   	
	   	edgeList.add("rqd2");
	   	edgeList.add("rqd6");
	   	
	   	edgeList.add("rqd3");
	   	edgeList.add("rqd4");
	   	
	   	edgeList.add("rqd3");
	   	edgeList.add("rqd5");
	   	
	   	edgeList.add("rqd4");
	   	edgeList.add("rqd6");
	   	
	   	edgeList.add("rqd5");
	   	edgeList.add("rqd6");
	   	
	   	edgeList.add("rdm1");
	   	edgeList.add("rdm2");
	   	
	   	edgeList.add("rdm1");
	   	edgeList.add("rdm3");
	   	
	   	edgeList.add("rus1");
	   	edgeList.add("rus2");
	   	
	   	edgeList.add("rds1");
	   	edgeList.add("rds2");
	   	
	   	edgeList.add("gfi1");
	   	edgeList.add("gfi2");
	   	
	   	edgeList.add("gas1");
	   	edgeList.add("gas2");
	   	
	   	edgeList.add("rmf1");
	   	edgeList.add("rmf2");
	   	
	   	obs = new Observer(nodeList, null, edgeList, "flr1", "Floor Class");
	   	obs.setRecording(true);
   }

   private static void addVisitedNode(String nodename) {
	   	if (obs == null || !obs.isRecording()) return;
	   	
	   	// Adding nodes here.
	   	if (nodename.equals("flr1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("flr2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("flr3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("sfl1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("sfl2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("sfl3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("gnf1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gnf2");
	   	} else if (nodename.equals("rum1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rum2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rum3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqu1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqu2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqu3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqu4")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqu5")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqu6")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqd1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqd2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqd3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqd4")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqd5")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rqd6")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rdm1")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rdm2")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rdm3")) {
	   		obs.addVisitedNode(nodename);
	   	} else if (nodename.equals("rus1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("rus2");	   	
	   	} else if (nodename.equals("rds1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("rds2");	   	
	   	} else if (nodename.equals("gfi1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gfi2");	   	
	   	} else if (nodename.equals("gas1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("gas2");	   	
	   	} else if (nodename.equals("rmf1")) {
	   		obs.addVisitedNode(nodename);
	   		obs.addVisitedNode("rmf2");
	   	} else {
	   		obs.addVisitedNode(nodename);
	   	}
   }
}
