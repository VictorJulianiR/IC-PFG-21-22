// This is mutant program.
// Author : ysma

public class CruiseControl
{

    CarSimulator car;

    Controller control;

    public CruiseControl()
    {
        car = new CarSimulator();
        control = new Controller( car );
    }

    public boolean handleCommand( java.lang.String command )
    {
        if (command.equals( "engineOn" )) {
            car.engineOn();
            control.engineOn();
            return true;
        } else {
            if (command.equals( "engineOff" )) {
                car.engineOff();
                control.engineOff();
                return true;
            } else {
                if (command.equals( "accelerator" )) {
                    car.accelerate();
                    control.accelerator();
                    return true;
                } else {
                    if (command.equals( "brake" )) {
                        car.brake();
                        control.brake();
                        return true;
                    } else {
                        if (command.equals( "on" )) {
                            control.on();
                            return true;
                        } else {
                            if (command.equals( "off" )) {
                                control.off();
                                return true;
                            } else {
                                if (command.equals( "resume" )) {
                                    control.resume();
                                    return true;
                                } else {
                                    return false;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public CarSimulator getCar()
    {
        return car;
    }

    public Controller getControl()
    {
        return control;
    }

}
