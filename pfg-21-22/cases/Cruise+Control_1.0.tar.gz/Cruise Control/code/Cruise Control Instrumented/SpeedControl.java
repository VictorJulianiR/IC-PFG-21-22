

import java.util.Vector;
import java.util.HashMap;

public class SpeedControl implements Runnable {
  	final static int DISABLED = 0; //speed control states
  	final static int ENABLED  = 1;
  	private int state = DISABLED;  //initial state
  	private int setSpeed = 0;      //target cruise control speed
  	private Thread speedController;
  	private CarSimulator cs;           //interface to control speed of engine

  	private static Observer obs;
  	
	// -----------
	// Constructor
	// ----------- 
	/**
	 * constructs a speed controller for the car simulator specified
	 * in parameters
	 * 
	 * @param cs - interface of the car simulator to control its speed
	 */
  	SpeedControl(CarSimulator cs){
  		this.addVisitedNode("sc0");
    	this.cs=cs; 
  	}

	/**
	 * Sets the target cruise control speed to the car current speed
	 */
  	synchronized void recordSpeed(){
  		this.addVisitedNode("sc1");
  		setSpeed=cs.getSpeed(); 
  	}

	/**
	 * It clears the target cruise control speed.
	 * It is used by Controller to reset target cruise control speed
	 * when the car engine is first started (before enabling cruising)
	 */
  	synchronized void clearSpeed(){
  		this.addVisitedNode("sc2");
    	if (state==DISABLED) {
    		this.addVisitedNode("sc3");
    		setSpeed=0;
    	}
    	this.addVisitedNode("sc4");
  	}

	/**
	 * Enables cruise control
	 */
  	synchronized void enableControl(){
  		this.addVisitedNode("sc5");
    	if (state==DISABLED) {
    		this.addVisitedNode("sc6");
      		speedController= new Thread(this);
      		speedController.start();
      		state=ENABLED;
    	}
    	this.addVisitedNode("sc7");
  	}

	/**
	 * Disables cruise control
	 */
  	synchronized void disableControl(){
  		this.addVisitedNode("sc8");
    	if (state==ENABLED)  {
    		this.addVisitedNode("sc9");
    		state=DISABLED;
    	}
    	this.addVisitedNode("sc10");
  	}

	/**
	 * The speed controller thread is started when cruising enabled.
	 * It runs until the cruise control is disabled.
	 * While running, the speed controller verifies every 0.5 second
	 * the current car speed and adjusts the car throttle based on 
	 * the current car speed and the target cruise control speed
	 */
  	public void run() {     // the speed controller thread
    	this.addVisitedNode("sc11");
  		try {
    		this.addVisitedNode("sc12");
      		while (state==ENABLED) {
      			this.addVisitedNode("sc13");
        		if (state==ENABLED) synchronized(this) {
        				this.addVisitedNode("sc14");
	          			double error = (float)(setSpeed-cs.getSpeed())/6.0;
	          			double steady = (double)setSpeed/12.0;
	          			cs.setThrottle(steady+error); //simplified feed back control
        		}
        		this.addVisitedNode("sc15");
        		Thread.sleep(500);
      		}
    	} catch (InterruptedException e) {}
    	this.addVisitedNode("sc16");
    	speedController=null;
  	}

  	/**
  	 * @return state - cruise control enabled (1) or disabled (0)
  	 */
  	public int getState(){
  		this.addVisitedNode("sc17");
	  	return state;
  	}
  	
  	/**
  	 * @return the target cruise speed
  	 */
  	public int getCruiseSpeed() {
  		this.addVisitedNode("sc18");
  		return setSpeed;
  	}
  	
  	public static String getReport() {
  		if (obs.isRecording()) {
  			return obs.getReport();
  		}
  		return "";
  	}
  	
  	public static void startRecording() {
  		// Setup recording here.
  		HashMap nodeList = new HashMap();
   		nodeList.put("sc0","Constructor, Line 27: this.cs=cs;");
  		nodeList.put("sc1","recordSpeed(), Line 34: setSpeed=cs.getSpeed();");
  		nodeList.put("sc2","clearSpeed(), Line 33: if (state==DISABLED)");
  		nodeList.put("sc3","clearSpeed(), Line 34: setSpeed=0;");
  		nodeList.put("sc4","clearSpeed(), Line 35: End if. return;");
  		nodeList.put("sc5","enableControl(), Line 52: if (state==DISABLED)");
  		nodeList.put("sc6","enableControl(), Line 53: speedController= new Thread(this);");
  		nodeList.put("sc7","enableControl(), Line 56: End if. return;");
  		nodeList.put("sc8","disableControl(), Line 63: if (state==ENABLED)");
  		nodeList.put("sc9","disableControl(), Line 64: state=DISABLED;");
  		nodeList.put("sc10","disableControl(), Line 65: End if. return;");
  		nodeList.put("sc11","run(), Line 76: try {");
  		nodeList.put("sc12","run(), Line 77: while (state==ENABLED)");
  		nodeList.put("sc13","run(), Line 78: if (state==ENABLED) synchronized(this) {");
  		nodeList.put("sc14","run(), Line 79: double error = (float)(setSpeed-cs.getSpeed())/6.0;");
  		nodeList.put("sc15","run(), Line 83: Thread.sleep(500);");
  		nodeList.put("sc16","run(), Line 86: speedController=null;");
  		nodeList.put("sc17","getState(), Line 93: return state;");
  		nodeList.put("sc18","getCruiseSpeed(), Line 100: return setSpeed;");
  		
  		Vector edgeList = new Vector();
  		
  		edgeList.add("sc2");
  		edgeList.add("sc3");
  		
  		edgeList.add("sc2");
  		edgeList.add("sc4");
  		
  		edgeList.add("sc3");
  		edgeList.add("sc4");
  		
  		edgeList.add("sc5");
  		edgeList.add("sc6");
  		
  		edgeList.add("sc5");
  		edgeList.add("sc7");
  		
  		edgeList.add("sc6");
  		edgeList.add("sc7");
  		
  		edgeList.add("sc8");
  		edgeList.add("sc9");
  		
  		edgeList.add("sc8");
  		edgeList.add("sc10");
  		
  		edgeList.add("sc9");
  		edgeList.add("sc10");
  		
  		edgeList.add("sc11");
  		edgeList.add("sc12");
  		
  		edgeList.add("sc12");
  		edgeList.add("sc13");
  		
  		edgeList.add("sc12");
  		edgeList.add("sc16");
  		
  		edgeList.add("sc13");
  		edgeList.add("sc14");
  		
  		edgeList.add("sc13");
  		edgeList.add("sc15");
  		
  		edgeList.add("sc14");
  		edgeList.add("sc15");
  		
  		edgeList.add("sc15");
  		edgeList.add("sc12");
   		
  		obs = new Observer(nodeList, null, edgeList, "sc0", "SpeedControl Class");
  		obs.setRecording(true);
  	}
  	
  	private void addVisitedNode(String nodeName) {
  		if (obs == null || !obs.isRecording()) return;
  		// Add visited nodes.
  		if(nodeName.equals("sc0")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc1")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc2")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc3")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc4")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc5")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc6")) {
  			obs.addVisitedNode(nodeName);
  			obs.addVisitedNode("sc7");
  		} else if (nodeName.equals("sc7")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc8")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc9")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc10")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc11")) {
  			obs.addVisitedNode(nodeName);
  			obs.addVisitedNode("sc12");
  		} else if (nodeName.equals("sc13")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc14")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc15")) {
  			obs.addVisitedNode(nodeName);
  			obs.addVisitedNode("sc12");
  		} else if (nodeName.equals("sc16")) {
  			obs.addVisitedNode(nodeName);
   		} else if (nodeName.equals("sc17")) {
  			obs.addVisitedNode(nodeName);
  		} else if (nodeName.equals("sc18")) {
  			obs.addVisitedNode(nodeName);
  		} else {
  			obs.addVisitedNode(nodeName);
  		}
  	}
}
