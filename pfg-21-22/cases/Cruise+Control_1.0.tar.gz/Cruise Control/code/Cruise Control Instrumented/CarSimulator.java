

import java.util.HashMap;
import java.util.Vector;

public class CarSimulator implements Runnable {

    private boolean ignition = false;     //engine off
    private double throttle = 0.0;        //throttle setting 0 .. 10, controlling the amount of gaz getting to the engine
    private int speed = 0;                //speed 0 .. 120 mph!, actual simulated car speed
    private int distance = 0;             //the crossed distance since starting the engine 
    private int brakepedal = 0;           //brake setting 0..10, allowing different levels of braking
    Thread engine = null;				  //car engine, null when the car is stopped 
	
    final static int maxSpeed = 120;
    final static double maxThrottle = 10.0;
    final static int maxBrake = 10;
    final static double airResistance = 12.5;  //inverse air resistance factor
    final static int ticksPerSecond = 5;

    private static Observer obs;
    
	// -----------
	// Constructor
	// -----------    
    public CarSimulator() {
        super();
        this.addVisitedNode("cs0");
    }

    /**
     * Starting the car engine. It creates a thread for the engine.
     */
    public synchronized void  engineOn(){
        this.addVisitedNode("cs1");
    	ignition = true;
        if (engine==null) {
        	this.addVisitedNode("cs3");
            engine = new Thread(this);
            engine.start();
        }
        this.addVisitedNode("cs4");
    }

    /**
     * Stopping the car engine. Resets all parameters.
     */
    public synchronized void  engineOff() {
    	this.addVisitedNode("cs5");
    	ignition = false;
        speed=0;
        distance=0;
        throttle=0;
        brakepedal=0;
        engine=null;
    }

    /**
     * When the engine is started, the throttle setting is incremented 
     * by 5 if not already at its maximum otherwise it is set to the maximum 
     * throttle value.
     */
    public synchronized void accelerate() {
    	this.addVisitedNode("cs6");
    	if (engine != null) {
    		this.addVisitedNode("cs7");
        	if (brakepedal>0) {
        		this.addVisitedNode("cs8");
        		brakepedal=0;
        	}
        	this.addVisitedNode("cs9");
           	if (throttle<(maxThrottle-5)) {
           		this.addVisitedNode("cs10");
               	throttle +=5.0;
           	} else {
           		this.addVisitedNode("cs11");
            	throttle=maxThrottle;
           	}
        }
    	this.addVisitedNode("cs12");
	}

    /**
     * When the engine is started, the brake setting is incremented 
     * by 1 if not already at its maximum otherwise it is set to the maximum 
     * braking value.
     */    
    public synchronized void brake() {
    	this.addVisitedNode("cs13");
        if (engine != null) {
        	this.addVisitedNode("cs14");
       		if (throttle>0) {
       			this.addVisitedNode("cs15");
       			throttle=0.0;
       		}
       		this.addVisitedNode("cs16");
       		if (brakepedal<(maxBrake-1)) {
       			this.addVisitedNode("cs17");
                brakepedal +=1;
       		} else {
       			this.addVisitedNode("cs18");
                brakepedal=maxBrake;
       		}
        }
        this.addVisitedNode("cs19");
    }

    /**
     * When the engine is started, the engine thread runs until it
     * is turned off. While running, speed and distance are
     * updated every 200 milliseconds
     *
     */
    public void run(){
      try {
    	this.addVisitedNode("cs20");
        double fdist=0.0;
        double fspeed=0.0;
        while (engine!=null) {
            synchronized(this) {
            	this.addVisitedNode("cs22");
            	//updating the speed based on the actual speed, throttle and brakepedal values
                fspeed = fspeed+((throttle - fspeed/airResistance - 2*brakepedal))/ticksPerSecond;
                if (fspeed>maxSpeed) {
                	this.addVisitedNode("cs24");
                	fspeed=maxSpeed;
                }
                this.addVisitedNode("cs25");
                if (fspeed<0) {
                	this.addVisitedNode("cs26");
                	fspeed=0;
                }
                this.addVisitedNode("cs27");
                //updating the distance based on the calculated speed
                fdist = fdist + (fspeed/36.0)/ticksPerSecond;
                speed = (int)fspeed;
                distance=(int)fdist;
                //adjusting throttle value to account for decay
                if (throttle>0.0) {
                	this.addVisitedNode("cs29");
                	throttle-=0.5/ticksPerSecond; //throttle decays
                }
                this.addVisitedNode("cs28A");
                if (throttle<0.0) {
                	this.addVisitedNode("cs29A");
                	throttle = 0.0;
                }
            }
            this.addVisitedNode("cs30");
            Thread.sleep(1000/ticksPerSecond);
        }
      } catch (InterruptedException e) {
      		System.out.println("Interrupted Exception caught.");
      }
      this.addVisitedNode("cs31");
    }

    /**
     * The controller set the throttle value while the cruise control is on
     * to adjust the car speed
     */
    public synchronized void setThrottle(double val) {
    	this.addVisitedNode("cs32");
    	throttle=val;
        if (throttle<0.0) {
        	this.addVisitedNode("cs34");
        	throttle=0.0;
        }
        this.addVisitedNode("cs35");
        if (throttle>10.0) {
        	this.addVisitedNode("cs36");
        	throttle=10.0;
        }
        this.addVisitedNode("cs37");
        brakepedal=0;
    }

    /**
     * @return current car speed
     */
    public synchronized int getSpeed() {
    	this.addVisitedNode("cs38");
    	return speed;
    }
    
    /**
     * @return current ignition state - true if the car is started, false otherwise
     */
    public synchronized boolean getIgnition() {
    	this.addVisitedNode("cs39");
      return ignition;
    }
 
    /**
     * @return throttle level
     */
    public synchronized double getThrottle() {
    	this.addVisitedNode("cs40");
      return throttle;
    }

    /**
     * @return current brakepedal level
     */
    public synchronized int getBrakepedal() {
    	this.addVisitedNode("cs41");
      return brakepedal;
    }
    
    /**
     * @return current distance
     */   
    public synchronized int getDistance() {
    	this.addVisitedNode("cs42");
    	return distance;
    }
    
    public static String getReport() {
    	if (obs.isRecording()) {
    		return obs.getReport();
    	} else {
    		return "";
    	}
    }
    
    public static void startRecording() {
    	// Setup the observer here.
    	HashMap nodeList = new HashMap();
    	
    	nodeList.put("cs0","Constructor, Line 27: super();");
    	nodeList.put("cs1","engineOn(), Line 32: ignition = true;");
    	nodeList.put("cs2","engineOn(), Line 33: if (engine==null) ");
    	nodeList.put("cs3","engineOn(), Line 34: engine = new Thread(this);");
    	nodeList.put("cs4","engineOn(), Line 36: End If. return;");
    	nodeList.put("cs5","engineOff(), Line 43: ignition = false;");
    	nodeList.put("cs6","accelerate(), Line 57: if (engine != null)");
    	nodeList.put("cs7","accelerate(), Line 58: if (brakepedal>0)");
    	nodeList.put("cs8","accelerate(), Line 58: brakepedal=0;");
    	nodeList.put("cs9","accelerate(), Line 59: if (throttle<(maxThrottle-5))");
    	nodeList.put("cs10","accelerate(), Line 60: throttle +=5.0;");
    	nodeList.put("cs11","accelerate(), Line 62: throttle=maxThrottle;");
    	nodeList.put("cs12","accelerate(), Line 63: End If. return;");
    	nodeList.put("cs13","brake(), Line 72: if (engine != null)");
    	nodeList.put("cs14","brake(), Line 73: if (throttle>0)");
    	nodeList.put("cs15","brake(), Line 73: throttle=0.0;");
    	nodeList.put("cs16","brake(), Line 74: if (brakepedal<(maxBrake-1))");
    	nodeList.put("cs17","brake(), Line 75: brakepedal +=1;");
    	nodeList.put("cs18","brake(), Line 77: brakepedal=maxBrake;");
    	nodeList.put("cs19","brake(), Line 78: End if; return;");
    	
    	nodeList.put("cs20","run(), Line 89: double fdist=0.0;");
    	nodeList.put("cs21","run(), Line 91: while (engine!=null)");
    	nodeList.put("cs22","run(), Line 94: fspeed = fspeed+((throttle - fspeed/airResistance - 2*brakepedal))/ticksPerSecond;");
    	nodeList.put("cs23","run(), Line 95: if (fspeed>maxSpeed)");
    	nodeList.put("cs24","run(), Line 95: fspeed=maxSpeed;");
    	nodeList.put("cs25","run(), Line 96: if (fspeed<0)");
    	nodeList.put("cs26","run(), Line 96: fspeed=0;");
    	nodeList.put("cs27","run(), Line 98: fdist = fdist + (fspeed/36.0)/ticksPerSecond;");
    	nodeList.put("cs28","run(), Line 102: if (throttle>0.0)");
    	nodeList.put("cs28A","run(), Line 102: if (throttle<0.0)");
    	nodeList.put("cs29","run(), Line 102: throttle-=0.5/ticksPerSecond;");
    	nodeList.put("cs29A","run(), Line 102: throttle=0;");
    	nodeList.put("cs30","run(), Line 104: Thread.sleep(1000/ticksPerSecond);");
    	nodeList.put("cs31","run(), Line 104: End While Loop");
    	
    	nodeList.put("cs32","setThrottle(), Line 116: throttle=val;");
    	nodeList.put("cs33","setThrottle(), Line 117: if (throttle<0.0)");
    	nodeList.put("cs34","setThrottle(), Line 117: throttle=0.0;");
    	nodeList.put("cs35","setThrottle(), Line 118: if (throttle>10.0)");
    	nodeList.put("cs36","setThrottle(), Line 118: throttle=10.0;");
    	nodeList.put("cs37","setThrottle(), Line 119: brakepedal=0;");
    	
    	nodeList.put("cs38","getSpeed(), Line 126: return speed;");
    	nodeList.put("cs39","getIgnition(), Line 133: return ignition;");
    	nodeList.put("cs40","getThrottle(), Line 140: return throttle;");
    	nodeList.put("cs41","getBrakepedal(), Line 147: return brakepedal;");
    	nodeList.put("cs42","getDistance(), Line 154: return distance;");
    	
    	Vector edgeList = new Vector();
    	
    	edgeList.add("cs1");
    	edgeList.add("cs2");
    	
    	edgeList.add("cs2");
    	edgeList.add("cs3");
    	
    	edgeList.add("cs2");
    	edgeList.add("cs4");
    	
    	edgeList.add("cs3");
    	edgeList.add("cs4");
    	
    	edgeList.add("cs6");
    	edgeList.add("cs7");
    	
    	edgeList.add("cs6");
    	edgeList.add("cs12");
    	
    	edgeList.add("cs7");
    	edgeList.add("cs8");
    	
    	edgeList.add("cs7");
    	edgeList.add("cs9");
    	
    	edgeList.add("cs8");
    	edgeList.add("cs9");
    	
    	edgeList.add("cs9");
    	edgeList.add("cs10");
    	
    	edgeList.add("cs9");
    	edgeList.add("cs11");
    	
    	edgeList.add("cs10");
    	edgeList.add("cs12");
    	
    	edgeList.add("cs11");
    	edgeList.add("cs12");
    	
    	edgeList.add("cs13");
    	edgeList.add("cs14");
    	
    	edgeList.add("cs13");
    	edgeList.add("cs19");
    	
    	edgeList.add("cs14");
    	edgeList.add("cs15");
    	
    	edgeList.add("cs14");
    	edgeList.add("cs16");
    	
    	edgeList.add("cs15");
    	edgeList.add("cs16");
    	
    	edgeList.add("cs16");
    	edgeList.add("cs17");
    	
    	edgeList.add("cs16");
    	edgeList.add("cs18");
    	
    	edgeList.add("cs17");
    	edgeList.add("cs19");
    	
    	edgeList.add("cs18");
    	edgeList.add("cs19");
    	
    	edgeList.add("cs20");
    	edgeList.add("cs21");
    	
    	edgeList.add("cs21");
    	edgeList.add("cs31");
    	
    	edgeList.add("cs21");
    	edgeList.add("cs22");
    	
    	edgeList.add("cs22");
    	edgeList.add("cs23");
    	
    	edgeList.add("cs23");
    	edgeList.add("cs24");
    	
    	edgeList.add("cs23");
    	edgeList.add("cs25");
    	
    	edgeList.add("cs24");
    	edgeList.add("cs25");
    	
    	edgeList.add("cs25");
    	edgeList.add("cs26");
    	
    	edgeList.add("cs25");
    	edgeList.add("cs27");
    	
    	edgeList.add("cs26");
    	edgeList.add("cs27");
    	
    	edgeList.add("cs27");
    	edgeList.add("cs28");
    	
    	edgeList.add("cs28");
    	edgeList.add("cs29");
    	
    	edgeList.add("cs28");
    	edgeList.add("cs28A");
    	
    	edgeList.add("cs29");
    	edgeList.add("cs28A");
    	
    	edgeList.add("cs28A");
    	edgeList.add("cs29A");
    	
    	edgeList.add("cs29A");
    	edgeList.add("cs30");
    	
    	edgeList.add("cs28A");
    	edgeList.add("cs30");
    	
    	edgeList.add("cs30");
    	edgeList.add("cs21");
    	
    	edgeList.add("cs32");
    	edgeList.add("cs33");
    	
    	edgeList.add("cs33");
    	edgeList.add("cs34");
    	
    	edgeList.add("cs33");
    	edgeList.add("cs35");
    	
    	edgeList.add("cs34");
    	edgeList.add("cs35");
    	
    	edgeList.add("cs35");
    	edgeList.add("cs36");
    	
    	edgeList.add("cs35");
    	edgeList.add("cs37");
    	
    	edgeList.add("cs36");
    	edgeList.add("cs37");
    	
    	obs = new Observer(nodeList, null, edgeList, "cs0", "CarSimulator Class");
    	obs.setRecording(true);
    }

    private void addVisitedNode(String nodename) {
    	if (obs == null || !obs.isRecording()) return;
    	
    	// Adding nodes here.
    	if (nodename.equals("cs0")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs1")) {
    		obs.addVisitedNode(nodename);
    		obs.addVisitedNode("cs2");
    	} else if (nodename.equals("cs3")) {
    		obs.addVisitedNode(nodename);
    		obs.addVisitedNode("cs4");
    	} else if (nodename.equals("cs4")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs5")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs6")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs7")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs8")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs9")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs10")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs11")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs12")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs13")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs14")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs15")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs16")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs17")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs18")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs19")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs20")) {
    		obs.addVisitedNode(nodename);
    		obs.addVisitedNode("cs21");
    	} else if (nodename.equals("cs22")) {
    		obs.addVisitedNode(nodename);
    		obs.addVisitedNode("cs23");
    	} else if (nodename.equals("cs24")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs25")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs26")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs27")) {
    		obs.addVisitedNode(nodename);
    		obs.addVisitedNode("cs28");
    	} else if (nodename.equals("cs28A")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs29A")) {
    		obs.addVisitedNode(nodename);
    		obs.addVisitedNode("cs30");
    	} else if (nodename.equals("cs29")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs30")) {
    		obs.addVisitedNode(nodename);
    		obs.addVisitedNode("cs21");
    	} else if (nodename.equals("cs31")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs32")) {
    		obs.addVisitedNode(nodename);
    		obs.addVisitedNode("cs33");
    	} else if (nodename.equals("cs34")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs35")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs36")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs37")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs38")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs39")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs40")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs41")) {
    		obs.addVisitedNode(nodename);
    	} else if (nodename.equals("cs42")) {
    		obs.addVisitedNode(nodename);
    	} else {
    		obs.addVisitedNode(nodename);
    	}
    }
}
