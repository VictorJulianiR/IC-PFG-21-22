
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

/**
 * @author mike
 *
 */
class Observer {

	private Vector nodesVisited;
	private HashMap nodeList;
	private HashMap defUseMap;
	private Vector edgeList;
	private boolean recording;
	private String startNode;
	private String methodName;
	private Vector lastVisited = new Vector(); //Added for method branching

	public Observer() {
		this(null,null,null,null,"");
		this.recording = false;
	}
	
	public Observer(HashMap nodeList,
					HashMap defUseMap,
					Vector edgeList,
					String startNode,
					String methodName) {
		this.nodeList = nodeList;
		this.defUseMap = defUseMap;
		this.edgeList = edgeList;
		this.startNode = startNode;
		this.methodName = methodName;
		
		nodesVisited = new Vector();
	}
	
	public void setRecording(boolean recording) {
		this.recording = recording;
	}
	
	public boolean isRecording() {
		return this.recording;
	}
	
	public void setNodesVisited(Vector v) {
		this.nodesVisited = v;
	}
	
	public void addVisitedNode(String node) {
		nodesVisited.add(node);
	}
	
	//Added for method branching
	public void addLastVisited(String node) {
		lastVisited.add(node);
	}
	
	public String getLastVisited() {
		if (lastVisited.size() > 0) {
			return (String) lastVisited.lastElement();
		} else {
			return "";
		}
	}
	
	public void removeLastVisited() {
		if (lastVisited.size() > 0) {
			lastVisited.remove(lastVisited.size() - 1);
		}
	}
	//Adds Finished 
	
	public String getReport() {
		
    	if (!recording) return "";

    	// If this method was never executed.
    	if (nodesVisited.isEmpty()) return "";
    	
    	String report = "\n" + methodName + "\n";
    	report += "===========================\n";
    	report += "\tNode Coverage\n";
    	report += "\t-------------\n";
    	
    	// NODE COVERAGE
    	// Figure out how many of the nodes have been covered.
    	Iterator i = nodeList.keySet().iterator();
    	Vector missedNodes = new Vector();
    	
    	while (i.hasNext()) {
    		String node = (String)i.next();
    		if (!nodesVisited.contains(node)) {
				missedNodes.add(node);
    		}
    	}
    	
    	double percentCoverage = ((double)(nodeList.size() - missedNodes.size()) / (double)(nodeList.size())) * 100;    	
    	for(int j = 0; j < missedNodes.size(); j++) {
    		report += "\t\t" + nodeList.get(missedNodes.elementAt(j)).toString() + " not covered. \n";
    	}
    	report += "\t" + percentCoverage + "% nodes covered.\n";
    	
		// EDGE COVERAGE
		report += "\n\tEdge Coverage\n";
		report += "\t-------------\n";
		
		// Check to see if the nodesVisited contains all of the edges.
		// Only need to check if the start of an edge series was visited.
		int countNodes = edgeList.size() / 2;
		int index = 0;
		boolean edgeFound = false;
		
		for (int j = 0; j < edgeList.size(); j = j + 2) {
			
			edgeFound = false;
			index = nodesVisited.indexOf(edgeList.elementAt(j));
			
			while((index != -1) && !edgeFound) {
				if (nodesVisited.elementAt(index + 1).equals(edgeList.elementAt(j+1))) {
					edgeFound = true;
				} else {
					index = index + 1;
				}
				index = nodesVisited.indexOf(edgeList.elementAt(j),index);
			}
			if (!edgeFound) {
				countNodes--;
				report += "\t\t Edge starting at " + nodeList.get(edgeList.elementAt(j)).toString() + " and ending at " + nodeList.get(edgeList.elementAt(j+1)).toString() + " not covered. \n";				
			}
		}
		
		percentCoverage = ((double)countNodes / ((double)edgeList.size() / 2) * 100);
		report += "\t" + percentCoverage + "% edges covered.\n";
		
/*		
		// ALL-DEFINITIONS COVERAGE
		report += "\n\tAll-Definitions Coverage\n";
		report += "\t-------------\n";

		i = defUseMap.keySet().iterator();
		countNodes = 0;
		String variableName = "";
		
		while(i.hasNext()) {
			String definition = (String)i.next();
			Vector useList = (Vector)defUseMap.get(definition);
			variableName = (String)useList.elementAt(0);

			// Get each definition in the paths taken. If there is a def-clear path to
			// a use for that definition, then that definition is covered.
			boolean pathFound = false;
			boolean breakout = false;
			int j = nodesVisited.indexOf(definition);

			if (j != -1) {
				for (j = nodesVisited.indexOf(definition); ((j < nodesVisited.size()) && !pathFound && !breakout); j++) {
					if (useList.contains(nodesVisited.elementAt(j))) {
						pathFound = true;
					} else if (nodesVisited.elementAt(j).equals(startNode)) {
						j = nodesVisited.indexOf(definition,j);
						breakout = (j == -1);
					}
				}
				
				if (!pathFound) {
					report += "\t\t Definition of " + variableName + " defined at " + nodeList.get(definition) + " not covered. \n";
				} else {
					countNodes++;
				}
			} else {
				// The defintion was not found, so it was not covered.
				report += "\t\t Definition of " + variableName + " defined at " + nodeList.get(definition) + " not covered. \n";
			}
		}

		percentCoverage = ((double)countNodes / (double)defUseMap.keySet().size() * 100);
		report += "\t" + percentCoverage + "% all-definitions covered.\n";

		// ALL-USES COVERAGE
		report += "\n\tAll-Uses Coverage\n";
		report += "\t-------------\n";

		i = defUseMap.keySet().iterator();
		countNodes = 0;
		int totalUses = 0;
		variableName = "";
		
		while(i.hasNext()) {
			String definition = (String)i.next();
			Vector useList = (Vector)defUseMap.get(definition);
			variableName = (String)useList.elementAt(0);

			// Get each definition in the paths taken. If there is a def-clear path to
			// a use for that definition, then that definition is covered.
			boolean pathFound = false;
			boolean useMissed = false;
			boolean breakout = false;
			
			totalUses += useList.size() - 1;
			
			int j = nodesVisited.indexOf(definition);
			if (j != -1) {
				for (int k = 1; k < useList.size() && !useMissed; k++) {
					
					pathFound = false;
					
					String currentUse = (String)useList.elementAt(k);
					
					for (j = nodesVisited.indexOf(definition); ((j < nodesVisited.size()) && !pathFound && !breakout); j++) {
						if (nodesVisited.elementAt(j).equals(currentUse)) {
							pathFound = true;
						} else if (nodesVisited.elementAt(j).equals(startNode)) {
							j = nodesVisited.indexOf(definition,j);
							breakout = (j == -1);
						}
					}
				
					if (!pathFound) {
						report += "\t\t Use of " + variableName + " at " + nodeList.get(currentUse) + " not covered. \n";
					} else {
						countNodes++;
					}
				}
			} else {
				// The defintion was not found, so it was not covered.
				report += "\t\t Definition of " + variableName + " not covered, so no uses covered. \n";
			}
		}

		percentCoverage = ((double)countNodes / (double)totalUses * 100);
		report += "\t" + percentCoverage + "% all-uses covered.\n";
*/
		return report;		
	}	
}