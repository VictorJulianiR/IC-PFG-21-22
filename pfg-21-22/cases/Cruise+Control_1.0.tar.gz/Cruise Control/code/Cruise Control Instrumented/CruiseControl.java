

import java.util.Vector;
import java.util.HashMap;

public class CruiseControl {

    CarSimulator car;	// The simulated car
    Controller control;	// Controls the car's speed when cruising is on

    private static Observer obs;
    
    // ---------
	// Constructor
	// ---------
    public CruiseControl() {
    	this.addVisitedNode("cc1");
        car = new CarSimulator();
        control = new Controller(car);
    }

    /**
     * Accepts command inputs and handle them by sending 
     * events to the car simulator and to the controller
     * appropriately.
     * 
     * @param command - the received command as a string
     * @return true if the command is recognized else otherwise
   	 */
   	public boolean handleCommand(String command)
   	{
   		this.addVisitedNode("cc2");
   		if(command.equals("engineOn")) //start the car engine
        {
   			this.addVisitedNode("cc3");
            car.engineOn();
            control.engineOn();
            return true;
        }
        else {
        	this.addVisitedNode("cc4");
        	if (command.equals("engineOff")) {//stop the car engine
        		this.addVisitedNode("cc5");
        		car.engineOff();
        		control.engineOff();
        		return true;
        	}
        	else {
        		this.addVisitedNode("cc6");
        		if (command.equals("accelerator")) { //accelerate
        			this.addVisitedNode("cc7");
        			car.accelerate();
        			control.accelerator();
        			return true;
        		}
        		else {
        			this.addVisitedNode("cc8");
        			if (command.equals("brake")) {	//brake
        				this.addVisitedNode("cc9");
        				car.brake();
        				control.brake();
        				return true;
        			}
        			else {
        				this.addVisitedNode("cc10");
        				if (command.equals("on")) {	//turn cruise control on
        					this.addVisitedNode("cc11");
        					control.on();
        					return true;
        				}
        				else {
        					this.addVisitedNode("cc12");
        					if (command.equals("off")) {//turn cruise control off
        						this.addVisitedNode("cc13");
        						control.off();
        						return true;
        					}
        					else {
        						this.addVisitedNode("cc14");
        						if (command.equals("resume")) {//resume cruising
        							this.addVisitedNode("cc15");
        						control.resume();
        						return true;
        						} else {
        							this.addVisitedNode("cc16");
        							return false;
        						}
        					}
        				}
        			}
        		}
        	}
        }
    }

	/**
	 * @return the car simulator associated with the cruise control system
	 */
   	public CarSimulator getCar() {
   		this.addVisitedNode("cc18");
		return car;
	}

   	/**
   	 * @return the controller associated with the cruise control system
   	 */
	public Controller getControl() {
		this.addVisitedNode("cc19");
		return control;
	}

	public static String getReport() {
		if (obs.isRecording()) {
			return obs.getReport();
		}
		return "";
	}
	
	public static void startRecording() {
		// Setup recording here.
		HashMap nodeList = new HashMap();
		nodeList.put("cc1","Constructor, Line 17: car = new CarSimulator();");
		nodeList.put("cc2","handleCommand(), Line 31: if(command.equals(\"engineOn\"))");
		nodeList.put("cc3","handleCommand(), Line 33: car.engineOn();");
		nodeList.put("cc4","handleCommand(), Line 37: else if (command.equals(\"engineOff\"))");
		nodeList.put("cc5","handleCommand(), Line 39: car.engineOff();");
        nodeList.put("cc6","handleCommand(), Line 43: else if (command.equals(\"accelerator\"))");
		nodeList.put("cc7","handleCommand(), Line 45: car.accelerate();");
        nodeList.put("cc8","handleCommand(), Line 49: else if (command.equals(\"brake\"))");
		nodeList.put("cc9","handleCommand(), Line 51: car.brake();");
		nodeList.put("cc10","handleCommand(), Line 55: else if (command.equals(\"on\"))");
		nodeList.put("cc11","handleCommand(), Line 57: control.on();");
		nodeList.put("cc12","handleCommand(), Line 60: else if (command.equals(\"off\"))");
		nodeList.put("cc13","handleCommand(), Line 62: control.off();");
        nodeList.put("cc14","handleCommand(), Line 65: else if (command.equals(\"resume\"))");
		nodeList.put("cc15","handleCommand(), Line 67: control.resume();");
		nodeList.put("cc16","handleCommand(), Line 71: return false;");
		nodeList.put("cc17","handleCommand(), Line 72: End Method");
		nodeList.put("cc18","getCar(), Line 78: return car;");
		nodeList.put("cc19","getControl(), Line 85: return control;");
		
		Vector edgeList = new Vector();
		
		edgeList.add("cc2");
		edgeList.add("cc3");
		
		edgeList.add("cc2");
		edgeList.add("cc4");
		
		edgeList.add("cc4");
		edgeList.add("cc5");
		
		edgeList.add("cc4");
		edgeList.add("cc6");
		
		edgeList.add("cc6");
		edgeList.add("cc7");
		
		edgeList.add("cc6");
		edgeList.add("cc8");
		
		edgeList.add("cc8");
		edgeList.add("cc9");
		
		edgeList.add("cc8");
		edgeList.add("cc10");
		
		edgeList.add("cc10");
		edgeList.add("cc11");
		
		edgeList.add("cc10");
		edgeList.add("cc12");
		
		edgeList.add("cc12");
		edgeList.add("cc13");
		
		edgeList.add("cc12");
		edgeList.add("cc14");
		
		edgeList.add("cc14");
		edgeList.add("cc15");
		
		edgeList.add("cc14");
		edgeList.add("cc16");
		
		edgeList.add("cc16");
		edgeList.add("cc17");
		
		edgeList.add("cc3");
		edgeList.add("cc17");
		
		edgeList.add("cc5");
		edgeList.add("cc17");

		edgeList.add("cc7");
		edgeList.add("cc17");

		edgeList.add("cc9");
		edgeList.add("cc17");
		
		edgeList.add("cc11");
		edgeList.add("cc17");
		
		edgeList.add("cc13");
		edgeList.add("cc17");

		edgeList.add("cc15");
		edgeList.add("cc17");
		
		obs = new Observer (nodeList, null, edgeList, "cc1", "CruiseControl Class");
		obs.setRecording(true);
	}
	
	private void addVisitedNode(String nodeName) {
		if (obs == null || !obs.isRecording()) return;
		
		// Add visited nodes here.
		if (nodeName.equals("cc1")) {
			obs.addVisitedNode(nodeName);
		} else if (nodeName.equals("cc2")) {
			obs.addVisitedNode(nodeName);
		} else if (nodeName.equals("cc3")) {
			obs.addVisitedNode(nodeName);
			obs.addVisitedNode("cc17");
		} else if (nodeName.equals("cc4")) {
			obs.addVisitedNode(nodeName);
		} else if (nodeName.equals("cc5")) {
			obs.addVisitedNode(nodeName);
			obs.addVisitedNode("cc17");
		} else if (nodeName.equals("cc6")) {
			obs.addVisitedNode(nodeName);
		} else if (nodeName.equals("cc7")) {
			obs.addVisitedNode(nodeName);
			obs.addVisitedNode("cc17");
		} else if (nodeName.equals("cc8")) {
			obs.addVisitedNode(nodeName);
		} else if (nodeName.equals("cc9")) {
			obs.addVisitedNode(nodeName);
			obs.addVisitedNode("cc17");
		} else if (nodeName.equals("cc10")) {
			obs.addVisitedNode(nodeName);
		} else if (nodeName.equals("cc11")) {
			obs.addVisitedNode(nodeName);
			obs.addVisitedNode("cc17");
		} else if (nodeName.equals("cc12")) {
			obs.addVisitedNode(nodeName);
		} else if (nodeName.equals("cc13")) {
			obs.addVisitedNode(nodeName);
			obs.addVisitedNode("cc17");
		} else if (nodeName.equals("cc14")) {
			obs.addVisitedNode(nodeName);
		} else if (nodeName.equals("cc15")) {
			obs.addVisitedNode(nodeName);
			obs.addVisitedNode("cc17");
		} else if (nodeName.equals("cc16")) {
			obs.addVisitedNode(nodeName);
			obs.addVisitedNode("cc17");
		} else if (nodeName.equals("cc18")) {
			obs.addVisitedNode(nodeName);
		} else if (nodeName.equals("cc19")) {
			obs.addVisitedNode(nodeName);
		} else {
			obs.addVisitedNode(nodeName);
		}
	}
}
