

import java.util.HashMap;
import java.util.Vector;

public class Controller {
	//	cruise controller states
  	public final static int INACTIVE = 0; 		//The car engine is inactive (off)
  	public final static int ACTIVE   = 1; 		//The car engine is active (on) but cruising is not enabled
  	public final static int CRUISING = 2; 		//The car engine is active, and cruising is enabled
  	public final static int STANDBY  = 3; 		//The car engine is active, but cruising has been disabled. Cruising can be resumed.
  	private int controlState  = INACTIVE; //represents the current state of the controller
  	private SpeedControl sc;			// The speed controller

  	private static Observer obs;
  	
	// -----------
	// Constructor
	// -----------
  	public Controller(CarSimulator cs)	{
  		this.addVisitedNode("c0");
  		sc=new SpeedControl(cs); 
  	}

	/**
	 * Braking would disable cruising.
	 * If the controller state is Cruising then it will be set to StandBy
	 */
   	synchronized void brake(){
   		this.addVisitedNode("c1");
    	if (controlState==CRUISING) {
    		this.addVisitedNode("c2");
    		sc.disableControl(); 
    		controlState=STANDBY; 
    	}
    	this.addVisitedNode("c3");
 	}

	/**
	 * Accelerating would disable cruising.
	 * If the controller state is Cruising then it will be set to StandBy
	 */
	synchronized void accelerator() {
		this.addVisitedNode("c4");
    	if (controlState==CRUISING) {
    		this.addVisitedNode("c5");
    		sc.disableControl(); 
    		controlState=STANDBY; 
    	}
    	this.addVisitedNode("c6");
  	}

	/**
	 * Turning the car engine off would disable cruising and set 
	 * the controller state to Inactive
	 */
   	synchronized void engineOff(){
   		this.addVisitedNode("c7");
    	if (controlState!=INACTIVE) {
    		this.addVisitedNode("c8");
      		sc.disableControl();
      		controlState=INACTIVE;
    	}
    	this.addVisitedNode("c9");
 	}

	/**
	 * When turning the car engine on, the controller resets the target
	 * cruise control speed. The controller state would be active
	 */
   	synchronized void engineOn(){
   		this.addVisitedNode("c10");
    	if (controlState==INACTIVE) {
    		this.addVisitedNode("c11");
    		sc.clearSpeed(); 
    		controlState=ACTIVE;
    	}
    	this.addVisitedNode("c12");
  	}

	/**
	 * When turning the cruise control on, cruising is enabled. The speed 
	 * controller would set the target cruise control speed and continue
	 * to monitor and adjust car speed 
	 */
   	synchronized void on() {
   		this.addVisitedNode("c13");
    	if( controlState!=INACTIVE) {
    		this.addVisitedNode("c14");
      		sc.recordSpeed(); 
      		sc.enableControl();
      		controlState=CRUISING;
    	}
    	this.addVisitedNode("c15");
  	}

	/**
	 * When turning the cruise control off, cruising is disabled. The
	 * controller becomes in Standby mode, allowing a possible resuming
	 * of the cruise control 
	 */
   	synchronized void off(){
   		this.addVisitedNode("c16");
    	if (controlState==CRUISING) {
    		this.addVisitedNode("c17");
    		sc.disableControl(); 
    		controlState=STANDBY;
    	}
    	this.addVisitedNode("c18");
  	}

	/**
	 * Resuming from a standby mode would enable cruising with the 
	 * same target speed used before disabling cruising 
	 */
   	synchronized void resume() {
   		this.addVisitedNode("c19");
    	if(controlState==STANDBY) {
    		this.addVisitedNode("c20");
    		sc.enableControl(); 
    		controlState=CRUISING;
    	}
    	this.addVisitedNode("c21");
  	}

   	/**
   	 * @return controller state
   	 */
  	public synchronized int getControlState() {
  		this.addVisitedNode("c22");
    	return controlState;
  	}

  	/**
  	 * @return speed control state
  	 */
  	public synchronized int getState() {
  		this.addVisitedNode("c23");
    	return sc.getState();
  	}
  	
  	public SpeedControl getSpeedControl() {
  		this.addVisitedNode("c24");
  		return sc;
  	}
  	
  	public static String getReport() {
  		if (obs.isRecording()) {
  			return obs.getReport();
  		}
  		return "";
  	}
  	
  	public static void startRecording() {
  		// Setup recording here.
  		HashMap nodeList = new HashMap();
  		nodeList.put("c0","Constructor, Line 21: sc=new SpeedControl(cs);");
  		nodeList.put("c1","brake(), Line 28: if (controlState==CRUISING)");
  		nodeList.put("c2","brake(), Line 29: sc.disableControl(); ");
  		nodeList.put("c3","brake(), Line 31: End if. return;");
  		nodeList.put("c4","accelerator(), Line 39: if (controlState==CRUISING)");
  		nodeList.put("c5","accelerator(), Line 40: sc.disableControl();");
  		nodeList.put("c6","accelerator(), Line 42: End if. return;");
  		nodeList.put("c7","engineOff(), Line 50: if (controlState!=INACTIVE)");
  		nodeList.put("c8","engineOff(), Line 51: sc.disableControl();");
  		nodeList.put("c9","engineOff(), Line 53: End if. return;");
  		nodeList.put("c10","engineOn(), Line 61: if (controlState==INACTIVE)");
  		nodeList.put("c11","engineOn(), Line 62: sc.clearSpeed();");
  		nodeList.put("c12","engineOn(), Line 64: End if. return;");
  		nodeList.put("c13","on(), Line 73: if( controlState!=INACTIVE)");
  		nodeList.put("c14","on(), Line 74: sc.recordSpeed(); ");
  		nodeList.put("c15","on(), Line 77: End if. return;");
  		nodeList.put("c16","off(), Line 86: if (controlState==CRUISING)");
  		nodeList.put("c17","off(), Line 87: sc.disableControl();");
  		nodeList.put("c18","off(), Line 89: End if. return;");
  		nodeList.put("c19","resume(), Line 97: if(controlState==STANDBY)");
  		nodeList.put("c20","resume(), Line 98: sc.enableControl();");
  		nodeList.put("c21","resume(), Line 100: End if. return;");
  		nodeList.put("c22","getControlState(), Line 107: return controlState;");
  		nodeList.put("c23","getState(), Line 114: return sc.getState();");
  		nodeList.put("c24","getSpeedControl(), Line 118: return sc;");
  		
  		Vector edgeList = new Vector();
  		edgeList.add("c1");  		
  		edgeList.add("c2");
  		
  		edgeList.add("c1");  		
  		edgeList.add("c3");
  		
  		edgeList.add("c2");  		
  		edgeList.add("c3");
  		
  		edgeList.add("c4");  		
  		edgeList.add("c5");
  		
  		edgeList.add("c4");  		
  		edgeList.add("c6");
  		
  		edgeList.add("c5");  		
  		edgeList.add("c6");
  		
  		edgeList.add("c7");  		
  		edgeList.add("c8");
  		
  		edgeList.add("c7");  		
  		edgeList.add("c9");
  		
  		edgeList.add("c8");  		
  		edgeList.add("c9");
  		
  		edgeList.add("c10");  		
  		edgeList.add("c11");
  		
  		edgeList.add("c10");  		
  		edgeList.add("c12");
  		
  		edgeList.add("c11");  		
  		edgeList.add("c12");
  		
  		edgeList.add("c13");  		
  		edgeList.add("c14");
  		
  		edgeList.add("c13");  		
  		edgeList.add("c15");
  		
  		edgeList.add("c14");  		
  		edgeList.add("c15");
  		
  		edgeList.add("c16");  		
  		edgeList.add("c17");
  		
  		edgeList.add("c16");  		
  		edgeList.add("c18");
  		
  		edgeList.add("c17");  		
  		edgeList.add("c18");
  		
  		edgeList.add("c19");  		
  		edgeList.add("c20");
  		
  		edgeList.add("c19");  		
  		edgeList.add("c21");
  		
  		edgeList.add("c20");  		
  		edgeList.add("c21");
  		
  		obs = new Observer(nodeList, null, edgeList, "c0", "Controller Class");
  		obs.setRecording(true);
  	}  	
  	
  	private void addVisitedNode(String nodeName) {
  		if (obs == null || !obs.isRecording()) return;
  		
  		// Setup add nodes here.
  		if (nodeName.equals("c0")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c1")) {
  			obs.addVisitedNode(nodeName);
  		} 
  		else if (nodeName.equals("c2")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c3")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c4")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c5")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c6")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c7")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c8")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c9")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c10")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c11")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c12")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c13")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c14")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c15")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c16")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c17")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c18")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c19")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c20")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c21")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c22")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c23")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else if (nodeName.equals("c24")) {
  			obs.addVisitedNode(nodeName);
  		}
  		else {
  			obs.addVisitedNode(nodeName);
  		}
  	}
}

