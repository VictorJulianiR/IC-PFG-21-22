
import java.io.*;

/**
 * 
 * @author Mike
 *
 */
public class Recorder {

	private static Recorder rec;
	
	private Recorder() {}
	
	public static Recorder getInstance() {
		if (rec == null) {
			rec = new Recorder();
		}
		
		return rec;
	}
	
	public void startRecording() {
		CarSimulator.startRecording();
		Controller.startRecording();
		CruiseControl.startRecording();
		SpeedControl.startRecording();
	}
	
	public void printReport() {
		String report = "";
		
		report += "Coverage Report";

		report += CarSimulator.getReport();
		report += Controller.getReport();
		report += CruiseControl.getReport();
		report += SpeedControl.getReport();

		File outputFile = new File("report.txt");
		if (outputFile.exists()) {
			outputFile.delete();
		}
		
		try {
			outputFile.createNewFile();
			
			PrintStream ps = new PrintStream(new FileOutputStream(outputFile));
			ps.print(report);
			ps.close();
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
			System.out.println("Unable to create report file. Dumping to console.");
			System.out.println(report);
		}
	}
}